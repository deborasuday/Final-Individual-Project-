-- Career Guidance Platform Database
-- Simple database structure for career assessment system

CREATE DATABASE IF NOT EXISTS career_guidance_platform;
USE career_guidance_platform;

-- Users table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'general_user',
    verified BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Assessments table
CREATE TABLE assessments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    assessment_type VARCHAR(50) DEFAULT 'comprehensive',
    questions_count INT DEFAULT 20,
    estimated_duration INT DEFAULT 15,
    status VARCHAR(50) DEFAULT 'published',
    created_by INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User assessment results
CREATE TABLE user_assessment_results (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    assessment_id INT NOT NULL,
    responses JSON NOT NULL,
    calculated_scores JSON,
    recommended_careers JSON,
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Careers table
CREATE TABLE careers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    overview TEXT NOT NULL,
    industry VARCHAR(100),
    salary_range_min INT,
    salary_range_max INT,
    job_outlook VARCHAR(50) DEFAULT 'stable',
    education_requirements TEXT,
    work_environment TEXT,
    status VARCHAR(50) DEFAULT 'published',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default assessment
INSERT INTO assessments (title, description, assessment_type, questions_count, estimated_duration, status, created_by) 
VALUES ('Career Interest Assessment', 'Discover your career interests and find matching career paths', 'comprehensive', 20, 15, 'published', 1);

-- Insert sample careers
INSERT INTO careers (title, overview, industry, salary_range_min, salary_range_max, job_outlook, education_requirements, work_environment, status) VALUES
('Software Developer', 'Design, develop, and maintain software applications and systems. Work with programming languages, frameworks, and tools to create solutions for various industries.', 'Technology', 60000, 120000, 'rapidly_growing', 'Bachelor\'s degree in Computer Science or related field', 'Office environment, remote work options available', 'published'),

('Data Scientist', 'Analyze complex data to help organizations make informed business decisions using statistical methods, machine learning, and data visualization tools.', 'Technology', 70000, 140000, 'rapidly_growing', 'Bachelor\'s degree in Statistics, Mathematics, or Computer Science', 'Office environment with collaborative workspaces', 'published'),

('Digital Marketing Specialist', 'Develop and execute digital marketing campaigns across various online platforms including social media, email, and search engines.', 'Marketing', 45000, 85000, 'growing', 'Bachelor\'s degree in Marketing, Communications, or related field', 'Office environment with creative spaces', 'published'),

('Project Manager', 'Plan, execute, and oversee projects from initiation to completion, ensuring they meet deadlines, budget requirements, and quality standards.', 'Business', 55000, 110000, 'stable', 'Bachelor\'s degree in Business Administration or related field', 'Office environment with meeting rooms', 'published'),

('UX/UI Designer', 'Create user-friendly and visually appealing interfaces for websites and mobile applications. Conduct user research and design prototypes.', 'Design', 50000, 100000, 'growing', 'Bachelor\'s degree in Design, HCI, or related field', 'Creative office environment with design studios', 'published'),

('Cybersecurity Analyst', 'Protect computer systems and networks from cyber threats by monitoring, detecting, and responding to security incidents.', 'Technology', 65000, 125000, 'rapidly_growing', 'Bachelor\'s degree in Cybersecurity, IT, or related field', 'Secure office environment with monitoring centers', 'published');