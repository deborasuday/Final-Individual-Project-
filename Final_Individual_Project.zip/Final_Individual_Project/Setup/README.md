# Career Guidance Platform

A comprehensive web application built with PHP and MySQL that helps individuals discover their ideal career paths through personalized assessments and data-driven recommendations.

## Project Description

The Career Guidance Platform is a sophisticated web application that addresses the challenge of career uncertainty in today's dynamic job market. The platform features an intelligent assessment engine that evaluates users across 14 skill areas and 8 interest domains, using a weighted matching algorithm that combines skills evaluation (60%) and interests analysis (40%) to generate accurate career compatibility scores. Users complete a 10-15 minute assessment and receive detailed career matches with comprehensive information including salary ranges, growth prospects, educational requirements, and step-by-step career roadmaps with actionable next steps.

## Key Features

- **Personalized Career Assessment**: Comprehensive evaluation of skills and interests
- **Intelligent Matching Algorithm**: Data-driven career recommendations with percentage scores
- **Detailed Career Database**: 500+ careers with salary data, growth prospects, and requirements
- **Career Roadmaps**: Step-by-step guidance with timelines, resources, and next steps
- **User Dashboard**: Progress tracking and assessment management
- **Responsive Design**: Professional interface optimized for all devices
- **Secure Authentication**: User registration and login system with password hashing

## Technology Stack

- **Backend**: PHP 7.4+ with MVC architecture
- **Database**: MySQL with normalized schema design
- **Frontend**: HTML5, CSS3, JavaScript
- **Security**: Password hashing, input validation, SQL injection prevention
- **Server**: Apache with mod_rewrite enabled

## Installation & Setup

### Prerequisites
- Apache web server with PHP 7.4+
- MySQL 8.0+ or MariaDB
- mod_rewrite enabled

### Setup Instructions

1. **Place Project Files**
   - Copy project to your web server directory (e.g., `htdocs/career_platform/`)

2. **Database Setup**
   - Start Apache and MySQL services
   - Run `initialize.php` in your browser to create database and tables
   - Or manually import `database/database.sql`

3. **Environment Configuration**
   - Copy `.env.example` to `.env`
   - Update database credentials in `.env` file

4. **Access Application**
   - Navigate to your project URL (e.g., `http://localhost/career_platform/`)
   - For demo version: use `demo_platform.php`

## Usage Guide

### User Journey
1. **Register**: Create account with personal information
2. **Assessment**: Complete skills and interests evaluation (10-15 minutes)
3. **Results**: View personalized career matches with detailed analysis
4. **Exploration**: Browse career database and detailed information
5. **Planning**: Access career roadmaps and development resources

### Assessment System
- **Skills Assessment**: Rate proficiency in 14 skill areas (1-5 scale)
- **Interests Assessment**: Rate interest in 8 career domains (1-5 scale)
- **Matching Algorithm**: Combines evaluations for accurate career matching
- **Results**: Displays top matches with percentage scores and explanations

## Architecture

### 3-Tier Architecture
- **Presentation Tier**: HTML5, CSS3, JavaScript user interface
- **Application Tier**: PHP controllers, business logic, authentication
- **Data Tier**: MySQL database with normalized schema

### File Structure
```
├── app/
│   ├── controllers/     # MVC controllers (Auth, Assessment, Career, Dashboard)
│   ├── models/         # Data models (User, Assessment, Career)
│   ├── services/       # Business logic services
│   ├── repositories/   # Data access layer
│   ├── views/          # User interface templates
│   └── core/           # Router and core functionality
├── config/             # Configuration files
├── database/           # Database schema and setup
├── public/assets/      # CSS, JavaScript, images
├── demo_platform.php   # Standalone demo version
└── index.php          # Main application entry point
```

### Database Schema
- **users**: User accounts and authentication
- **assessments**: Assessment definitions and metadata
- **user_assessment_results**: User responses and calculated results
- **careers**: Career information and details

## Target Users

- **Recent Graduates**: Transitioning from education to workforce
- **Career Changers**: Professionals seeking new directions
- **Working Professionals**: Looking for advancement opportunities
- **Students**: Exploring career options for academic planning
- **Job Seekers**: Targeting compatible career positions

## Security Features

- Secure password hashing using PHP's `password_hash()`
- Input validation and sanitization
- SQL injection prevention through prepared statements
- Session-based authentication
- CSRF protection on forms

## Browser Compatibility

- Chrome 60+
- Firefox 55+
- Safari 11+
- Edge 79+

## Demo Access

For demonstration purposes, use:
- **Main Application**: `index.php`
- **Standalone Demo**: `demo_platform.php` (no database setup required)

## Development Notes

- Built using MVC architectural pattern
- Follows PSR-12 PHP coding standards
- Implements responsive design principles
- Uses normalized database design
- Includes comprehensive error handling

## Educational Value

This project demonstrates:
- Full-stack web development skills
- Database design and management
- User experience and interface design
- Security implementation
- Software engineering best practices
- Problem-solving through technology

## License

This project is developed for educational purposes.

---

**Project Status**: Complete and ready for demonstration  
**Last Updated**: December 2024