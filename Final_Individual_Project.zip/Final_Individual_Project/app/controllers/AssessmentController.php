<?php
/**
 * Assessment Controller
 * Handles career assessment functionality
 */

require_once 'BaseController.php';
require_once APP_PATH . '/services/AssessmentService.php';

class AssessmentController extends BaseController {
    private $assessmentService;
    
    public function __construct() {
        parent::__construct();
        $this->assessmentService = new AssessmentService();
    }
    
    /**
     * Display assessment form
     */
    public function index() {
        $user = $this->getCurrentUser();
        
        if (!$user) {
            $this->redirect('/login');
            return;
        }
        
        // Get assessment questions
        $questions = $this->assessmentService->getAssessmentQuestions();
        
        // Check if user has previous assessments
        $previousAssessments = $this->assessmentService->getUserAssessmentHistory($user['id']);
        
        $data = [
            'title' => 'Career Assessment - ' . APP_NAME,
            'user' => $user,
            'questions' => $questions,
            'previousAssessments' => $previousAssessments,
            'hasCompletedBefore' => !empty($previousAssessments)
        ];
        
        $this->render('assessment/index', $data);
    }
    
    /**
     * Process assessment submission
     */
    public function submit() {
        $user = $this->getCurrentUser();
        
        if (!$user) {
            $this->json(['success' => false, 'error' => 'Authentication required'], 401);
            return;
        }
        
        // Validate CSRF token
        $this->validateCSRF();
        
        // Get form data
        $skillResponses = $_POST['skills'] ?? [];
        $interestResponses = $_POST['interests'] ?? [];
        
        $responses = [
            'skills' => $skillResponses,
            'interests' => $interestResponses
        ];
        
        // Process assessment
        $result = $this->assessmentService->processAssessment($user['id'], $responses);
        
        if ($result['success']) {
            // Store assessment ID in session for results page
            $_SESSION['latest_assessment_id'] = $result['assessment_id'];
            
            if ($this->isAjaxRequest()) {
                $this->json($result);
            } else {
                $_SESSION['flash_message'] = 'Assessment completed successfully!';
                $_SESSION['flash_type'] = 'success';
                $this->redirect('/assessment/results');
            }
        } else {
            if ($this->isAjaxRequest()) {
                $this->json($result, 400);
            } else {
                $_SESSION['flash_message'] = 'Assessment submission failed. Please try again.';
                $_SESSION['flash_type'] = 'error';
                $this->redirect('/assessment');
            }
        }
    }
    
    /**
     * Display assessment results
     */
    public function results() {
        $user = $this->getCurrentUser();
        
        if (!$user) {
            $this->redirect('/login');
            return;
        }
        
        // Get assessment ID from session or URL parameter
        $assessmentId = $_SESSION['latest_assessment_id'] ?? $_GET['id'] ?? null;
        
        if (!$assessmentId) {
            $_SESSION['flash_message'] = 'No assessment results found.';
            $_SESSION['flash_type'] = 'error';
            $this->redirect('/assessment');
            return;
        }
        
        // Get detailed assessment results
        $results = $this->assessmentService->getAssessmentResults($assessmentId);
        
        if (!$results) {
            $_SESSION['flash_message'] = 'Assessment results not found.';
            $_SESSION['flash_type'] = 'error';
            $this->redirect('/assessment');
            return;
        }
        
        // Clear session assessment ID
        unset($_SESSION['latest_assessment_id']);
        
        $data = [
            'title' => 'Assessment Results - ' . APP_NAME,
            'user' => $user,
            'results' => $results
        ];
        
        $this->render('assessment/results', $data);
    }
    
    /**
     * Display assessment history
     */
    public function history() {
        $user = $this->getCurrentUser();
        
        if (!$user) {
            $this->redirect('/login');
            return;
        }
        
        $assessments = $this->assessmentService->getUserAssessmentHistory($user['id']);
        
        $data = [
            'title' => 'Assessment History - ' . APP_NAME,
            'user' => $user,
            'assessments' => $assessments
        ];
        
        $this->render('assessment/history', $data);
    }
}