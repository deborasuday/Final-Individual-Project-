<?php
/**
 * Base Controller Class
 * Provides common functionality for all controllers
 */

class BaseController {
    protected $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    /**
     * Render a view with data
     */
    protected function render($view, $data = []) {
        // Extract data array to variables
        extract($data);
        
        // Start output buffering
        ob_start();
        
        // Include the view file
        $viewFile = APP_PATH . '/views/' . $view . '.php';
        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            throw new Exception("View not found: " . $view);
        }
        
        // Get the content and clean buffer
        $content = ob_get_clean();
        
        // Include layout if not an AJAX request
        if (!$this->isAjaxRequest()) {
            include APP_PATH . '/views/layouts/main.php';
        } else {
            echo $content;
        }
    }
    
    /**
     * Return JSON response
     */
    protected function json($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }
    
    /**
     * Redirect to another URL
     */
    protected function redirect($url, $statusCode = 302) {
        // Add base URL if it's a relative path
        if ($url[0] === '/') {
            $url = BASE_URL . $url;
        }
        
        http_response_code($statusCode);
        header('Location: ' . $url);
        exit;
    }
    
    /**
     * Check if request is AJAX
     */
    protected function isAjaxRequest() {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
    
    /**
     * Get current user from session
     */
    protected function getCurrentUser() {
        if (!isset($_SESSION['user_id'])) {
            return null;
        }
        
        // Load user from database
        require_once APP_PATH . '/repositories/UserRepository.php';
        $userRepo = new UserRepository();
        return $userRepo->findById($_SESSION['user_id']);
    }
    
    /**
     * Check if user has specific role
     */
    protected function hasRole($role) {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === $role;
    }
    
    /**
     * Validate CSRF token
     */
    protected function validateCSRF() {
        $token = $_POST[CSRF_TOKEN_NAME] ?? '';
        if (!verifyCSRFToken($token)) {
            http_response_code(403);
            $this->json(['error' => 'Invalid CSRF token']);
        }
    }
    
    /**
     * Get and sanitize POST data
     */
    protected function getPostData($fields = null) {
        $data = [];
        $source = $_POST;
        
        if ($fields === null) {
            $fields = array_keys($source);
        }
        
        foreach ($fields as $field) {
            $data[$field] = sanitizeInput($source[$field] ?? '');
        }
        
        return $data;
    }
    
    /**
     * Get and sanitize GET data
     */
    protected function getQueryData($fields = null) {
        $data = [];
        $source = $_GET;
        
        if ($fields === null) {
            $fields = array_keys($source);
        }
        
        foreach ($fields as $field) {
            $data[$field] = sanitizeInput($source[$field] ?? '');
        }
        
        return $data;
    }
}