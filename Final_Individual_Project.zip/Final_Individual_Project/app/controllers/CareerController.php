<?php
/**
 * Career Controller
 * Handles career exploration and roadmap functionality
 */

require_once 'BaseController.php';
require_once APP_PATH . '/services/CareerService.php';
require_once APP_PATH . '/repositories/CareerRepository.php';

class CareerController extends BaseController {
    private $careerService;
    private $careerRepository;
    
    public function __construct() {
        parent::__construct();
        $this->careerService = new CareerService();
        $this->careerRepository = new CareerRepository();
    }
    
    /**
     * Display careers listing with search and filters
     * Public access allowed - encourages registration for full features
     */
    public function index() {
        $user = $this->getCurrentUser();
        
        // Get search parameters
        $searchTerm = $_GET['search'] ?? '';
        $industry = $_GET['industry'] ?? '';
        $page = max(1, intval($_GET['page'] ?? 1));
        $limit = 12;
        
        // Get careers based on search/filters
        if ($searchTerm || $industry) {
            $careers = $this->careerService->searchCareers($searchTerm, [
                'industry' => $industry,
                'limit' => $limit * $page
            ]);
        } else if ($user) {
            // Get personalized recommendations for logged-in users
            $careers = $this->careerService->getPersonalizedRecommendations($user['id'], $limit * $page);
        } else {
            // Show popular careers for guests
            $careers = $this->careerRepository->getPopularCareers($limit);
        }
        
        // Get all industries for filter
        $industries = $this->careerRepository->getAllIndustries();
        
        // Get popular careers
        $popularCareers = $this->careerRepository->getPopularCareers(6);
        
        $data = [
            'title' => 'Explore Careers - ' . APP_NAME,
            'user' => $user,
            'careers' => $careers,
            'industries' => $industries,
            'popularCareers' => $popularCareers,
            'searchTerm' => $searchTerm,
            'selectedIndustry' => $industry,
            'currentPage' => $page,
            'hasSearch' => !empty($searchTerm) || !empty($industry),
            'isGuest' => !$user
        ];
        
        $this->render('careers/index', $data);
    }
    
    /**
     * Display individual career details
     * Public access allowed - shows preview, encourages registration for full features
     */
    public function show($careerId) {
        $user = $this->getCurrentUser();
        
        // Get career roadmap with full details
        $career = $this->careerService->getCareerRoadmap($careerId);
        
        if (!$career) {
            $_SESSION['flash_message'] = 'Career not found.';
            $_SESSION['flash_type'] = 'error';
            $this->redirect('/careers');
            return;
        }
        
        // Get career insights
        $insights = $this->careerService->getCareerInsights($careerId);
        
        // For logged-in users, get personalized data
        $isSaved = false;
        $skillGap = null;
        
        if ($user) {
            $isSaved = $this->isCareerSaved($user['id'], $careerId);
            $skillGap = $this->getUserSkillGap($user['id'], $career);
        }
        
        $data = [
            'title' => $career['title'] . ' - Career Roadmap',
            'user' => $user,
            'career' => $career,
            'insights' => $insights,
            'isSaved' => $isSaved,
            'skillGap' => $skillGap,
            'isGuest' => !$user
        ];
        
        $this->render('careers/show', $data);
    }
    
    /**
     * Save/unsave career for user
     */
    public function toggleSave() {
        $user = $this->getCurrentUser();
        
        if (!$user) {
            $this->json(['success' => false, 'error' => 'Authentication required'], 401);
            return;
        }
        
        $this->validateCSRF();
        
        $careerId = $_POST['career_id'] ?? null;
        
        if (!$careerId) {
            $this->json(['success' => false, 'error' => 'Career ID required'], 400);
            return;
        }
        
        // Check if career exists
        $career = $this->careerRepository->findById($careerId);
        if (!$career) {
            $this->json(['success' => false, 'error' => 'Career not found'], 404);
            return;
        }
        
        // Toggle save status
        $isSaved = $this->isCareerSaved($user['id'], $careerId);
        
        if ($isSaved) {
            $result = $this->removeCareerSave($user['id'], $careerId);
            $action = 'removed';
        } else {
            $result = $this->saveCareer($user['id'], $careerId);
            $action = 'saved';
        }
        
        if ($result) {
            $this->json([
                'success' => true,
                'action' => $action,
                'message' => "Career {$action} successfully"
            ]);
        } else {
            $this->json(['success' => false, 'error' => 'Failed to update save status'], 500);
        }
    }
    
    /**
     * Get career comparison data
     */
    public function compare() {
        $user = $this->getCurrentUser();
        
        if (!$user) {
            $this->redirect('/login');
            return;
        }
        
        $careerIds = $_GET['careers'] ?? [];
        
        if (!is_array($careerIds) || count($careerIds) < 2 || count($careerIds) > 3) {
            $_SESSION['flash_message'] = 'Please select 2-3 careers to compare.';
            $_SESSION['flash_type'] = 'error';
            $this->redirect('/careers');
            return;
        }
        
        $careers = [];
        foreach ($careerIds as $careerId) {
            $career = $this->careerService->getCareerRoadmap($careerId);
            if ($career) {
                $careers[] = $career;
            }
        }
        
        if (count($careers) < 2) {
            $_SESSION['flash_message'] = 'Invalid careers selected for comparison.';
            $_SESSION['flash_type'] = 'error';
            $this->redirect('/careers');
            return;
        }
        
        $data = [
            'title' => 'Career Comparison - ' . APP_NAME,
            'user' => $user,
            'careers' => $careers
        ];
        
        $this->render('careers/compare', $data);
    }
    
    /**
     * Check if user has saved a career
     */
    private function isCareerSaved($userId, $careerId) {
        // This would query user_preferences table
        // For now, return false
        return false;
    }
    
    /**
     * Save career for user
     */
    private function saveCareer($userId, $careerId) {
        // This would insert into user_preferences table
        // For now, return true
        return true;
    }
    
    /**
     * Remove career save for user
     */
    private function removeCareerSave($userId, $careerId) {
        // This would delete from user_preferences table
        // For now, return true
        return true;
    }
    
    /**
     * Get user's skill gap analysis for a career
     */
    private function getUserSkillGap($userId, $career) {
        // This would compare user's assessment with career requirements
        // For now, return sample data
        return [
            'matching_skills' => 8,
            'total_skills' => 12,
            'gap_percentage' => 33,
            'missing_skills' => [
                'Advanced JavaScript',
                'Database Design',
                'System Architecture',
                'DevOps'
            ]
        ];
    }
}