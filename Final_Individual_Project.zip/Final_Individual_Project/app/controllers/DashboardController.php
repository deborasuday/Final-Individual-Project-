<?php
/**
 * Home Controller
 * Handles the main landing page and public content
 */

require_once 'BaseController.php';

class DashboardController extends BaseController {
    
    /**
     * Display the dashboard
     */
    public function index() {
        $user = $this->getCurrentUser();
        
        // Sample data for dashboard
        $data = [
            'title' => 'Dashboard - ' . APP_NAME,
            'user' => $user,
            'hasAssessment' => false, // User hasn't taken assessment yet
            'progressStats' => [
                'assessments_completed' => 0,
                'careers_explored' => 0,
                'roadmaps_viewed' => 0,
                'skills_identified' => 0,
                'progress_percentage' => 0
            ],
            'recentActivity' => [
                [
                    'type' => 'registration',
                    'title' => 'Welcome to Career Guidance Platform!',
                    'description' => 'Account created successfully',
                    'date' => date('Y-m-d H:i:s'),
                    'icon' => '🎉'
                ]
            ]
        ];
        
        $this->render('dashboard/index', $data);
    }
}