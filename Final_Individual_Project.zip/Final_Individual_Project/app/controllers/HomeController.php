<?php

require_once 'BaseController.php';

class HomeController extends BaseController {
    
    public function index() {
        $data = [
            'title' => 'Career Guidance Platform - Discover Your Path',
            'isLoggedIn' => isset($_SESSION['user_id']),
            'user' => $_SESSION['user'] ?? null
        ];
        
        $this->render('home/index', $data);
    }
}