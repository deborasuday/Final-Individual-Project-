<?php
/**
 * Router Class
 * Handles URL routing and dispatches requests to appropriate controllers
 */

class Router {
    private $routes = [];
    private $middlewares = [];
    
    public function __construct() {
        $this->loadRoutes();
    }
    
    /**
     * Define application routes
     */
    private function loadRoutes() {
        // Public routes
        $this->addRoute('GET', '/', 'HomeController@index');
        $this->addRoute('GET', '/login', 'AuthController@showLogin');
        $this->addRoute('POST', '/login', 'AuthController@login');
        $this->addRoute('GET', '/register', 'AuthController@showRegister');
        $this->addRoute('POST', '/register', 'AuthController@register');
        $this->addRoute('GET', '/logout', 'AuthController@logout');
        
        // Career routes
        $this->addRoute('GET', '/careers', 'CareerController@index');
        $this->addRoute('GET', '/careers/{id}', 'CareerController@show');
        
        // Protected routes
        $this->addRoute('GET', '/dashboard', 'DashboardController@index', ['auth']);
        $this->addRoute('GET', '/assessment', 'AssessmentController@index', ['auth']);
        $this->addRoute('POST', '/assessment', 'AssessmentController@submit', ['auth']);
        $this->addRoute('GET', '/assessment/results', 'AssessmentController@results', ['auth']);
        $this->addRoute('GET', '/assessment/history', 'AssessmentController@history', ['auth']);
    }
    
    /**
     * Add a route to the routing table
     */
    private function addRoute($method, $path, $handler, $middlewares = []) {
        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'handler' => $handler,
            'middlewares' => $middlewares
        ];
    }
    
    /**
     * Handle incoming request
     */
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        // Remove base path if running in a subdirectory
        $basePath = dirname($_SERVER['SCRIPT_NAME']);
        if ($basePath !== '/' && strpos($path, $basePath) === 0) {
            $path = substr($path, strlen($basePath));
        }
        
        // Ensure path starts with /
        if (empty($path) || $path[0] !== '/') {
            $path = '/' . $path;
        }
        
        // Remove trailing slash except for root
        if ($path !== '/' && substr($path, -1) === '/') {
            $path = rtrim($path, '/');
        }
        
        foreach ($this->routes as $route) {
            if ($this->matchRoute($route, $method, $path)) {
                $this->executeRoute($route, $path);
                return;
            }
        }
        
        // No route found - 404 error
        $this->handleNotFound();
    }
    
    /**
     * Check if route matches current request
     */
    private function matchRoute($route, $method, $path) {
        if ($route['method'] !== $method) {
            return false;
        }
        
        $routePath = $route['path'];
        
        // Convert route parameters to regex pattern
        $pattern = preg_replace('/\{([^}]+)\}/', '([^/]+)', $routePath);
        $pattern = '#^' . $pattern . '$#';
        
        return preg_match($pattern, $path);
    }
    
    /**
     * Execute matched route
     */
    private function executeRoute($route, $path) {
        // Extract route parameters
        $params = $this->extractParams($route['path'], $path);
        
        // Run middlewares
        foreach ($route['middlewares'] as $middleware) {
            if (!$this->runMiddleware($middleware)) {
                return; // Middleware blocked the request
            }
        }
        
        // Parse controller and method
        list($controllerName, $methodName) = explode('@', $route['handler']);
        
        // Load and instantiate controller
        $controllerFile = APP_PATH . '/controllers/' . $controllerName . '.php';
        if (!file_exists($controllerFile)) {
            throw new Exception("Controller file not found: " . $controllerFile);
        }
        
        require_once $controllerFile;
        
        if (!class_exists($controllerName)) {
            throw new Exception("Controller class not found: " . $controllerName);
        }
        
        $controller = new $controllerName();
        
        if (!method_exists($controller, $methodName)) {
            throw new Exception("Method not found: " . $controllerName . '::' . $methodName);
        }
        
        // Call controller method with parameters
        call_user_func_array([$controller, $methodName], $params);
    }
    
    /**
     * Extract parameters from URL path
     */
    private function extractParams($routePath, $actualPath) {
        $routeParts = explode('/', trim($routePath, '/'));
        $actualParts = explode('/', trim($actualPath, '/'));
        
        $params = [];
        for ($i = 0; $i < count($routeParts); $i++) {
            if (preg_match('/\{([^}]+)\}/', $routeParts[$i])) {
                $params[] = $actualParts[$i] ?? null;
            }
        }
        
        return $params;
    }
    
    /**
     * Run middleware
     */
    private function runMiddleware($middleware) {
        switch ($middleware) {
            case 'auth':
                return $this->authMiddleware();
            default:
                return true;
        }
    }
    
    /**
     * Authentication middleware
     */
    private function authMiddleware() {
        if (!isset($_SESSION['user_id'])) {
            $baseUrl = defined('BASE_URL') ? BASE_URL : 'http://localhost/Final_Individual_Project';
            header('Location: ' . $baseUrl . '/login');
            exit;
        }
        return true;
    }
    
    /**
     * Handle 404 Not Found
     */
    private function handleNotFound() {
        http_response_code(404);
        echo "<h1>Page Not Found</h1><p>The page you are looking for does not exist.</p>";
    }
}