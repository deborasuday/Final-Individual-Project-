<?php
/**
 * Assessment Model
 * Handles career assessments and user results
 */

require_once 'BaseModel.php';

class Assessment extends BaseModel {
    protected $table = 'assessments';
    protected $fillable = [
        'title', 'description', 'assessment_type', 'questions_count', 
        'estimated_duration', 'status', 'created_by'
    ];
    protected $casts = [
        'questions_count' => 'integer',
        'estimated_duration' => 'integer',
        'created_by' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime'
    ];
    
    /**
     * Get assessment with questions
     */
    public function getAssessmentWithQuestions($assessmentId) {
        $assessment = $this->find($assessmentId);
        
        if (!$assessment) {
            return null;
        }
        
        $assessment['questions'] = $this->getAssessmentQuestions($assessmentId);
        
        return $assessment;
    }
    
    /**
     * Get published assessments
     */
    public function getPublishedAssessments() {
        return $this->findAll(['status' => 'published'], 'title');
    }
    
    /**
     * Get assessment questions in order
     */
    public function getAssessmentQuestions($assessmentId) {
        $sql = "SELECT * FROM assessment_questions 
                WHERE assessment_id = ? 
                ORDER BY question_order";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$assessmentId]);
        
        $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Decode JSON options
        foreach ($questions as &$question) {
            if ($question['options']) {
                $question['options'] = json_decode($question['options'], true);
            }
        }
        
        return $questions;
    }
    
    /**
     * Submit assessment results
     */
    public function submitAssessmentResults($userId, $assessmentId, $responses) {
        // Validate responses
        $assessment = $this->getAssessmentWithQuestions($assessmentId);
        if (!$assessment) {
            throw new InvalidArgumentException('Assessment not found');
        }
        
        $errors = $this->validateResponses($assessment, $responses);
        if (!empty($errors)) {
            throw new InvalidArgumentException('Invalid responses: ' . implode(', ', $errors));
        }
        
        // Calculate scores based on assessment type
        $calculatedScores = $this->calculateScores($assessment, $responses);
        
        // Generate career recommendations
        $recommendations = $this->generateRecommendations($calculatedScores);
        
        // Store results
        $sql = "INSERT INTO user_assessment_results 
                (user_id, assessment_id, responses, calculated_scores, recommended_careers) 
                VALUES (?, ?, ?, ?, ?)";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            $userId,
            $assessmentId,
            json_encode($responses),
            json_encode($calculatedScores),
            json_encode($recommendations)
        ]);
        
        $resultId = $this->db->lastInsertId();
        
        return [
            'id' => $resultId,
            'scores' => $calculatedScores,
            'recommendations' => $recommendations
        ];
    }
    
    /**
     * Get user's assessment results
     */
    public function getUserAssessmentResults($userId, $assessmentId = null) {
        $sql = "SELECT uar.*, a.title as assessment_title, a.assessment_type
                FROM user_assessment_results uar
                JOIN assessments a ON uar.assessment_id = a.id
                WHERE uar.user_id = ?";
        
        $params = [$userId];
        
        if ($assessmentId) {
            $sql .= " AND uar.assessment_id = ?";
            $params[] = $assessmentId;
        }
        
        $sql .= " ORDER BY uar.completed_at DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Decode JSON fields
        foreach ($results as &$result) {
            $result['responses'] = json_decode($result['responses'], true);
            $result['calculated_scores'] = json_decode($result['calculated_scores'], true);
            $result['recommended_careers'] = json_decode($result['recommended_careers'], true);
        }
        
        return $results;
    }
    
    /**
     * Get latest assessment result for user
     */
    public function getLatestUserResult($userId, $assessmentType = null) {
        $sql = "SELECT uar.*, a.title as assessment_title, a.assessment_type
                FROM user_assessment_results uar
                JOIN assessments a ON uar.assessment_id = a.id
                WHERE uar.user_id = ?";
        
        $params = [$userId];
        
        if ($assessmentType) {
            $sql .= " AND a.assessment_type = ?";
            $params[] = $assessmentType;
        }
        
        $sql .= " ORDER BY uar.completed_at DESC LIMIT 1";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            $result['responses'] = json_decode($result['responses'], true);
            $result['calculated_scores'] = json_decode($result['calculated_scores'], true);
            $result['recommended_careers'] = json_decode($result['recommended_careers'], true);
        }
        
        return $result;
    }
    
    /**
     * Validate assessment responses
     */
    private function validateResponses($assessment, $responses) {
        $errors = [];
        
        foreach ($assessment['questions'] as $question) {
            $questionId = $question['id'];
            
            if (!isset($responses[$questionId])) {
                $errors[] = "Missing response for question {$question['question_order']}";
                continue;
            }
            
            $response = $responses[$questionId];
            
            switch ($question['question_type']) {
                case 'multiple_choice':
                    $validOptions = $question['options']['options'] ?? [];
                    if (!in_array($response, $validOptions)) {
                        $errors[] = "Invalid option for question {$question['question_order']}";
                    }
                    break;
                    
                case 'scale':
                    $min = $question['options']['min'] ?? 1;
                    $max = $question['options']['max'] ?? 5;
                    if (!is_numeric($response) || $response < $min || $response > $max) {
                        $errors[] = "Invalid scale value for question {$question['question_order']}";
                    }
                    break;
                    
                case 'ranking':
                    if (!is_array($response)) {
                        $errors[] = "Ranking response must be an array for question {$question['question_order']}";
                    }
                    break;
                    
                case 'text':
                    if (empty(trim($response))) {
                        $errors[] = "Text response cannot be empty for question {$question['question_order']}";
                    }
                    break;
            }
        }
        
        return $errors;
    }
    
    /**
     * Calculate assessment scores
     */
    private function calculateScores($assessment, $responses) {
        $scores = [];
        
        switch ($assessment['assessment_type']) {
            case 'interests':
                $scores = $this->calculateInterestScores($assessment, $responses);
                break;
                
            case 'skills':
                $scores = $this->calculateSkillScores($assessment, $responses);
                break;
                
            case 'personality':
                $scores = $this->calculatePersonalityScores($assessment, $responses);
                break;
                
            case 'values':
                $scores = $this->calculateValueScores($assessment, $responses);
                break;
                
            case 'comprehensive':
                $scores = $this->calculateComprehensiveScores($assessment, $responses);
                break;
        }
        
        return $scores;
    }
    
    /**
     * Calculate interest-based scores
     */
    private function calculateInterestScores($assessment, $responses) {
        $interestAreas = [
            'technology' => 0,
            'healthcare' => 0,
            'business' => 0,
            'creative' => 0,
            'education' => 0,
            'engineering' => 0
        ];
        
        // Simple scoring algorithm - in a real system this would be more sophisticated
        foreach ($responses as $questionId => $response) {
            if (is_numeric($response)) {
                // For scale questions, distribute score across relevant areas
                $interestAreas['technology'] += $response * 0.2;
                $interestAreas['business'] += $response * 0.15;
                $interestAreas['creative'] += $response * 0.1;
            }
        }
        
        // Normalize scores
        $maxScore = max($interestAreas);
        if ($maxScore > 0) {
            foreach ($interestAreas as &$score) {
                $score = round(($score / $maxScore) * 100, 2);
            }
        }
        
        return [
            'interest_areas' => $interestAreas,
            'top_interests' => array_keys(array_slice(arsort($interestAreas) ? $interestAreas : [], 0, 3, true))
        ];
    }
    
    /**
     * Calculate skill-based scores
     */
    private function calculateSkillScores($assessment, $responses) {
        $skillCategories = [
            'technical' => 0,
            'analytical' => 0,
            'creative' => 0,
            'interpersonal' => 0,
            'leadership' => 0
        ];
        
        // Calculate based on responses
        foreach ($responses as $response) {
            if (is_numeric($response)) {
                $skillCategories['technical'] += $response * 0.25;
                $skillCategories['analytical'] += $response * 0.2;
                $skillCategories['interpersonal'] += $response * 0.15;
            }
        }
        
        return [
            'skill_categories' => $skillCategories,
            'skill_level' => 'intermediate' // This would be calculated based on responses
        ];
    }
    
    /**
     * Calculate personality scores
     */
    private function calculatePersonalityScores($assessment, $responses) {
        return [
            'personality_type' => 'analytical', // Simplified
            'work_style' => 'collaborative',
            'communication_style' => 'direct'
        ];
    }
    
    /**
     * Calculate value scores
     */
    private function calculateValueScores($assessment, $responses) {
        return [
            'work_values' => [
                'autonomy' => 75,
                'security' => 60,
                'growth' => 85,
                'impact' => 70
            ]
        ];
    }
    
    /**
     * Calculate comprehensive scores
     */
    private function calculateComprehensiveScores($assessment, $responses) {
        return array_merge(
            $this->calculateInterestScores($assessment, $responses),
            $this->calculateSkillScores($assessment, $responses),
            $this->calculatePersonalityScores($assessment, $responses),
            $this->calculateValueScores($assessment, $responses)
        );
    }
    
    /**
     * Generate career recommendations based on scores
     */
    private function generateRecommendations($scores) {
        // This is a simplified recommendation system
        // In a real system, this would use machine learning or more sophisticated algorithms
        
        $recommendations = [];
        
        if (isset($scores['interest_areas'])) {
            $topInterests = array_keys(array_slice(
                array_filter($scores['interest_areas'], function($score) { return $score > 60; }),
                0, 3, true
            ));
            
            // Map interests to career IDs (this would come from a more sophisticated system)
            $careerMapping = [
                'technology' => [1, 2, 3], // Software Developer, Data Scientist, etc.
                'healthcare' => [4, 5],
                'business' => [6, 7, 8],
                'creative' => [9, 10],
                'education' => [11, 12],
                'engineering' => [13, 14, 15]
            ];
            
            foreach ($topInterests as $interest) {
                if (isset($careerMapping[$interest])) {
                    $recommendations = array_merge($recommendations, $careerMapping[$interest]);
                }
            }
        }
        
        return array_unique(array_slice($recommendations, 0, 10));
    }
    
    /**
     * Get assessment statistics
     */
    public function getAssessmentStats($assessmentId = null) {
        $sql = "SELECT 
                    COUNT(*) as total_completions,
                    COUNT(DISTINCT user_id) as unique_users,
                    AVG(JSON_LENGTH(responses)) as avg_responses
                FROM user_assessment_results";
        
        $params = [];
        
        if ($assessmentId) {
            $sql .= " WHERE assessment_id = ?";
            $params[] = $assessmentId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}