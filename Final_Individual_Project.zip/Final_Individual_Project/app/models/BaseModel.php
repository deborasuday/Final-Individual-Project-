<?php
/**
 * Base Model Class
 * Provides common database functionality for all models
 */

abstract class BaseModel {
    protected $db;
    protected $table;
    protected $primaryKey = 'id';
    protected $fillable = [];
    protected $hidden = [];
    protected $casts = [];
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    /**
     * Find a record by ID
     */
    public function find($id) {
        $sql = "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $this->castAttributes($result) : null;
    }
    
    /**
     * Find all records with optional conditions
     */
    public function findAll($conditions = [], $orderBy = null, $limit = null) {
        $sql = "SELECT * FROM {$this->table}";
        $params = [];
        
        if (!empty($conditions)) {
            $whereClause = [];
            foreach ($conditions as $field => $value) {
                $whereClause[] = "{$field} = ?";
                $params[] = $value;
            }
            $sql .= " WHERE " . implode(' AND ', $whereClause);
        }
        
        if ($orderBy) {
            $sql .= " ORDER BY {$orderBy}";
        }
        
        if ($limit) {
            $sql .= " LIMIT {$limit}";
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return array_map([$this, 'castAttributes'], $results);
    }
    
    /**
     * Find first record matching conditions
     */
    public function findWhere($conditions) {
        $results = $this->findAll($conditions, null, 1);
        return !empty($results) ? $results[0] : null;
    }
    
    /**
     * Create a new record
     */
    public function create($data) {
        $data = $this->filterFillable($data);
        $data = $this->prepareForDatabase($data);
        
        $fields = array_keys($data);
        $placeholders = array_fill(0, count($fields), '?');
        
        $sql = "INSERT INTO {$this->table} (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $placeholders) . ")";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute(array_values($data));
        
        $id = $this->db->lastInsertId();
        return $this->find($id);
    }
    
    /**
     * Update a record by ID
     */
    public function update($id, $data) {
        $data = $this->filterFillable($data);
        $data = $this->prepareForDatabase($data);
        
        $fields = array_keys($data);
        $setClause = array_map(function($field) {
            return "{$field} = ?";
        }, $fields);
        
        $sql = "UPDATE {$this->table} SET " . implode(', ', $setClause) . " WHERE {$this->primaryKey} = ?";
        
        $params = array_values($data);
        $params[] = $id;
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        return $this->find($id);
    }
    
    /**
     * Delete a record by ID
     */
    public function delete($id) {
        $sql = "DELETE FROM {$this->table} WHERE {$this->primaryKey} = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$id]);
    }
    
    /**
     * Count records with optional conditions
     */
    public function count($conditions = []) {
        $sql = "SELECT COUNT(*) FROM {$this->table}";
        $params = [];
        
        if (!empty($conditions)) {
            $whereClause = [];
            foreach ($conditions as $field => $value) {
                $whereClause[] = "{$field} = ?";
                $params[] = $value;
            }
            $sql .= " WHERE " . implode(' AND ', $whereClause);
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        return (int) $stmt->fetchColumn();
    }
    
    /**
     * Check if a record exists
     */
    public function exists($conditions) {
        return $this->count($conditions) > 0;
    }
    
    /**
     * Filter data to only include fillable fields
     */
    protected function filterFillable($data) {
        if (empty($this->fillable)) {
            return $data;
        }
        
        return array_intersect_key($data, array_flip($this->fillable));
    }
    
    /**
     * Prepare data for database insertion/update
     */
    protected function prepareForDatabase($data) {
        foreach ($data as $key => $value) {
            if (isset($this->casts[$key])) {
                switch ($this->casts[$key]) {
                    case 'json':
                        $data[$key] = json_encode($value);
                        break;
                    case 'boolean':
                        $data[$key] = $value ? 1 : 0;
                        break;
                    case 'datetime':
                        if ($value instanceof DateTime) {
                            $data[$key] = $value->format('Y-m-d H:i:s');
                        }
                        break;
                }
            }
        }
        
        return $data;
    }
    
    /**
     * Cast attributes according to model definition
     */
    protected function castAttributes($data) {
        if (!$data) {
            return $data;
        }
        
        // Remove hidden fields
        foreach ($this->hidden as $field) {
            unset($data[$field]);
        }
        
        // Cast fields according to definition
        foreach ($this->casts as $field => $type) {
            if (isset($data[$field])) {
                switch ($type) {
                    case 'json':
                        $data[$field] = json_decode($data[$field], true);
                        break;
                    case 'boolean':
                        $data[$field] = (bool) $data[$field];
                        break;
                    case 'integer':
                        $data[$field] = (int) $data[$field];
                        break;
                    case 'float':
                        $data[$field] = (float) $data[$field];
                        break;
                    case 'datetime':
                        $data[$field] = new DateTime($data[$field]);
                        break;
                }
            }
        }
        
        return $data;
    }
    
    /**
     * Validate data before saving
     */
    public function validate($data) {
        $errors = [];
        
        // Override in child classes for specific validation
        return $errors;
    }
    
    /**
     * Execute raw SQL query
     */
    protected function query($sql, $params = []) {
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }
    
    /**
     * Begin database transaction
     */
    protected function beginTransaction() {
        return $this->db->beginTransaction();
    }
    
    /**
     * Commit database transaction
     */
    protected function commit() {
        return $this->db->commit();
    }
    
    /**
     * Rollback database transaction
     */
    protected function rollback() {
        return $this->db->rollback();
    }
}