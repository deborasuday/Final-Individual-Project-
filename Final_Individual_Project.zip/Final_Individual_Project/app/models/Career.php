<?php
/**
 * Career Model
 * Handles career pathway data and relationships
 */

require_once 'BaseModel.php';

class Career extends BaseModel {
    protected $table = 'careers';
    protected $fillable = [
        'title', 'slug', 'overview', 'industry_id', 'salary_range_min', 'salary_range_max',
        'job_outlook', 'education_requirements', 'work_environment', 'typical_hours',
        'travel_requirements', 'status', 'created_by'
    ];
    protected $casts = [
        'industry_id' => 'integer',
        'salary_range_min' => 'integer',
        'salary_range_max' => 'integer',
        'created_by' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime'
    ];
    
    /**
     * Get career with all related data
     */
    public function getCareerWithDetails($careerId) {
        $career = $this->find($careerId);
        
        if (!$career) {
            return null;
        }
        
        // Get industry information
        $career['industry'] = $this->getIndustry($career['industry_id']);
        
        // Get career stages
        $career['stages'] = $this->getCareerStages($careerId);
        
        // Get required skills
        $career['skills'] = $this->getCareerSkills($careerId);
        
        // Get learning resources
        $career['resources'] = $this->getCareerResources($careerId);
        
        // Get career stories
        $career['stories'] = $this->getCareerStories($careerId);
        
        return $career;
    }
    
    /**
     * Get published careers with basic information
     */
    public function getPublishedCareers($limit = null) {
        $sql = "SELECT c.*, i.name as industry_name, i.slug as industry_slug
                FROM {$this->table} c
                JOIN industries i ON c.industry_id = i.id
                WHERE c.status = 'published'
                ORDER BY c.title";
        
        if ($limit) {
            $sql .= " LIMIT {$limit}";
        }
        
        $stmt = $this->db->query($sql);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        return array_map([$this, 'castAttributes'], $results);
    }
    
    /**
     * Search careers by title, industry, or skills
     */
    public function searchCareers($query, $industryId = null, $filters = []) {
        $sql = "SELECT DISTINCT c.*, i.name as industry_name, i.slug as industry_slug
                FROM {$this->table} c
                JOIN industries i ON c.industry_id = i.id
                LEFT JOIN career_skills cs ON c.id = cs.career_id
                LEFT JOIN skills s ON cs.skill_id = s.id
                WHERE c.status = 'published'";
        
        $params = [];
        
        // Text search
        if (!empty($query)) {
            $sql .= " AND (c.title LIKE ? OR c.overview LIKE ? OR s.name LIKE ?)";
            $params[] = "%{$query}%";
            $params[] = "%{$query}%";
            $params[] = "%{$query}%";
        }
        
        // Industry filter
        if ($industryId) {
            $sql .= " AND c.industry_id = ?";
            $params[] = $industryId;
        }
        
        // Salary range filter
        if (isset($filters['min_salary'])) {
            $sql .= " AND c.salary_range_min >= ?";
            $params[] = $filters['min_salary'];
        }
        
        if (isset($filters['max_salary'])) {
            $sql .= " AND c.salary_range_max <= ?";
            $params[] = $filters['max_salary'];
        }
        
        // Job outlook filter
        if (isset($filters['job_outlook'])) {
            $sql .= " AND c.job_outlook = ?";
            $params[] = $filters['job_outlook'];
        }
        
        $sql .= " ORDER BY c.title";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return array_map([$this, 'castAttributes'], $results);
    }
    
    /**
     * Get career recommendations based on assessment results
     */
    public function getCareerRecommendations($assessmentResults, $limit = 10) {
        // This is a simplified recommendation algorithm
        // In a real system, this would be more sophisticated
        
        $skillMatches = $assessmentResults['skill_matches'] ?? [];
        $interestAreas = $assessmentResults['interest_areas'] ?? [];
        
        $sql = "SELECT c.*, i.name as industry_name,
                       COUNT(DISTINCT cs.skill_id) as skill_match_count,
                       AVG(cs.importance = 'critical') as critical_skill_ratio
                FROM {$this->table} c
                JOIN industries i ON c.industry_id = i.id
                LEFT JOIN career_skills cs ON c.id = cs.career_id
                WHERE c.status = 'published'";
        
        $params = [];
        
        if (!empty($skillMatches)) {
            $placeholders = str_repeat('?,', count($skillMatches) - 1) . '?';
            $sql .= " AND cs.skill_id IN ({$placeholders})";
            $params = array_merge($params, $skillMatches);
        }
        
        $sql .= " GROUP BY c.id
                  ORDER BY skill_match_count DESC, critical_skill_ratio DESC
                  LIMIT {$limit}";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return array_map([$this, 'castAttributes'], $results);
    }
    
    /**
     * Get career stages in order
     */
    public function getCareerStages($careerId) {
        $sql = "SELECT * FROM career_stages 
                WHERE career_id = ? 
                ORDER BY stage_order";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$careerId]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get career skills with proficiency levels
     */
    public function getCareerSkills($careerId) {
        $sql = "SELECT s.*, cs.proficiency_level, cs.importance, cs.stage_introduced
                FROM skills s
                JOIN career_skills cs ON s.id = cs.skill_id
                WHERE cs.career_id = ?
                ORDER BY cs.importance DESC, s.category, s.name";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$careerId]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get learning resources for career stages
     */
    public function getCareerResources($careerId) {
        $sql = "SELECT lr.*, csr.relevance_score, cs.stage_order, cs.title as stage_title
                FROM learning_resources lr
                JOIN career_stage_resources csr ON lr.id = csr.learning_resource_id
                JOIN career_stages cs ON csr.career_stage_id = cs.id
                WHERE cs.career_id = ? AND lr.status = 'published'
                ORDER BY cs.stage_order, csr.relevance_score DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$careerId]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get published career stories
     */
    public function getCareerStories($careerId, $limit = 5) {
        $sql = "SELECT * FROM career_stories 
                WHERE career_id = ? AND status = 'published'
                ORDER BY created_at DESC";
        
        if ($limit) {
            $sql .= " LIMIT {$limit}";
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$careerId]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get industry information
     */
    private function getIndustry($industryId) {
        $sql = "SELECT * FROM industries WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$industryId]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Create career with slug generation
     */
    public function createCareer($data) {
        // Generate slug from title
        if (empty($data['slug']) && !empty($data['title'])) {
            $data['slug'] = $this->generateSlug($data['title']);
        }
        
        // Validate career data
        $errors = $this->validateCareerData($data);
        if (!empty($errors)) {
            throw new InvalidArgumentException('Validation failed: ' . implode(', ', $errors));
        }
        
        return $this->create($data);
    }
    
    /**
     * Generate unique slug from title
     */
    private function generateSlug($title) {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        $originalSlug = $slug;
        $counter = 1;
        
        while ($this->findWhere(['slug' => $slug])) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }
    
    /**
     * Validate career data
     */
    public function validateCareerData($data) {
        $errors = [];
        
        if (empty($data['title'])) {
            $errors[] = 'Title is required';
        }
        
        if (empty($data['overview'])) {
            $errors[] = 'Overview is required';
        }
        
        if (empty($data['industry_id'])) {
            $errors[] = 'Industry is required';
        }
        
        if (isset($data['salary_range_min']) && isset($data['salary_range_max'])) {
            if ($data['salary_range_min'] > $data['salary_range_max']) {
                $errors[] = 'Minimum salary cannot be greater than maximum salary';
            }
        }
        
        $validOutlooks = ['declining', 'stable', 'growing', 'rapidly_growing'];
        if (isset($data['job_outlook']) && !in_array($data['job_outlook'], $validOutlooks)) {
            $errors[] = 'Invalid job outlook specified';
        }
        
        $validStatuses = ['draft', 'published', 'archived'];
        if (isset($data['status']) && !in_array($data['status'], $validStatuses)) {
            $errors[] = 'Invalid status specified';
        }
        
        return $errors;
    }
    
    /**
     * Get career statistics
     */
    public function getCareerStats() {
        $sql = "SELECT 
                    COUNT(*) as total_careers,
                    SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END) as published_careers,
                    SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) as draft_careers,
                    COUNT(DISTINCT industry_id) as industries_covered,
                    AVG(salary_range_max - salary_range_min) as avg_salary_range
                FROM {$this->table}";
        
        $stmt = $this->db->query($sql);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}