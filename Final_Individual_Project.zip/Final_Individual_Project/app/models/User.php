<?php
/**
 * User Model
 * Handles user authentication and profile management
 */

require_once 'BaseModel.php';

class User extends BaseModel {
    protected $table = 'users';
    protected $fillable = [
        'email', 'password_hash', 'role', 'first_name', 'last_name', 
        'verified', 'verification_token', 'password_reset_token', 'password_reset_expires'
    ];
    protected $hidden = ['password_hash', 'verification_token', 'password_reset_token'];
    protected $casts = [
        'verified' => 'boolean',
        'password_reset_expires' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'last_login' => 'datetime'
    ];
    
    /**
     * Create a new user with hashed password
     */
    public function createUser($data) {
        // Validate required fields
        $errors = $this->validateUserData($data);
        if (!empty($errors)) {
            throw new InvalidArgumentException('Validation failed: ' . implode(', ', $errors));
        }
        
        // Hash password
        if (isset($data['password'])) {
            $data['password_hash'] = password_hash($data['password'], PASSWORD_DEFAULT);
            unset($data['password']);
        }
        
        // Generate verification token
        $data['verification_token'] = bin2hex(random_bytes(32));
        
        return $this->create($data);
    }
    
    /**
     * Find user by email
     */
    public function findByEmail($email) {
        return $this->findWhere(['email' => $email]);
    }
    
    /**
     * Verify user password
     */
    public function verifyPassword($user, $password) {
        if (!$user || !isset($user['password_hash'])) {
            return false;
        }
        
        return password_verify($password, $user['password_hash']);
    }
    
    /**
     * Update user's last login timestamp
     */
    public function updateLastLogin($userId) {
        $sql = "UPDATE {$this->table} SET last_login = NOW() WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$userId]);
    }
    
    /**
     * Verify user account
     */
    public function verifyAccount($token) {
        $user = $this->findWhere(['verification_token' => $token]);
        
        if (!$user) {
            return false;
        }
        
        return $this->update($user['id'], [
            'verified' => true,
            'verification_token' => null
        ]);
    }
    
    /**
     * Generate password reset token
     */
    public function generatePasswordResetToken($email) {
        $user = $this->findByEmail($email);
        
        if (!$user) {
            return false;
        }
        
        $token = bin2hex(random_bytes(32));
        $expires = new DateTime('+1 hour');
        
        $this->update($user['id'], [
            'password_reset_token' => $token,
            'password_reset_expires' => $expires
        ]);
        
        return $token;
    }
    
    /**
     * Reset password using token
     */
    public function resetPassword($token, $newPassword) {
        $user = $this->findWhere(['password_reset_token' => $token]);
        
        if (!$user) {
            return false;
        }
        
        // Check if token is expired
        $expires = new DateTime($user['password_reset_expires']);
        if ($expires < new DateTime()) {
            return false;
        }
        
        $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
        
        return $this->update($user['id'], [
            'password_hash' => $passwordHash,
            'password_reset_token' => null,
            'password_reset_expires' => null
        ]);
    }
    
    /**
     * Change user password
     */
    public function changePassword($userId, $currentPassword, $newPassword) {
        $user = $this->find($userId);
        
        if (!$user) {
            return false;
        }
        
        // Verify current password
        if (!$this->verifyPassword($user, $currentPassword)) {
            return false;
        }
        
        $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
        
        return $this->update($userId, ['password_hash' => $passwordHash]);
    }
    
    /**
     * Update user role
     */
    public function updateRole($userId, $newRole) {
        $validRoles = ['general_user', 'contributor', 'administrator'];
        
        if (!in_array($newRole, $validRoles)) {
            throw new InvalidArgumentException('Invalid role specified');
        }
        
        return $this->update($userId, ['role' => $newRole]);
    }
    
    /**
     * Get user profile with extended information
     */
    public function getUserWithProfile($userId) {
        $sql = "SELECT u.*, p.bio, p.location, p.website, p.linkedin_url, p.github_url, 
                       p.experience_level, p.current_job_title, p.current_company
                FROM users u
                LEFT JOIN user_profiles p ON u.id = p.user_id
                WHERE u.id = ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$userId]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $this->castAttributes($result) : null;
    }
    
    /**
     * Get users by role
     */
    public function getUsersByRole($role) {
        return $this->findAll(['role' => $role], 'created_at DESC');
    }
    
    /**
     * Search users
     */
    public function searchUsers($query, $role = null) {
        $sql = "SELECT * FROM {$this->table} WHERE 
                (first_name LIKE ? OR last_name LIKE ? OR email LIKE ?)";
        $params = ["%{$query}%", "%{$query}%", "%{$query}%"];
        
        if ($role) {
            $sql .= " AND role = ?";
            $params[] = $role;
        }
        
        $sql .= " ORDER BY first_name, last_name";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return array_map([$this, 'castAttributes'], $results);
    }
    
    /**
     * Validate user data
     */
    public function validateUserData($data) {
        $errors = [];
        
        // Email validation
        if (empty($data['email'])) {
            $errors[] = 'Email is required';
        } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Invalid email format';
        } elseif ($this->findByEmail($data['email'])) {
            $errors[] = 'Email already exists';
        }
        
        // Password validation
        if (isset($data['password'])) {
            if (empty($data['password'])) {
                $errors[] = 'Password is required';
            } elseif (strlen($data['password']) < PASSWORD_MIN_LENGTH) {
                $errors[] = 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters long';
            }
        }
        
        // Name validation
        if (empty($data['first_name'])) {
            $errors[] = 'First name is required';
        }
        
        if (empty($data['last_name'])) {
            $errors[] = 'Last name is required';
        }
        
        // Role validation
        if (isset($data['role'])) {
            $validRoles = ['general_user', 'contributor', 'administrator'];
            if (!in_array($data['role'], $validRoles)) {
                $errors[] = 'Invalid role specified';
            }
        }
        
        return $errors;
    }
    
    /**
     * Get user statistics
     */
    public function getUserStats() {
        $sql = "SELECT 
                    COUNT(*) as total_users,
                    SUM(CASE WHEN role = 'general_user' THEN 1 ELSE 0 END) as general_users,
                    SUM(CASE WHEN role = 'contributor' THEN 1 ELSE 0 END) as contributors,
                    SUM(CASE WHEN role = 'administrator' THEN 1 ELSE 0 END) as administrators,
                    SUM(CASE WHEN verified = 1 THEN 1 ELSE 0 END) as verified_users,
                    SUM(CASE WHEN last_login >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) as active_users
                FROM {$this->table}";
        
        $stmt = $this->db->query($sql);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}