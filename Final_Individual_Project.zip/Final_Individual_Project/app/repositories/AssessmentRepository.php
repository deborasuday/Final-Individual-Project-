<?php
/**
 * Assessment Repository
 * Handles database operations for career assessments
 */

require_once 'BaseRepository.php';

class AssessmentRepository extends BaseRepository {
    protected $table = 'user_assessment_results';
    
    /**
     * Save assessment results
     */
    public function saveAssessment($userId, $assessmentData) {
        // For now, we'll use assessment_id = 1 (comprehensive assessment)
        // In a full implementation, this would be dynamic
        $responses = [
            'skills' => $assessmentData['skills'],
            'interests' => $assessmentData['interests']
        ];
        
        $data = [
            'user_id' => $userId,
            'assessment_id' => 1, // Default comprehensive assessment
            'responses' => json_encode($responses),
            'calculated_scores' => json_encode([]), // Will be calculated later
            'recommended_careers' => json_encode([]), // Will be calculated later
            'completed_at' => date('Y-m-d H:i:s')
        ];
        
        return $this->create($data);
    }
    
    /**
     * Get user's latest assessment
     */
    public function getLatestAssessment($userId) {
        $sql = "
            SELECT * FROM {$this->table} 
            WHERE user_id = ? 
            ORDER BY completed_at DESC 
            LIMIT 1
        ";
        
        $stmt = $this->query($sql, [$userId]);
        $assessment = $stmt->fetch();
        
        if ($assessment) {
            $responses = json_decode($assessment['responses'], true);
            $assessment['skill_responses'] = $responses['skills'] ?? [];
            $assessment['interest_responses'] = $responses['interests'] ?? [];
        }
        
        return $assessment;
    }
    
    /**
     * Get all assessments for a user
     */
    public function getUserAssessments($userId) {
        $assessments = $this->findAll(['user_id' => $userId], 'completed_at DESC');
        
        foreach ($assessments as &$assessment) {
            $responses = json_decode($assessment['responses'], true);
            $assessment['skill_responses'] = $responses['skills'] ?? [];
            $assessment['interest_responses'] = $responses['interests'] ?? [];
        }
        
        return $assessments;
    }
    
    /**
     * Calculate career matches based on assessment
     */
    public function calculateCareerMatches($assessmentId) {
        $assessment = $this->findById($assessmentId);
        
        if (!$assessment) {
            return [];
        }
        
        $responses = json_decode($assessment['responses'], true);
        $skillResponses = $responses['skills'] ?? [];
        $interestResponses = $responses['interests'] ?? [];
        
        // Get user's strong skills (rated 4 or 5)
        $strongSkills = [];
        foreach ($skillResponses as $skillId => $rating) {
            if ($rating >= 4) {
                $strongSkills[] = $skillId;
            }
        }
        
        // Get user's high interests (rated 4 or 5)
        $highInterests = [];
        foreach ($interestResponses as $interest => $rating) {
            if ($rating >= 4) {
                $highInterests[] = $interest;
            }
        }
        
        // Get all careers for matching
        $careerRepo = new CareerRepository();
        $allCareers = $careerRepo->findAll([], 'title ASC');
        $matches = [];
        
        foreach ($allCareers as $career) {
            $matchScore = $this->calculateMatchScore($career, $strongSkills, $highInterests);
            if ($matchScore > 0) {
                $matches[] = [
                    'career' => $career,
                    'match_score' => $matchScore,
                    'skill_matches' => count($strongSkills),
                    'interest_matches' => count($highInterests)
                ];
            }
        }
        
        // Sort by match score
        usort($matches, function($a, $b) {
            return $b['match_score'] <=> $a['match_score'];
        });
        
        return array_slice($matches, 0, 10);
    }
    
    /**
     * Calculate match score for a career
     */
    private function calculateMatchScore($career, $userSkills, $userInterests) {
        // Calculate skill match percentage (0-60 points, representing 60% of total)
        $skillMatchPercentage = $this->calculateSkillMatch($career, $userSkills);
        
        // Calculate interest match percentage (0-40 points, representing 40% of total)
        $interestMatchPercentage = $this->calculateInterestMatch($career, $userInterests);
        
        // Total score is sum of both components (max 100%)
        $totalScore = $skillMatchPercentage + $interestMatchPercentage;
        
        return round(min($totalScore, 100), 2); // Ensure maximum is exactly 100%
    }
    
    /**
     * Calculate skill match component (max 60 points)
     */
    private function calculateSkillMatch($career, $userSkills) {
        if (empty($userSkills)) {
            return 0;
        }
        
        $careerTitle = strtolower($career['title']);
        $careerDescription = strtolower($career['description'] ?? '');
        
        // Skill keywords mapping
        $skillKeywords = [
            1 => ['programming', 'coding', 'software', 'development'],
            2 => ['data', 'analysis', 'analytics', 'statistics'],
            3 => ['project', 'management', 'planning'],
            4 => ['communication', 'writing', 'presentation'],
            5 => ['leadership', 'management', 'team'],
            6 => ['problem', 'solving', 'troubleshooting'],
            7 => ['design', 'creative', 'art', 'visual'],
            8 => ['sales', 'marketing', 'business'],
            9 => ['finance', 'accounting', 'financial'],
            10 => ['research', 'analysis', 'investigation']
        ];
        
        $matchedSkills = 0;
        $totalUserSkills = count($userSkills);
        
        foreach ($userSkills as $skillId) {
            if (isset($skillKeywords[$skillId])) {
                foreach ($skillKeywords[$skillId] as $keyword) {
                    if (strpos($careerTitle, $keyword) !== false || strpos($careerDescription, $keyword) !== false) {
                        $matchedSkills++;
                        break;
                    }
                }
            }
        }
        
        // Calculate percentage of skills matched, then scale to 60 points max
        $skillMatchRatio = $totalUserSkills > 0 ? ($matchedSkills / $totalUserSkills) : 0;
        return $skillMatchRatio * 60; // 60% of total score
    }
    
    /**
     * Calculate interest match component (max 40 points)
     */
    private function calculateInterestMatch($career, $userInterests) {
        if (empty($userInterests)) {
            return 0;
        }
        
        $careerTitle = strtolower($career['title']);
        $careerDescription = strtolower($career['description'] ?? '');
        $careerIndustry = strtolower($career['industry'] ?? '');
        
        // Interest keywords mapping
        $interestKeywords = [
            'technology' => ['technology', 'tech', 'software', 'computer'],
            'healthcare' => ['health', 'medical', 'care', 'medicine'],
            'education' => ['education', 'teaching', 'training'],
            'business' => ['business', 'management', 'corporate'],
            'creative' => ['creative', 'design', 'art', 'media'],
            'science' => ['science', 'research', 'laboratory'],
            'finance' => ['finance', 'financial', 'banking', 'investment'],
            'social_service' => ['social', 'community', 'service', 'nonprofit'],
            'engineering' => ['engineering', 'technical', 'construction'],
            'sales' => ['sales', 'marketing', 'retail'],
            'law' => ['law', 'legal', 'attorney', 'justice'],
            'media' => ['media', 'journalism', 'communication', 'broadcasting']
        ];
        
        $matchedInterests = 0;
        $totalUserInterests = count($userInterests);
        
        foreach ($userInterests as $interest) {
            if (isset($interestKeywords[$interest])) {
                foreach ($interestKeywords[$interest] as $keyword) {
                    if (strpos($careerTitle, $keyword) !== false || 
                        strpos($careerDescription, $keyword) !== false || 
                        strpos($careerIndustry, $keyword) !== false) {
                        $matchedInterests++;
                        break;
                    }
                }
            }
        }
        
        // Calculate percentage of interests matched, then scale to 40 points max
        $interestMatchRatio = $totalUserInterests > 0 ? ($matchedInterests / $totalUserInterests) : 0;
        return $interestMatchRatio * 40; // 40% of total score
    }
    
    /**
     * Get assessment statistics
     */
    public function getAssessmentStats() {
        $sql = "
            SELECT 
                COUNT(*) as total_assessments,
                COUNT(DISTINCT user_id) as unique_users,
                AVG(JSON_LENGTH(responses)) as avg_responses_length,
                DATE(completed_at) as assessment_date,
                COUNT(*) as daily_count
            FROM {$this->table}
            WHERE completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY DATE(completed_at)
            ORDER BY assessment_date DESC
        ";
        
        $stmt = $this->query($sql);
        return $stmt->fetchAll();
    }
    
    /**
     * Get skill distribution from assessments
     */
    public function getSkillDistribution() {
        $sql = "SELECT responses FROM {$this->table}";
        $stmt = $this->query($sql);
        $assessments = $stmt->fetchAll();
        
        $skillCounts = [];
        
        foreach ($assessments as $assessment) {
            $responses = json_decode($assessment['responses'], true);
            $skills = $responses['skills'] ?? [];
            
            foreach ($skills as $skillId => $rating) {
                if ($rating >= 4) { // Only count high ratings
                    $skillCounts[$skillId] = ($skillCounts[$skillId] ?? 0) + 1;
                }
            }
        }
        
        arsort($skillCounts);
        return $skillCounts;
    }
}