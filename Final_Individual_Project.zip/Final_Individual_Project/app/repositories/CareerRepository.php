<?php
/**
 * Career Repository
 * Handles database operations for careers and related data
 */

require_once 'BaseRepository.php';

class CareerRepository extends BaseRepository {
    protected $table = 'careers';
    
    /**
     * Override findAll to include industry information
     */
    public function findAll($conditions = [], $orderBy = 'id', $limit = null) {
        // First check if industries table exists and has data
        try {
            $checkStmt = $this->query("SELECT COUNT(*) as count FROM industries");
            $industriesExist = $checkStmt->fetch()['count'] > 0;
        } catch (Exception $e) {
            $industriesExist = false;
        }
        
        if ($industriesExist) {
            // Use proper join with industries table
            $sql = "
                SELECT c.*, i.name as industry 
                FROM {$this->table} c 
                LEFT JOIN industries i ON c.industry_id = i.id
            ";
        } else {
            // Fallback: check if careers table has direct industry field
            try {
                $checkStmt = $this->query("SHOW COLUMNS FROM {$this->table} LIKE 'industry'");
                $hasIndustryField = $checkStmt->fetch() !== false;
                
                if ($hasIndustryField) {
                    $sql = "SELECT c.*, c.industry FROM {$this->table} c";
                } else {
                    // No industry field, add placeholder
                    $sql = "SELECT c.*, 'General' as industry FROM {$this->table} c";
                }
            } catch (Exception $e) {
                $sql = "SELECT c.*, 'General' as industry FROM {$this->table} c";
            }
        }
        
        $params = [];
        
        if (!empty($conditions)) {
            $whereClause = [];
            foreach ($conditions as $field => $value) {
                $whereClause[] = "c.{$field} = ?";
                $params[] = $value;
            }
            $sql .= " WHERE " . implode(' AND ', $whereClause);
        }
        
        if ($orderBy) {
            $sql .= " ORDER BY " . $orderBy;
        }
        
        if ($limit) {
            $sql .= " LIMIT " . $limit;
        }
        
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    /**
     * Override findById to include industry information
     */
    public function findById($id) {
        // First check if industries table exists and has data
        try {
            $checkStmt = $this->query("SELECT COUNT(*) as count FROM industries");
            $industriesExist = $checkStmt->fetch()['count'] > 0;
        } catch (Exception $e) {
            $industriesExist = false;
        }
        
        if ($industriesExist) {
            // Use proper join with industries table
            $sql = "
                SELECT c.*, i.name as industry 
                FROM {$this->table} c 
                LEFT JOIN industries i ON c.industry_id = i.id 
                WHERE c.id = ?
            ";
        } else {
            // Fallback: check if careers table has direct industry field
            try {
                $checkStmt = $this->query("SHOW COLUMNS FROM {$this->table} LIKE 'industry'");
                $hasIndustryField = $checkStmt->fetch() !== false;
                
                if ($hasIndustryField) {
                    $sql = "SELECT c.*, c.industry FROM {$this->table} c WHERE c.id = ?";
                } else {
                    // No industry field, add placeholder
                    $sql = "SELECT c.*, 'General' as industry FROM {$this->table} c WHERE c.id = ?";
                }
            } catch (Exception $e) {
                $sql = "SELECT c.*, 'General' as industry FROM {$this->table} c WHERE c.id = ?";
            }
        }
        
        $stmt = $this->query($sql, [$id]);
        return $stmt->fetch();
    }
    
    /**
     * Get career with all related data (stages, skills, resources)
     */
    public function getCareerWithDetails($careerId) {
        $career = $this->findById($careerId);
        
        if (!$career) {
            return null;
        }
        
        // Get career stages
        $career['stages'] = $this->getCareerStages($careerId);
        
        // Get required skills
        $career['skills'] = $this->getCareerSkills($careerId);
        
        // Get learning resources
        $career['resources'] = $this->getCareerResources($careerId);
        
        return $career;
    }
    
    /**
     * Get career stages ordered by sequence
     */
    public function getCareerStages($careerId) {
        $sql = "
            SELECT * FROM career_stages 
            WHERE career_id = ? 
            ORDER BY stage_order ASC
        ";
        
        $stmt = $this->query($sql, [$careerId]);
        return $stmt->fetchAll();
    }
    
    /**
     * Get career skills with proficiency levels
     */
    public function getCareerSkills($careerId) {
        $sql = "
            SELECT s.*, cs.proficiency_level 
            FROM skills s
            JOIN career_skills cs ON s.id = cs.skill_id
            WHERE cs.career_id = ?
            ORDER BY s.category, s.name
        ";
        
        $stmt = $this->query($sql, [$careerId]);
        return $stmt->fetchAll();
    }
    
    /**
     * Get learning resources for a career
     */
    public function getCareerResources($careerId) {
        $sql = "
            SELECT * FROM learning_resources 
            WHERE career_id = ? 
            ORDER BY resource_type, title
        ";
        
        $stmt = $this->query($sql, [$careerId]);
        return $stmt->fetchAll();
    }
    
    /**
     * Search careers by title, industry, or skills
     */
    public function searchCareers($searchTerm, $industry = null, $limit = 20) {
        $sql = "
            SELECT DISTINCT c.* 
            FROM careers c
            LEFT JOIN career_skills cs ON c.id = cs.career_id
            LEFT JOIN skills s ON cs.skill_id = s.id
            WHERE (c.title LIKE ? OR c.overview LIKE ? OR s.name LIKE ?)
        ";
        
        $params = ["%{$searchTerm}%", "%{$searchTerm}%", "%{$searchTerm}%"];
        
        if ($industry) {
            $sql .= " AND c.industry = ?";
            $params[] = $industry;
        }
        
        $sql .= " ORDER BY c.title LIMIT ?";
        $params[] = $limit;
        
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    /**
     * Get careers by industry
     */
    public function getCareersByIndustry($industry) {
        return $this->findAll(['industry' => $industry], 'title');
    }
    
    /**
     * Get all industries
     */
    public function getAllIndustries() {
        $sql = "SELECT DISTINCT industry FROM {$this->table} ORDER BY industry";
        $stmt = $this->query($sql);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    /**
     * Get career recommendations based on skills
     */
    public function getCareerRecommendations($userSkills, $limit = 10) {
        if (empty($userSkills)) {
            return [];
        }
        
        $skillPlaceholders = str_repeat('?,', count($userSkills) - 1) . '?';
        
        $sql = "
            SELECT c.*, COUNT(cs.skill_id) as skill_matches
            FROM careers c
            JOIN career_skills cs ON c.id = cs.career_id
            WHERE cs.skill_id IN ({$skillPlaceholders})
            GROUP BY c.id
            ORDER BY skill_matches DESC, c.title
            LIMIT ?
        ";
        
        $params = array_merge($userSkills, [$limit]);
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    /**
     * Get popular careers (most viewed/saved)
     */
    public function getPopularCareers($limit = 10) {
        $sql = "
            SELECT c.*, COUNT(up.career_id) as save_count
            FROM careers c
            LEFT JOIN user_preferences up ON c.id = up.career_id
            GROUP BY c.id
            ORDER BY save_count DESC, c.title
            LIMIT ?
        ";
        
        $stmt = $this->query($sql, [$limit]);
        return $stmt->fetchAll();
    }
    
    /**
     * Add career stage
     */
    public function addCareerStage($careerId, $stageData) {
        $stageData['career_id'] = $careerId;
        
        $sql = "INSERT INTO career_stages (career_id, stage_order, title, description, estimated_duration) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->query($sql, [
            $stageData['career_id'],
            $stageData['stage_order'],
            $stageData['title'],
            $stageData['description'],
            $stageData['estimated_duration']
        ]);
        
        return $this->db->lastInsertId();
    }
    
    /**
     * Add skill requirement to career
     */
    public function addCareerSkill($careerId, $skillId, $proficiencyLevel) {
        $sql = "INSERT INTO career_skills (career_id, skill_id, proficiency_level) VALUES (?, ?, ?)";
        $stmt = $this->query($sql, [$careerId, $skillId, $proficiencyLevel]);
        return $stmt->rowCount() > 0;
    }
    
    /**
     * Add learning resource to career
     */
    public function addLearningResource($careerId, $resourceData) {
        $resourceData['career_id'] = $careerId;
        
        $sql = "INSERT INTO learning_resources (career_id, title, description, url, resource_type) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->query($sql, [
            $resourceData['career_id'],
            $resourceData['title'],
            $resourceData['description'],
            $resourceData['url'],
            $resourceData['resource_type']
        ]);
        
        return $this->db->lastInsertId();
    }
    
    /**
     * Get all careers
     */
    public function getAllCareers() {
        return $this->findAll([], 'title');
    }
    
    /**
     * Get career by ID
     */
    public function getCareerById($careerId) {
        return $this->findById($careerId);
    }
    
    /**
     * Create a new career
     */
    public function createCareer($careerData) {
        $sql = "INSERT INTO careers (title, description, category, salary_range, education_level, industry, overview) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->query($sql, [
            $careerData['title'],
            $careerData['description'] ?? '',
            $careerData['category'] ?? 'General',
            $careerData['salary_range'] ?? '',
            $careerData['education_level'] ?? '',
            $careerData['category'] ?? 'General',
            $careerData['description'] ?? ''
        ]);
        
        return $this->db->lastInsertId();
    }
    
    /**
     * Delete a career
     */
    public function deleteCareer($careerId) {
        return $this->delete($careerId);
    }
}