<?php
/**
 * User Repository
 * Handles database operations for users
 */

require_once 'BaseRepository.php';

class UserRepository extends BaseRepository {
    protected $table = 'users';
    
    /**
     * Find user by email
     */
    public function findByEmail($email) {
        return $this->findOne(['email' => $email]);
    }
    
    /**
     * Create new user with password hashing
     */
    public function createUser($userData) {
        // Hash password before storing
        if (isset($userData['password'])) {
            $userData['password_hash'] = password_hash($userData['password'], PASSWORD_DEFAULT);
            unset($userData['password']);
        }
        
        // Set default values with proper types
        $userData['created_at'] = date('Y-m-d H:i:s');
        $userData['verified'] = 0; // Use integer instead of boolean
        
        // Ensure role is set
        if (!isset($userData['role']) || empty($userData['role'])) {
            $userData['role'] = 'general_user';
        }
        
        return $this->create($userData);
    }
    
    /**
     * Verify user password
     */
    public function verifyPassword($email, $password) {
        $user = $this->findByEmail($email);
        
        if ($user && password_verify($password, $user['password_hash'])) {
            return $user;
        }
        
        return false;
    }
    
    /**
     * Update user password
     */
    public function updatePassword($userId, $newPassword) {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        return $this->update($userId, ['password_hash' => $hashedPassword]);
    }
    
    /**
     * Verify user account
     */
    public function verifyUser($userId) {
        return $this->update($userId, ['verified' => 1]);
    }
    
    /**
     * Get users by role
     */
    public function findByRole($role) {
        return $this->findAll(['role' => $role]);
    }
    
    /**
     * Update user role
     */
    public function updateRole($userId, $role) {
        return $this->update($userId, ['role' => $role]);
    }
    
    /**
     * Get user statistics
     */
    public function getUserStats() {
        $sql = "
            SELECT 
                role,
                COUNT(*) as count,
                COUNT(CASE WHEN verified = 1 THEN 1 END) as verified_count
            FROM {$this->table} 
            GROUP BY role
        ";
        
        $stmt = $this->query($sql);
        return $stmt->fetchAll();
    }
    
    /**
     * Search users by email or name
     */
    public function searchUsers($searchTerm, $limit = 20) {
        $sql = "
            SELECT id, email, role, verified, created_at 
            FROM {$this->table} 
            WHERE email LIKE ? OR first_name LIKE ? OR last_name LIKE ?
            ORDER BY created_at DESC 
            LIMIT ?
        ";
        
        $searchPattern = "%{$searchTerm}%";
        $stmt = $this->query($sql, [$searchPattern, $searchPattern, $searchPattern, $limit]);
        return $stmt->fetchAll();
    }
    
    /**
     * Get recent users
     */
    public function getRecentUsers($limit = 10) {
        return $this->findAll([], 'created_at DESC', $limit);
    }
    
    /**
     * Update last login time
     */
    public function updateLastLogin($userId) {
        return $this->update($userId, ['last_login' => date('Y-m-d H:i:s')]);
    }
}