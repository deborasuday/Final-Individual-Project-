<?php

require_once APP_PATH . '/repositories/AssessmentRepository.php';
require_once APP_PATH . '/repositories/CareerRepository.php';

class AssessmentService {
    private $db;
    private $assessmentRepository;
    private $careerRepository;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->assessmentRepository = new AssessmentRepository();
        $this->careerRepository = new CareerRepository();
    }
    
    public function getAssessmentQuestions() {
        return [
            'skills' => $this->getSkillQuestions(),
            'interests' => $this->getInterestQuestions()
        ];
    }
    
    /**
     * Get user assessment history
     */
    public function getUserAssessmentHistory($userId) {
        try {
            $assessments = $this->assessmentRepository->getUserAssessments($userId);
            return $assessments;
        } catch (Exception $e) {
            error_log("Error getting assessment history: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Process and save assessment results
     */
    public function processAssessment($userId, $responses) {
        try {
            // Validate responses
            $validation = $this->validateAssessmentResponses($responses);
            if (!$validation['valid']) {
                return ['success' => false, 'errors' => $validation['errors']];
            }
            
            // Save assessment to database
            $assessmentId = $this->assessmentRepository->saveAssessment($userId, $responses);
            
            if (!$assessmentId) {
                return ['success' => false, 'error' => 'Failed to save assessment'];
            }
            
            // Calculate career matches
            $matches = $this->assessmentRepository->calculateCareerMatches($assessmentId);
            
            // Generate insights
            $insights = $this->generateAssessmentInsights($responses, $matches);
            
            return [
                'success' => true,
                'assessment_id' => $assessmentId,
                'matches' => $matches,
                'insights' => $insights
            ];
        } catch (Exception $e) {
            error_log("Error processing assessment: " . $e->getMessage());
            return ['success' => false, 'error' => 'An error occurred while processing your assessment'];
        }
    }
    
    /**
     * Get assessment results with detailed analysis
     */
    public function getAssessmentResults($assessmentId) {
        try {
            $assessment = $this->assessmentRepository->findById($assessmentId);
            
            if (!$assessment) {
                return null;
            }
            
            // Decode JSON responses from the responses column
            $responses = json_decode($assessment['responses'] ?? '{}', true);
            $skillResponses = $responses['skills'] ?? [];
            $interestResponses = $responses['interests'] ?? [];
            
            // Get career matches
            $matches = $this->assessmentRepository->calculateCareerMatches($assessmentId);
            
            // Generate detailed analysis
            $analysis = [
                'assessment' => $assessment,
                'career_matches' => $matches,
                'skill_strengths' => $this->identifySkillStrengths($skillResponses),
                'skill_gaps' => $this->identifySkillGaps($skillResponses),
                'interest_profile' => $this->analyzeInterestProfile($interestResponses),
                'recommendations' => $this->generateRecommendations($assessment, $matches)
            ];
            
            return $analysis;
        } catch (Exception $e) {
            error_log("Error getting assessment results: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Get skill questions for assessment
     */
    private function getSkillQuestions() {
        // In production, this would come from a database
        return [
            1 => ['name' => 'Programming/Coding', 'category' => 'technical'],
            2 => ['name' => 'Data Analysis', 'category' => 'technical'],
            3 => ['name' => 'Project Management', 'category' => 'soft'],
            4 => ['name' => 'Communication', 'category' => 'soft'],
            5 => ['name' => 'Leadership', 'category' => 'soft'],
            6 => ['name' => 'Problem Solving', 'category' => 'soft'],
            7 => ['name' => 'Creative Design', 'category' => 'technical'],
            8 => ['name' => 'Sales & Marketing', 'category' => 'soft'],
            9 => ['name' => 'Financial Analysis', 'category' => 'technical'],
            10 => ['name' => 'Research & Analysis', 'category' => 'technical'],
            11 => ['name' => 'Teaching/Training', 'category' => 'soft'],
            12 => ['name' => 'Customer Service', 'category' => 'soft'],
            13 => ['name' => 'Technical Writing', 'category' => 'technical'],
            14 => ['name' => 'Team Collaboration', 'category' => 'soft'],
            15 => ['name' => 'Strategic Planning', 'category' => 'soft']
        ];
    }
    
    /**
     * Get interest questions for assessment
     */
    private function getInterestQuestions() {
        return [
            'technology' => 'Working with computers, software, and digital systems',
            'healthcare' => 'Helping people with health and medical needs',
            'education' => 'Teaching, training, and developing others',
            'business' => 'Managing operations, strategy, and growth',
            'creative' => 'Artistic expression, design, and creative projects',
            'science' => 'Research, experimentation, and scientific discovery',
            'finance' => 'Managing money, investments, and financial planning',
            'social_service' => 'Helping communities and social causes',
            'engineering' => 'Building, designing, and solving technical problems',
            'sales' => 'Persuading, selling, and building relationships',
            'law' => 'Legal systems, justice, and advocacy',
            'media' => 'Communication, journalism, and content creation'
        ];
    }
    
    /**
     * Validate assessment responses
     */
    private function validateAssessmentResponses($responses) {
        $errors = [];
        
        // Check skills responses
        if (empty($responses['skills']) || !is_array($responses['skills'])) {
            $errors['skills'] = 'Skills assessment is required';
        } else {
            foreach ($responses['skills'] as $skillId => $rating) {
                if (!is_numeric($rating) || $rating < 1 || $rating > 5) {
                    $errors['skills'] = 'Invalid skill rating';
                    break;
                }
            }
        }
        
        // Check interests responses
        if (empty($responses['interests']) || !is_array($responses['interests'])) {
            $errors['interests'] = 'Interest assessment is required';
        } else {
            foreach ($responses['interests'] as $interest => $rating) {
                if (!is_numeric($rating) || $rating < 1 || $rating > 5) {
                    $errors['interests'] = 'Invalid interest rating';
                    break;
                }
            }
        }
        
        return ['valid' => empty($errors), 'errors' => $errors];
    }
    
    /**
     * Generate assessment insights
     */
    private function generateAssessmentInsights($responses, $matches) {
        $insights = [];
        
        // Skill insights
        $skillStrengths = $this->identifySkillStrengths($responses['skills']);
        if (!empty($skillStrengths)) {
            $insights[] = "Your strongest skills are in " . implode(', ', array_slice($skillStrengths, 0, 3));
        }
        
        // Interest insights
        $topInterests = $this->getTopInterests($responses['interests']);
        if (!empty($topInterests)) {
            $insights[] = "You show high interest in " . implode(' and ', array_slice($topInterests, 0, 2));
        }
        
        // Career match insights
        if (!empty($matches)) {
            $topMatch = $matches[0];
            $insights[] = "Based on your profile, " . $topMatch['career']['title'] . " is your top career match";
        }
        
        return $insights;
    }
    
    /**
     * Calculate assessment progress over time
     */
    private function calculateAssessmentProgress($assessment) {
        // This would compare with previous assessments
        // For now, return placeholder data
        return [
            'skill_improvement' => rand(0, 20),
            'clarity_increase' => rand(0, 30),
            'confidence_boost' => rand(0, 25)
        ];
    }
    
    /**
     * Identify skill strengths
     */
    private function identifySkillStrengths($skillResponses) {
        if (!is_array($skillResponses) || empty($skillResponses)) {
            return [];
        }
        
        $skills = $this->getSkillQuestions();
        $strengths = [];
        
        foreach ($skillResponses as $skillId => $rating) {
            if ($rating >= 4 && isset($skills[$skillId])) {
                $strengths[] = $skills[$skillId]['name'];
            }
        }
        
        return $strengths;
    }
    
    /**
     * Identify skill gaps
     */
    private function identifySkillGaps($skillResponses) {
        if (!is_array($skillResponses) || empty($skillResponses)) {
            return [];
        }
        
        $skills = $this->getSkillQuestions();
        $gaps = [];
        
        foreach ($skillResponses as $skillId => $rating) {
            if ($rating <= 2 && isset($skills[$skillId])) {
                $gaps[] = $skills[$skillId]['name'];
            }
        }
        
        return $gaps;
    }
    
    /**
     * Analyze interest profile
     */
    private function analyzeInterestProfile($interestResponses) {
        if (!is_array($interestResponses) || empty($interestResponses)) {
            return [];
        }
        
        $interests = $this->getInterestQuestions();
        $profile = [];
        
        foreach ($interestResponses as $interest => $rating) {
            if (isset($interests[$interest])) {
                $profile[] = [
                    'area' => $interest,
                    'description' => $interests[$interest],
                    'rating' => $rating,
                    'level' => $this->getRatingLevel($rating)
                ];
            }
        }
        
        // Sort by rating
        usort($profile, function($a, $b) {
            return $b['rating'] <=> $a['rating'];
        });
        
        return $profile;
    }
    
    /**
     * Generate personalized recommendations
     */
    private function generateRecommendations($assessment, $matches) {
        $recommendations = [];
        
        // Get responses from JSON
        $responses = json_decode($assessment['responses'] ?? '{}', true);
        $skillResponses = $responses['skills'] ?? [];
        
        // Learning recommendations based on skill gaps
        $skillGaps = $this->identifySkillGaps($skillResponses);
        if (!empty($skillGaps)) {
            $recommendations['learning'] = [
                'title' => 'Skill Development Opportunities',
                'items' => array_map(function($skill) {
                    return "Consider improving your {$skill} skills through online courses or practice";
                }, array_slice($skillGaps, 0, 3))
            ];
        }
        
        // Career exploration recommendations
        if (!empty($matches)) {
            $recommendations['exploration'] = [
                'title' => 'Career Paths to Explore',
                'items' => array_map(function($match) {
                    return "Learn more about {$match['career']['title']} - {$match['match_score']}% match";
                }, array_slice($matches, 0, 3))
            ];
        }
        
        // Next steps recommendations
        $recommendations['next_steps'] = [
            'title' => 'Recommended Next Steps',
            'items' => [
                'Explore detailed roadmaps for your top career matches',
                'Connect with professionals in your areas of interest',
                'Consider taking courses to strengthen your skill gaps',
                'Retake the assessment in 3-6 months to track progress'
            ]
        ];
        
        return $recommendations;
    }
    
    /**
     * Get top interests
     */
    private function getTopInterests($interestResponses) {
        $interests = $this->getInterestQuestions();
        $topInterests = [];
        
        arsort($interestResponses);
        
        foreach ($interestResponses as $interest => $rating) {
            if ($rating >= 4 && isset($interests[$interest])) {
                $topInterests[] = str_replace('_', ' ', $interest);
            }
        }
        
        return $topInterests;
    }
    
    /**
     * Get rating level description
     */
    private function getRatingLevel($rating) {
        $levels = [
            1 => 'Not interested',
            2 => 'Slightly interested',
            3 => 'Moderately interested',
            4 => 'Very interested',
            5 => 'Extremely interested'
        ];
        
        return $levels[$rating] ?? 'Unknown';
    }
}