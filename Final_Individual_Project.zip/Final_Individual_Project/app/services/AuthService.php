<?php
/**
 * Authentication Service
 * Handles user authentication, session management, and security
 */

require_once APP_PATH . '/repositories/UserRepository.php';

class AuthService {
    private $userRepository;
    
    public function __construct() {
        $this->userRepository = new UserRepository();
    }
    
    /**
     * Register a new user
     */
    public function register($userData) {
        // Validate input data
        $validation = $this->validateRegistrationData($userData);
        if (!$validation['valid']) {
            return ['success' => false, 'errors' => $validation['errors']];
        }
        
        // Check if email already exists
        if ($this->userRepository->findByEmail($userData['email'])) {
            return ['success' => false, 'errors' => ['email' => 'Email already registered']];
        }
        
        // Create user
        $userId = $this->userRepository->createUser($userData);
        
        if ($userId) {
            // Send verification email (implement later)
            // $this->sendVerificationEmail($userData['email'], $userId);
            
            return ['success' => true, 'user_id' => $userId];
        }
        
        return ['success' => false, 'errors' => ['general' => 'Registration failed']];
    }
    
    /**
     * Authenticate user login
     */
    public function login($email, $password, $rememberMe = false) {
        // Rate limiting check
        if (!$this->checkLoginAttempts($email)) {
            return ['success' => false, 'error' => 'Too many login attempts. Please try again later.'];
        }
        
        // Verify credentials
        $user = $this->userRepository->verifyPassword($email, $password);
        
        if (!$user) {
            $this->recordFailedLogin($email);
            return ['success' => false, 'error' => 'Invalid email or password'];
        }
        
        // Check if user is verified (for contributors)
        if ($user['role'] === 'contributor' && !$user['verified']) {
            return ['success' => false, 'error' => 'Account pending verification'];
        }
        
        // Create session
        $this->createUserSession($user);
        
        // Update last login
        $this->userRepository->updateLastLogin($user['id']);
        
        // Clear failed login attempts
        $this->clearFailedLogins($email);
        
        return ['success' => true, 'user' => $user];
    }
    
    /**
     * Logout user
     */
    public function logout() {
        // Clear session data
        $_SESSION = [];
        
        // Destroy session cookie
        if (isset($_COOKIE[session_name()])) {
            setcookie(session_name(), '', time() - 3600, '/');
        }
        
        // Destroy session
        session_destroy();
        
        return true;
    }
    
    /**
     * Check if user is authenticated
     */
    public function isAuthenticated() {
        return isset($_SESSION['user_id']) && !$this->isSessionExpired();
    }
    
    /**
     * Get current authenticated user
     */
    public function getCurrentUser() {
        if (!$this->isAuthenticated()) {
            return null;
        }
        
        return $this->userRepository->findById($_SESSION['user_id']);
    }
    
    /**
     * Check if user has specific role
     */
    public function hasRole($role) {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === $role;
    }
    
    /**
     * Check if user has any of the specified roles
     */
    public function hasAnyRole($roles) {
        return isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], $roles);
    }
    
    /**
     * Initiate password reset
     */
    public function initiatePasswordReset($email) {
        $user = $this->userRepository->findByEmail($email);
        
        if (!$user) {
            // Don't reveal if email exists
            return ['success' => true, 'message' => 'If the email exists, a reset link has been sent'];
        }
        
        // Generate reset token
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // Store reset token (implement password_resets table)
        $this->storePasswordResetToken($user['id'], $token, $expiry);
        
        // Send reset email (implement later)
        // $this->sendPasswordResetEmail($email, $token);
        
        return ['success' => true, 'message' => 'Password reset link sent to your email'];
    }
    
    /**
     * Reset password with token
     */
    public function resetPassword($token, $newPassword) {
        // Validate token
        $resetData = $this->getPasswordResetData($token);
        
        if (!$resetData || strtotime($resetData['expires_at']) < time()) {
            return ['success' => false, 'error' => 'Invalid or expired reset token'];
        }
        
        // Validate new password
        if (strlen($newPassword) < PASSWORD_MIN_LENGTH) {
            return ['success' => false, 'error' => 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters'];
        }
        
        // Update password
        $success = $this->userRepository->updatePassword($resetData['user_id'], $newPassword);
        
        if ($success) {
            // Delete reset token
            $this->deletePasswordResetToken($token);
            
            return ['success' => true, 'message' => 'Password updated successfully'];
        }
        
        return ['success' => false, 'error' => 'Failed to update password'];
    }
    
    /**
     * Validate registration data
     */
    private function validateRegistrationData($data) {
        $errors = [];
        
        // Email validation
        if (empty($data['email']) || !isValidEmail($data['email'])) {
            $errors['email'] = 'Valid email is required';
        }
        
        // Password validation
        if (empty($data['password']) || strlen($data['password']) < PASSWORD_MIN_LENGTH) {
            $errors['password'] = 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters';
        }
        
        // Name validation
        if (empty($data['first_name'])) {
            $errors['first_name'] = 'First name is required';
        }
        
        if (empty($data['last_name'])) {
            $errors['last_name'] = 'Last name is required';
        }
        
        // Role validation
        $validRoles = ['general_user', 'contributor'];
        if (empty($data['role']) || !in_array($data['role'], $validRoles)) {
            $errors['role'] = 'Valid role is required';
        }
        
        return ['valid' => empty($errors), 'errors' => $errors];
    }
    
    /**
     * Create user session
     */
    private function createUserSession($user) {
        // Regenerate session ID for security
        session_regenerate_id(true);
        
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['login_time'] = time();
        $_SESSION['last_activity'] = time();
    }
    
    /**
     * Check if session is expired
     */
    private function isSessionExpired() {
        if (!isset($_SESSION['last_activity'])) {
            return true;
        }
        
        $inactiveTime = time() - $_SESSION['last_activity'];
        
        if ($inactiveTime > SESSION_TIMEOUT) {
            return true;
        }
        
        // Update last activity
        $_SESSION['last_activity'] = time();
        
        return false;
    }
    
    /**
     * Check login attempts for rate limiting
     */
    private function checkLoginAttempts($email) {
        // Simple file-based rate limiting (implement Redis/database for production)
        $attemptsFile = sys_get_temp_dir() . '/login_attempts_' . md5($email);
        
        if (!file_exists($attemptsFile)) {
            return true;
        }
        
        $attempts = json_decode(file_get_contents($attemptsFile), true);
        $recentAttempts = array_filter($attempts, function($timestamp) {
            return $timestamp > (time() - 900); // 15 minutes
        });
        
        return count($recentAttempts) < 5;
    }
    
    /**
     * Record failed login attempt
     */
    private function recordFailedLogin($email) {
        $attemptsFile = sys_get_temp_dir() . '/login_attempts_' . md5($email);
        
        $attempts = [];
        if (file_exists($attemptsFile)) {
            $attempts = json_decode(file_get_contents($attemptsFile), true) ?: [];
        }
        
        $attempts[] = time();
        file_put_contents($attemptsFile, json_encode($attempts));
    }
    
    /**
     * Clear failed login attempts
     */
    private function clearFailedLogins($email) {
        $attemptsFile = sys_get_temp_dir() . '/login_attempts_' . md5($email);
        
        if (file_exists($attemptsFile)) {
            unlink($attemptsFile);
        }
    }
    
    /**
     * Store password reset token (implement password_resets table)
     */
    private function storePasswordResetToken($userId, $token, $expiry) {
        // This would use a password_resets table in production
        $resetFile = sys_get_temp_dir() . '/password_reset_' . $token;
        $data = ['user_id' => $userId, 'expires_at' => $expiry];
        file_put_contents($resetFile, json_encode($data));
    }
    
    /**
     * Get password reset data
     */
    private function getPasswordResetData($token) {
        $resetFile = sys_get_temp_dir() . '/password_reset_' . $token;
        
        if (file_exists($resetFile)) {
            return json_decode(file_get_contents($resetFile), true);
        }
        
        return null;
    }
    
    /**
     * Delete password reset token
     */
    private function deletePasswordResetToken($token) {
        $resetFile = sys_get_temp_dir() . '/password_reset_' . $token;
        
        if (file_exists($resetFile)) {
            unlink($resetFile);
        }
    }
    
    /**
     * Generate CSRF token
     */
    public function generateCSRFToken() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $token = bin2hex(random_bytes(32));
        $_SESSION['csrf_token'] = $token;
        
        return $token;
    }
    
    /**
     * Validate CSRF token
     */
    public function validateCSRFToken($token) {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        if (empty($token)) {
            return false;
        }
        
        if (!isset($_SESSION['csrf_token'])) {
            return false;
        }
        
        return hash_equals($_SESSION['csrf_token'], $token);
    }
    
    /**
     * Regenerate session ID
     */
    public function regenerateSession() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        return session_regenerate_id(true);
    }
}