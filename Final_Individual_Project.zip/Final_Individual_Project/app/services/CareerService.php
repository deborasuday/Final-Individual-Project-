<?php
/**
 * Career Service
 * Handles business logic for career roadmaps and recommendations
 */

require_once APP_PATH . '/repositories/CareerRepository.php';
require_once APP_PATH . '/repositories/AssessmentRepository.php';

class CareerService {
    private $careerRepository;
    private $assessmentRepository;
    
    public function __construct($careerRepository = null, $assessmentRepository = null) {
        $this->careerRepository = $careerRepository ?? new CareerRepository();
        $this->assessmentRepository = $assessmentRepository ?? new AssessmentRepository();
    }
    
    /**
     * Get career roadmap with all details
     */
    public function getCareerRoadmap($careerId) {
        $careerData = $this->careerRepository->getCareerWithDetails($careerId);
        
        if (!$careerData) {
            return null;
        }
        
        // Format stages with proper structure
        $formattedStages = [];
        foreach ($careerData['stages'] as $stage) {
            $formattedStages[] = [
                'stage_number' => $stage['stage_order'],
                'title' => $stage['title'],
                'description' => $stage['description'],
                'duration_months' => $this->parseDurationToMonths($stage['estimated_duration']),
                'skills' => $this->getStageSkills($stage['id'])
            ];
        }
        
        // Return structured roadmap
        return [
            'career' => [
                'id' => $careerData['id'],
                'title' => $careerData['title'],
                'description' => $careerData['overview'] ?? $careerData['description'] ?? '',
                'industry' => $careerData['industry'] ?? 'General',
                'total_duration' => $this->calculateTotalDuration($careerData['stages']),
                'difficulty_level' => $this->calculateDifficultyLevel($careerData['skills'])
            ],
            'stages' => $formattedStages,
            'skills' => $careerData['skills'],
            'resources' => $careerData['resources']
        ];
    }
    
    /**
     * Parse duration string to months
     */
    private function parseDurationToMonths($duration) {
        if (is_numeric($duration)) {
            return (int)$duration;
        }
        
        // Parse duration (e.g., "3 months", "1 year", "6 weeks")
        if (preg_match('/(\d+)\s*(month|year|week)s?/i', $duration, $matches)) {
            $number = intval($matches[1]);
            $unit = strtolower($matches[2]);
            
            switch ($unit) {
                case 'year':
                    return $number * 12;
                case 'month':
                    return $number;
                case 'week':
                    return max(1, round($number / 4));
            }
        }
        
        return 1; // Default to 1 month
    }
    
    /**
     * Get skills for a specific stage
     */
    private function getStageSkills($stageId) {
        // This would query stage_skills table if it exists
        // For now, return empty array
        return [];
    }
    
    /**
     * Get personalized career recommendations for a user
     */
    public function getPersonalizedRecommendations($userId, $limit = 10) {
        // Get user's latest assessment
        $assessment = $this->assessmentRepository->getLatestAssessment($userId);
        
        if (!$assessment) {
            // Return popular careers if no assessment
            return $this->careerRepository->getPopularCareers($limit);
        }
        
        // Calculate career matches based on assessment
        $matches = $this->assessmentRepository->calculateCareerMatches($assessment['id']);
        
        // Enhance matches with additional data
        foreach ($matches as &$match) {
            $match['career']['match_percentage'] = round($match['match_score'] * 10, 1);
            $match['career']['skill_gap'] = $this->calculateSkillGap($match['career'], $assessment);
        }
        
        return array_slice($matches, 0, $limit);
    }
    
    /**
     * Search careers with filters
     */
    public function searchCareers($searchTerm, $filters = []) {
        $industry = $filters['industry'] ?? null;
        $limit = $filters['limit'] ?? 20;
        
        $careers = $this->careerRepository->searchCareers($searchTerm, $industry, $limit);
        
        // Enhance search results
        foreach ($careers as &$career) {
            $career['preview_stages'] = $this->getPreviewStages($career['id']);
            $career['key_skills'] = $this->getKeySkills($career['id']);
        }
        
        return $careers;
    }
    
    /**
     * Get career statistics and insights
     */
    public function getCareerInsights($careerId) {
        $career = $this->careerRepository->findById($careerId);
        
        if (!$career) {
            return null;
        }
        
        $insights = [
            'career' => $career,
            'popularity_rank' => $this->getCareerPopularityRank($careerId),
            'average_timeline' => $this->getAverageTimeline($careerId),
            'success_stories_count' => $this->getSuccessStoriesCount($careerId),
            'related_careers' => $this->getRelatedCareers($careerId),
            'market_demand' => $this->getMarketDemandData($career['industry'])
        ];
        
        return $insights;
    }
    
    /**
     * Create a new career roadmap
     */
    public function createCareerRoadmap($careerData, $stages, $skills, $resources) {
        $this->careerRepository->beginTransaction();
        
        try {
            // Create the career
            $careerId = $this->careerRepository->create($careerData);
            
            if (!$careerId) {
                throw new Exception('Failed to create career');
            }
            
            // Add stages
            foreach ($stages as $stage) {
                $this->careerRepository->addCareerStage($careerId, $stage);
            }
            
            // Add skills
            foreach ($skills as $skill) {
                $this->careerRepository->addCareerSkill(
                    $careerId, 
                    $skill['skill_id'], 
                    $skill['proficiency_level']
                );
            }
            
            // Add resources
            foreach ($resources as $resource) {
                $this->careerRepository->addLearningResource($careerId, $resource);
            }
            
            $this->careerRepository->commit();
            
            return ['success' => true, 'career_id' => $careerId];
            
        } catch (Exception $e) {
            $this->careerRepository->rollback();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Calculate total duration from stages
     */
    private function calculateTotalDuration($stages) {
        $totalMonths = 0;
        
        foreach ($stages as $stage) {
            $duration = $stage['estimated_duration'];
            
            // Parse duration (e.g., "3 months", "1 year", "6 weeks")
            if (preg_match('/(\d+)\s*(month|year|week)s?/i', $duration, $matches)) {
                $number = intval($matches[1]);
                $unit = strtolower($matches[2]);
                
                switch ($unit) {
                    case 'year':
                        $totalMonths += $number * 12;
                        break;
                    case 'month':
                        $totalMonths += $number;
                        break;
                    case 'week':
                        $totalMonths += $number / 4;
                        break;
                }
            }
        }
        
        return $this->formatDuration($totalMonths);
    }
    
    /**
     * Categorize skills by type
     */
    private function categorizeSkills($skills) {
        $categories = [
            'technical' => [],
            'soft' => []
        ];
        
        foreach ($skills as $skill) {
            $categories[$skill['category']][] = $skill;
        }
        
        return $categories;
    }
    
    /**
     * Calculate difficulty level based on required skills
     */
    private function calculateDifficultyLevel($skills) {
        $advancedCount = 0;
        $totalCount = count($skills);
        
        foreach ($skills as $skill) {
            if ($skill['proficiency_level'] === 'advanced') {
                $advancedCount++;
            }
        }
        
        if ($totalCount === 0) return 'Beginner';
        
        $advancedRatio = $advancedCount / $totalCount;
        
        if ($advancedRatio >= 0.5) return 'Advanced';
        if ($advancedRatio >= 0.3) return 'Intermediate';
        return 'Beginner';
    }
    
    /**
     * Calculate skill gap for user
     */
    private function calculateSkillGap($career, $assessment) {
        $careerSkills = $this->careerRepository->getCareerSkills($career['id']);
        $userSkills = $assessment['skill_responses'];
        
        $gaps = [];
        
        foreach ($careerSkills as $skill) {
            $userLevel = $userSkills[$skill['id']] ?? 0;
            $requiredLevel = $this->proficiencyToNumber($skill['proficiency_level']);
            
            if ($userLevel < $requiredLevel) {
                $gaps[] = [
                    'skill' => $skill,
                    'current_level' => $userLevel,
                    'required_level' => $requiredLevel,
                    'gap' => $requiredLevel - $userLevel
                ];
            }
        }
        
        return $gaps;
    }
    
    /**
     * Get preview stages (first 3 stages)
     */
    private function getPreviewStages($careerId) {
        $stages = $this->careerRepository->getCareerStages($careerId);
        return array_slice($stages, 0, 3);
    }
    
    /**
     * Get key skills (top 5 most important)
     */
    private function getKeySkills($careerId) {
        $skills = $this->careerRepository->getCareerSkills($careerId);
        
        // Sort by proficiency level (advanced first)
        usort($skills, function($a, $b) {
            $levelOrder = ['advanced' => 3, 'intermediate' => 2, 'beginner' => 1];
            return $levelOrder[$b['proficiency_level']] <=> $levelOrder[$a['proficiency_level']];
        });
        
        return array_slice($skills, 0, 5);
    }
    
    /**
     * Get career popularity rank
     */
    private function getCareerPopularityRank($careerId) {
        // This would be based on user interactions, saves, views, etc.
        // For now, return a placeholder
        return rand(1, 100);
    }
    
    /**
     * Get average timeline for career completion
     */
    private function getAverageTimeline($careerId) {
        $stages = $this->careerRepository->getCareerStages($careerId);
        return $this->calculateTotalDuration($stages);
    }
    
    /**
     * Get success stories count
     */
    private function getSuccessStoriesCount($careerId) {
        // This would query the career_stories table
        return rand(5, 50);
    }
    
    /**
     * Get related careers
     */
    private function getRelatedCareers($careerId) {
        $career = $this->careerRepository->findById($careerId);
        
        if (!$career) {
            return [];
        }
        
        // Get careers in the same industry
        $related = $this->careerRepository->getCareersByIndustry($career['industry']);
        
        // Remove current career and limit results
        $related = array_filter($related, function($c) use ($careerId) {
            return $c['id'] != $careerId;
        });
        
        return array_slice($related, 0, 5);
    }
    
    /**
     * Get market demand data
     */
    private function getMarketDemandData($industry) {
        // This would integrate with job market APIs
        // For now, return placeholder data
        return [
            'demand_level' => 'High',
            'growth_rate' => '+15%',
            'avg_salary' => '$75,000',
            'job_openings' => rand(1000, 10000)
        ];
    }
    
    /**
     * Convert proficiency level to number
     */
    private function proficiencyToNumber($level) {
        $levels = ['beginner' => 2, 'intermediate' => 3, 'advanced' => 5];
        return $levels[$level] ?? 1;
    }
    
    /**
     * Format duration in human-readable format
     */
    private function formatDuration($months) {
        if ($months < 1) {
            return 'Less than 1 month';
        } elseif ($months < 12) {
            return round($months) . ' months';
        } else {
            $years = floor($months / 12);
            $remainingMonths = $months % 12;
            
            $result = $years . ' year' . ($years > 1 ? 's' : '');
            
            if ($remainingMonths > 0) {
                $result .= ' ' . round($remainingMonths) . ' months';
            }
            
            return $result;
        }
    }
}