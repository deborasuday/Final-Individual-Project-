<?php
// Redirect to working simple assessment
header("Location: /Final_Individual_Project/SIMPLE_ASSESSMENT.php");
exit;
?>
<!-- Assessment Page -->
<div class="assessment-container">
    <div class="assessment-header">
        <h1>Career Assessment</h1>
        <p class="assessment-intro">
            Discover your ideal career path through our comprehensive assessment. 
            We'll evaluate your skills and interests to provide personalized recommendations.
        </p>
        
        <?php if ($hasCompletedBefore): ?>
            <div class="previous-assessment-notice">
                <p>You've completed this assessment before. Taking it again will help us provide updated recommendations based on your current skills and interests.</p>
            </div>
        <?php endif; ?>
    </div>
    
    <form id="assessmentForm" class="assessment-form" method="POST" action="<?= BASE_URL ?>/assessment">
        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
        
        <!-- Progress Indicator -->
        <div class="progress-indicator">
            <div class="progress-step active" data-step="1">
                <div class="step-number">1</div>
                <div class="step-label">Skills</div>
            </div>
            <div class="progress-step" data-step="2">
                <div class="step-number">2</div>
                <div class="step-label">Interests</div>
            </div>
            <div class="progress-step" data-step="3">
                <div class="step-number">3</div>
                <div class="step-label">Review</div>
            </div>
        </div>
        
        <!-- Skills Assessment Section -->
        <div class="assessment-section active" id="skills-section">
            <div class="section-header">
                <h2>Skills Assessment</h2>
                <p>Rate your current proficiency level in each skill area (1 = Beginner, 5 = Expert)</p>
            </div>
            
            <div class="skills-grid">
                <?php if (isset($questions['skills'])): ?>
                    <?php foreach ($questions['skills'] as $skillId => $skill): ?>
                        <div class="skill-item">
                            <div class="skill-info">
                                <h4><?= htmlspecialchars($skill['name']) ?></h4>
                                <span class="skill-category"><?= ucfirst($skill['category']) ?></span>
                            </div>
                            
                            <div class="rating-scale">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <label class="rating-option">
                                        <input type="radio" name="skills[<?= $skillId ?>]" value="<?= $i ?>" required>
                                        <span class="rating-circle"><?= $i ?></span>
                                    </label>
                                <?php endfor; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No skills questions available.</p>
                <?php endif; ?>
            </div>
            
            <div class="section-navigation">
                <button type="button" class="btn btn-primary" onclick="nextSection()">
                    Continue to Interests
                </button>
            </div>
        </div>
        
        <!-- Interests Assessment Section -->
        <div class="assessment-section" id="interests-section">
            <div class="section-header">
                <h2>Interest Assessment</h2>
                <p>Rate your level of interest in each area (1 = Not interested, 5 = Very interested)</p>
            </div>
            
            <div class="interests-grid">
                <?php if (isset($questions['interests'])): ?>
                    <?php foreach ($questions['interests'] as $interestKey => $interestDescription): ?>
                        <div class="interest-item">
                            <div class="interest-info">
                                <h4><?= ucwords(str_replace('_', ' ', $interestKey)) ?></h4>
                                <p><?= htmlspecialchars($interestDescription) ?></p>
                            </div>
                            
                            <div class="rating-scale">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <label class="rating-option">
                                        <input type="radio" name="interests[<?= $interestKey ?>]" value="<?= $i ?>" required>
                                        <span class="rating-circle"><?= $i ?></span>
                                    </label>
                                <?php endfor; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No interest questions available.</p>
                <?php endif; ?>
            </div>
            
            <div class="section-navigation">
                <button type="button" class="btn btn-secondary" onclick="previousSection()">
                    Back to Skills
                </button>
                <button type="button" class="btn btn-primary" onclick="nextSection()">
                    Review Responses
                </button>
            </div>
        </div>
        
        <!-- Review Section -->
        <div class="assessment-section" id="review-section">
            <div class="section-header">
                <h2>Review Your Responses</h2>
                <p>Please review your assessment before submitting. You can go back to make changes if needed.</p>
            </div>
            
            <div class="review-content">
                <div class="review-summary">
                    <div class="summary-card">
                        <h3>Skills Summary</h3>
                        <div id="skills-summary"></div>
                    </div>
                    
                    <div class="summary-card">
                        <h3>Interests Summary</h3>
                        <div id="interests-summary"></div>
                    </div>
                </div>
                
                <div class="assessment-info">
                    <h3>What happens next?</h3>
                    <ul>
                        <li>We'll analyze your responses to identify your strengths and interests</li>
                        <li>You'll receive personalized career recommendations</li>
                        <li>Each recommendation includes detailed roadmaps and requirements</li>
                        <li>You can save careers and track your progress over time</li>
                    </ul>
                </div>
            </div>
            
            <div class="section-navigation">
                <button type="button" class="btn btn-secondary" onclick="previousSection()">
                    Back to Interests
                </button>
                <button type="submit" class="btn btn-primary" id="submitAssessment">
                    Complete Assessment
                </button>
            </div>
        </div>
    </form>
</div>

<style>
.assessment-container {
    max-width: 800px;
    margin: 0 auto;
    padding: 2rem 1rem;
}

.assessment-header {
    text-align: center;
    margin-bottom: 3rem;
}

.assessment-header h1 {
    color: #000000;
    margin-bottom: 1rem;
}

.assessment-intro {
    color: #666666;
    font-size: 1.1rem;
    line-height: 1.6;
    max-width: 600px;
    margin: 0 auto;
}

.previous-assessment-notice {
    background-color: #f8f6f3;
    padding: 1rem;
    border-radius: 6px;
    margin-top: 1rem;
    border-left: 4px solid #B9937B;
}

.previous-assessment-notice p {
    color: #666666;
    margin: 0;
    font-size: 0.9rem;
}

.progress-indicator {
    display: flex;
    justify-content: center;
    margin-bottom: 3rem;
    position: relative;
}

.progress-indicator::before {
    content: '';
    position: absolute;
    top: 20px;
    left: 25%;
    right: 25%;
    height: 2px;
    background-color: #e0e0e0;
    z-index: 1;
}

.progress-step {
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    z-index: 2;
}

.step-number {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background-color: #e0e0e0;
    color: #666666;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    margin-bottom: 0.5rem;
    transition: all 0.3s ease;
}

.progress-step.active .step-number {
    background-color: #B9937B;
    color: #ffffff;
}

.progress-step.completed .step-number {
    background-color: #28a745;
    color: #ffffff;
}

.step-label {
    font-size: 0.9rem;
    color: #666666;
    font-weight: 500;
}

.progress-step.active .step-label {
    color: #B9937B;
    font-weight: 600;
}

.assessment-section {
    display: none;
}

.assessment-section.active {
    display: block;
}

.section-header {
    text-align: center;
    margin-bottom: 2rem;
}

.section-header h2 {
    color: #000000;
    margin-bottom: 0.5rem;
}

.section-header p {
    color: #666666;
    font-size: 1rem;
}

.skills-grid,
.interests-grid {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.skill-item,
.interest-item {
    background-color: #ffffff;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: border-color 0.3s ease;
}

.skill-item:hover,
.interest-item:hover {
    border-color: #B9937B;
}

.skill-info h4,
.interest-info h4 {
    color: #000000;
    margin-bottom: 0.25rem;
}

.skill-category {
    background-color: #f0f0f0;
    color: #666666;
    padding: 0.25rem 0.5rem;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 500;
}

.interest-info p {
    color: #666666;
    margin: 0;
    font-size: 0.9rem;
    line-height: 1.4;
}

.rating-scale {
    display: flex;
    gap: 0.5rem;
}

.rating-option {
    cursor: pointer;
}

.rating-option input {
    display: none;
}

.rating-circle {
    width: 40px;
    height: 40px;
    border: 2px solid #e0e0e0;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    color: #666666;
    transition: all 0.3s ease;
}

.rating-option:hover .rating-circle {
    border-color: #B9937B;
    color: #B9937B;
}

.rating-option input:checked + .rating-circle {
    background-color: #B9937B;
    border-color: #B9937B;
    color: #ffffff;
}

.section-navigation {
    display: flex;
    justify-content: center;
    gap: 1rem;
    margin-top: 2rem;
}

.review-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 2rem;
    margin-bottom: 2rem;
}

.summary-card {
    background-color: #f8f6f3;
    padding: 1.5rem;
    border-radius: 8px;
}

.summary-card h3 {
    color: #000000;
    margin-bottom: 1rem;
}

.assessment-info {
    grid-column: 1 / -1;
    background-color: #ffffff;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 1.5rem;
}

.assessment-info h3 {
    color: #B9937B;
    margin-bottom: 1rem;
}

.assessment-info ul {
    color: #666666;
    line-height: 1.6;
}

.assessment-info li {
    margin-bottom: 0.5rem;
}

@media (max-width: 768px) {
    .skill-item,
    .interest-item {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
    }
    
    .rating-scale {
        align-self: stretch;
        justify-content: space-between;
    }
    
    .review-content {
        grid-template-columns: 1fr;
    }
    
    .section-navigation {
        flex-direction: column;
    }
    
    .progress-indicator {
        margin-bottom: 2rem;
    }
    
    .progress-indicator::before {
        left: 20%;
        right: 20%;
    }
}
</style>

<script>
let currentSection = 1;
const totalSections = 3;

function nextSection() {
    if (currentSection < totalSections) {
        // Validate current section
        if (!validateCurrentSection()) {
            return;
        }
        
        // Hide current section
        document.querySelector('.assessment-section.active').classList.remove('active');
        document.querySelector('.progress-step.active').classList.remove('active');
        document.querySelector('.progress-step.active').classList.add('completed');
        
        // Show next section
        currentSection++;
        const nextSectionElement = document.querySelector(`#${getSectionId(currentSection)}`);
        const nextStepElement = document.querySelector(`[data-step="${currentSection}"]`);
        
        nextSectionElement.classList.add('active');
        nextStepElement.classList.add('active');
        
        // Update review section if we're on it
        if (currentSection === 3) {
            updateReviewSummary();
        }
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

function previousSection() {
    if (currentSection > 1) {
        // Hide current section
        document.querySelector('.assessment-section.active').classList.remove('active');
        document.querySelector('.progress-step.active').classList.remove('active');
        
        // Show previous section
        currentSection--;
        const prevSectionElement = document.querySelector(`#${getSectionId(currentSection)}`);
        const prevStepElement = document.querySelector(`[data-step="${currentSection}"]`);
        
        prevSectionElement.classList.add('active');
        prevStepElement.classList.add('active');
        prevStepElement.classList.remove('completed');
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

function getSectionId(sectionNumber) {
    const sections = ['skills-section', 'interests-section', 'review-section'];
    return sections[sectionNumber - 1];
}

function validateCurrentSection() {
    const currentSectionElement = document.querySelector('.assessment-section.active');
    const requiredInputs = currentSectionElement.querySelectorAll('input[required]');
    
    // Group radio buttons by name
    const radioGroups = {};
    requiredInputs.forEach(input => {
        if (input.type === 'radio') {
            if (!radioGroups[input.name]) {
                radioGroups[input.name] = [];
            }
            radioGroups[input.name].push(input);
        }
    });
    
    // Check if all radio groups have a selection
    for (const groupName in radioGroups) {
        const group = radioGroups[groupName];
        const hasSelection = group.some(input => input.checked);
        
        if (!hasSelection) {
            alert('Please complete all ratings before continuing.');
            return false;
        }
    }
    
    return true;
}

function updateReviewSummary() {
    // Update skills summary
    const skillsData = getFormData('skills');
    const skillsSummary = document.getElementById('skills-summary');
    skillsSummary.innerHTML = generateSkillsSummary(skillsData);
    
    // Update interests summary
    const interestsData = getFormData('interests');
    const interestsSummary = document.getElementById('interests-summary');
    interestsSummary.innerHTML = generateInterestsSummary(interestsData);
}

function getFormData(section) {
    const data = {};
    const inputs = document.querySelectorAll(`input[name^="${section}"]:checked`);
    
    inputs.forEach(input => {
        const match = input.name.match(/\[([^\]]+)\]/);
        if (match) {
            data[match[1]] = parseInt(input.value);
        }
    });
    
    return data;
}

function generateSkillsSummary(skillsData) {
    const skillNames = <?= json_encode($questions['skills'] ?? []) ?>;
    let html = '<div class="summary-items">';
    
    // Show top skills (rating 4 or 5)
    const topSkills = Object.entries(skillsData)
        .filter(([id, rating]) => rating >= 4)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 5);
    
    if (topSkills.length > 0) {
        html += '<h4>Your Strongest Skills:</h4><ul>';
        topSkills.forEach(([skillId, rating]) => {
            const skill = skillNames[skillId];
            if (skill) {
                html += `<li>${skill.name} (${rating}/5)</li>`;
            }
        });
        html += '</ul>';
    }
    
    html += `<p><strong>Total skills assessed:</strong> ${Object.keys(skillsData).length}</p>`;
    html += '</div>';
    
    return html;
}

function generateInterestsSummary(interestsData) {
    const interestNames = <?= json_encode($questions['interests'] ?? []) ?>;
    let html = '<div class="summary-items">';
    
    // Show top interests (rating 4 or 5)
    const topInterests = Object.entries(interestsData)
        .filter(([id, rating]) => rating >= 4)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 5);
    
    if (topInterests.length > 0) {
        html += '<h4>Your Top Interests:</h4><ul>';
        topInterests.forEach(([interestKey, rating]) => {
            const interestName = interestKey.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            html += `<li>${interestName} (${rating}/5)</li>`;
        });
        html += '</ul>';
    }
    
    html += `<p><strong>Total areas assessed:</strong> ${Object.keys(interestsData).length}</p>`;
    html += '</div>';
    
    return html;
}

// Form submission
document.getElementById('assessmentForm').addEventListener('submit', function(e) {
    const submitButton = document.getElementById('submitAssessment');
    
    // Validate that we're on the review section
    if (currentSection !== 3) {
        e.preventDefault();
        alert('Please complete all sections before submitting.');
        return;
    }
    
    // Validate all required fields are filled
    const skillInputs = document.querySelectorAll('input[name^="skills"]:checked');
    const interestInputs = document.querySelectorAll('input[name^="interests"]:checked');
    
    const totalSkills = <?= isset($questions['skills']) ? count($questions['skills']) : 0 ?>;
    const totalInterests = <?= isset($questions['interests']) ? count($questions['interests']) : 0 ?>;
    
    if (skillInputs.length < totalSkills || interestInputs.length < totalInterests) {
        e.preventDefault();
        alert('Please complete all ratings before submitting.');
        return;
    }
    
    // Disable button and show processing
    submitButton.disabled = true;
    submitButton.textContent = 'Processing...';
    
    // Form will submit normally - don't prevent default
});
</script>