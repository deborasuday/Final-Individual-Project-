<!-- Assessment Results Page -->
<div class="results-container">
    <div class="results-header">
        <h1>Your Assessment Results 🎉</h1>
        <p class="results-intro">
            Based on your responses, we've identified your strengths and matched you with careers 
            that align with your skills and interests.
        </p>
        
        <div class="completion-badge">
            <div class="badge-content">
                <h3>Assessment Complete! ✅</h3>
                <p>Completed on <?= date('F j, Y', strtotime($results['assessment']['completed_at'])) ?></p>
            </div>
        </div>
    </div>
    
    <!-- Career Matches Section -->
    <section class="career-matches-section">
        <h2>Your Top Career Matches 🎯</h2>
        <p>These careers align best with your skills and interests:</p>
        
        <div class="matches-grid">
            <?php foreach (array_slice($results['career_matches'], 0, 6) as $match): ?>
                <div class="match-card">
                    <div class="match-header">
                        <h3><?= htmlspecialchars($match['career']['title']) ?></h3>
                        <div class="match-score">
                            <?= round($match['match_score'] * 10, 1) ?>% match
                        </div>
                    </div>
                    
                    <div class="match-details">
                        <p class="career-industry"><?= htmlspecialchars($match['career']['industry'] ?? 'General') ?></p>
                        <p class="career-description">
                            <?= htmlspecialchars(substr($match['career']['overview'], 0, 120)) ?>...
                        </p>
                        
                        <div class="match-stats">
                            <span class="stat">
                                <strong><?= $match['skill_matches'] ?></strong> skill matches
                            </span>
                        </div>
                    </div>
                    
                    <div class="match-actions">
                        <a href="/Final_Individual_Project/SIMPLE_CAREER_DETAIL.php?id=<?= $match['career']['id'] ?>" class="btn btn-primary btn-small">
                            View Roadmap
                        </a>
                        <button class="btn btn-secondary btn-small save-career" data-career-id="<?= $match['career']['id'] ?>">
                            Save Career
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <?php if (count($results['career_matches']) > 6): ?>
            <div class="view-more">
                <a href="/Final_Individual_Project/SIMPLE_CAREERS.php" class="btn btn-secondary">
                    View All <?= count($results['career_matches']) ?> Matches
                </a>
            </div>
        <?php endif; ?>
    </section>
    
    <!-- Skills Analysis Section -->
    <section class="skills-analysis-section">
        <h2>Your Skills Profile</h2>
        
        <div class="skills-content">
            <div class="skills-strengths">
                <h3>Your Strengths</h3>
                <?php if (!empty($results['skill_strengths'])): ?>
                    <div class="strengths-list">
                        <?php foreach (array_slice($results['skill_strengths'], 0, 8) as $skill): ?>
                            <div class="skill-tag strength">
                                <?= htmlspecialchars($skill) ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="no-data">Complete more skill assessments to identify your strengths.</p>
                <?php endif; ?>
            </div>
            
            <div class="skills-gaps">
                <h3>Areas for Development</h3>
                <?php if (!empty($results['skill_gaps'])): ?>
                    <div class="gaps-list">
                        <?php foreach (array_slice($results['skill_gaps'], 0, 6) as $skill): ?>
                            <div class="skill-tag gap">
                                <?= htmlspecialchars($skill) ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <p class="gap-note">
                        These skills could enhance your career prospects. Consider focusing on these areas for growth.
                    </p>
                <?php else: ?>
                    <p class="no-data">Great! You have strong skills across all assessed areas.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
    
    <!-- Interest Profile Section -->
    <section class="interest-profile-section">
        <h2>Your Interest Profile</h2>
        
        <div class="interests-chart">
            <?php foreach (array_slice($results['interest_profile'], 0, 8) as $interest): ?>
                <div class="interest-item">
                    <div class="interest-info">
                        <h4><?= ucwords(str_replace('_', ' ', $interest['area'])) ?></h4>
                        <p><?= htmlspecialchars($interest['description']) ?></p>
                    </div>
                    
                    <div class="interest-rating">
                        <div class="rating-bar">
                            <div class="rating-fill" style="width: <?= ($interest['rating'] / 5) * 100 ?>%"></div>
                        </div>
                        <span class="rating-text"><?= $interest['level'] ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    
    <!-- Recommendations Section -->
    <section class="recommendations-section">
        <h2>Personalized Recommendations</h2>
        
        <div class="recommendations-grid">
            <?php foreach ($results['recommendations'] as $category => $recommendation): ?>
                <div class="recommendation-card">
                    <h3><?= htmlspecialchars($recommendation['title']) ?></h3>
                    <ul>
                        <?php foreach ($recommendation['items'] as $item): ?>
                            <li><?= htmlspecialchars($item) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    
    <!-- Next Steps Section -->
    <section class="next-steps-section">
        <h2>What's Next?</h2>
        
        <div class="next-steps-grid">
            <div class="step-card">
                <h3>Explore Career Roadmaps</h3>
                <p>Dive deep into your top career matches to understand the path forward.</p>
                <a href="/Final_Individual_Project/SIMPLE_CAREERS.php" class="btn btn-primary">Browse Careers</a>
            </div>
            
            <div class="step-card">
                <h3>Save Your Favorites</h3>
                <p>Save careers that interest you to track your progress and build your plan.</p>
                <a href="<?= BASE_URL ?>/dashboard" class="btn btn-secondary">Go to Dashboard</a>
            </div>
            
            <div class="step-card">
                <h3>Start Learning</h3>
                <p>Begin developing skills that will help you reach your career goals.</p>
                <a href="/Final_Individual_Project/SIMPLE_CAREERS.php" class="btn btn-secondary">Find Resources</a>
            </div>
            
            <div class="step-card">
                <h3>Retake Assessment</h3>
                <p>Update your results as you grow and develop new skills.</p>
                <a href="/Final_Individual_Project/SIMPLE_ASSESSMENT.php" class="btn btn-secondary">Retake Assessment</a>
            </div>
        </div>
    </section>
</div>

<style>
.results-container {
    max-width: 1000px;
    margin: 0 auto;
    padding: 2rem 1rem;
}

.results-header {
    text-align: center;
    margin-bottom: 3rem;
}

.results-header h1 {
    color: #000000;
    margin-bottom: 1rem;
}

.results-intro {
    color: #666666;
    font-size: 1.1rem;
    line-height: 1.6;
    max-width: 600px;
    margin: 0 auto 2rem;
}

.completion-badge {
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #B9937B 0%, #9A7A5F 100%);
    color: #ffffff;
    padding: 1.5rem;
    border-radius: 12px;
    max-width: 400px;
    margin: 0 auto;
    text-align: center;
}

.badge-content h3 {
    color: #ffffff;
    margin-bottom: 0.25rem;
}

.badge-content p {
    color: #f0e6d9;
    margin: 0;
    font-size: 0.9rem;
}

.career-matches-section,
.skills-analysis-section,
.interest-profile-section,
.recommendations-section,
.next-steps-section {
    margin-bottom: 3rem;
    background: #ffffff;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.career-matches-section h2,
.skills-analysis-section h2,
.interest-profile-section h2,
.recommendations-section h2,
.next-steps-section h2 {
    color: #000000;
    margin-bottom: 1rem;
}

.matches-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.match-card {
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 1.5rem;
    transition: box-shadow 0.3s ease;
}

.match-card:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.match-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 1rem;
}

.match-header h3 {
    color: #000000;
    margin: 0;
    flex: 1;
}

.match-score {
    background-color: #B9937B;
    color: #ffffff;
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
}

.career-industry {
    color: #B9937B;
    font-weight: 600;
    margin-bottom: 0.5rem;
}

.career-description {
    color: #666666;
    margin-bottom: 1rem;
    line-height: 1.5;
}

.match-stats {
    margin-bottom: 1rem;
}

.stat {
    color: #666666;
    font-size: 0.9rem;
}

.match-actions {
    display: flex;
    gap: 0.5rem;
}

.view-more {
    text-align: center;
}

.skills-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 2rem;
}

.strengths-list,
.gaps-list {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin-bottom: 1rem;
}

.skill-tag {
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-size: 0.9rem;
    font-weight: 500;
}

.skill-tag.strength {
    background-color: #d4edda;
    color: #155724;
}

.skill-tag.gap {
    background-color: #fff3cd;
    color: #856404;
}

.gap-note {
    color: #666666;
    font-size: 0.9rem;
    font-style: italic;
}

.no-data {
    color: #666666;
    font-style: italic;
}

.interests-chart {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.interest-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
    background-color: #f8f6f3;
    border-radius: 6px;
}

.interest-info {
    flex: 1;
}

.interest-info h4 {
    color: #000000;
    margin-bottom: 0.25rem;
}

.interest-info p {
    color: #666666;
    margin: 0;
    font-size: 0.9rem;
}

.interest-rating {
    display: flex;
    align-items: center;
    gap: 1rem;
    min-width: 150px;
}

.rating-bar {
    width: 80px;
    height: 8px;
    background-color: #e0e0e0;
    border-radius: 4px;
    overflow: hidden;
}

.rating-fill {
    height: 100%;
    background-color: #B9937B;
    transition: width 0.3s ease;
}

.rating-text {
    font-size: 0.8rem;
    color: #666666;
    font-weight: 500;
}

.recommendations-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1.5rem;
}

.recommendation-card {
    background-color: #f8f6f3;
    padding: 1.5rem;
    border-radius: 8px;
    border-left: 4px solid #B9937B;
}

.recommendation-card h3 {
    color: #B9937B;
    margin-bottom: 1rem;
}

.recommendation-card ul {
    list-style-position: inside;
    color: #666666;
    line-height: 1.6;
}

.recommendation-card li {
    margin-bottom: 0.5rem;
}

.next-steps-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
}

.step-card {
    text-align: center;
    padding: 2rem;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    transition: transform 0.3s ease;
}

.step-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.step-card h3 {
    color: #000000;
    margin-bottom: 1rem;
}

.step-card p {
    color: #666666;
    margin-bottom: 1.5rem;
    line-height: 1.5;
}

@media (max-width: 768px) {
    .completion-badge {
        flex-direction: column;
        text-align: center;
    }
    
    .skills-content {
        grid-template-columns: 1fr;
    }
    
    .interest-item {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
    }
    
    .interest-rating {
        width: 100%;
        justify-content: space-between;
    }
    
    .match-actions {
        flex-direction: column;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Save career functionality
    document.querySelectorAll('.save-career').forEach(button => {
        button.addEventListener('click', function() {
            const careerId = this.dataset.careerId;
            
            // Make AJAX request to save career
            fetch('/careers/toggle-save', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content
                },
                body: `career_id=${careerId}&csrf_token=${document.querySelector('meta[name="csrf-token"]').content}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.textContent = data.action === 'saved' ? 'Saved!' : 'Save Career';
                    this.classList.toggle('btn-primary', data.action === 'saved');
                    this.classList.toggle('btn-secondary', data.action !== 'saved');
                }
            })
            .catch(error => {
                console.error('Error saving career:', error);
            });
        });
    });
});
</script>