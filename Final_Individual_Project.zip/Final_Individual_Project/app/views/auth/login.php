<!-- Login Page -->
<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <h1>Welcome Back</h1>
            <p>Sign in to continue your career journey</p>
        </div>
        
        <form class="auth-form" method="POST" action="<?= BASE_URL ?>/login">

            
            <div class="form-group">
                <label for="email">Email Address</label>
                <input 
                    type="email" 
                    id="email" 
                    name="email" 
                    required 
                    value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                    placeholder="Enter your email"
                >
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input 
                    type="password" 
                    id="password" 
                    name="password" 
                    required 
                    placeholder="Enter your password"
                >
            </div>
            
            <div class="form-options">
                <label class="checkbox-label">
                    <input type="checkbox" name="remember_me" value="1">
                    <span class="checkmark"></span>
                    Remember me
                </label>
                
                <a href="/forgot-password" class="forgot-link">Forgot password?</a>
            </div>
            
            <button type="submit" class="btn btn-primary btn-full">Sign In</button>
        </form>
        
        <div class="auth-footer">
            <p>Don't have an account? <a href="<?= BASE_URL ?>/register">Sign up here</a></p>
        </div>
    </div>
    
    <div class="auth-benefits">
        <h3>Why Join Our Platform?</h3>
        <ul>
            <li>
                <div class="benefit-icon">✓</div>
                <div>
                    <strong>Personalized Roadmaps</strong>
                    <p>Get step-by-step guidance tailored to your goals</p>
                </div>
            </li>
            <li>
                <div class="benefit-icon">✓</div>
                <div>
                    <strong>Skills Assessment</strong>
                    <p>Discover your strengths and areas for growth</p>
                </div>
            </li>
            <li>
                <div class="benefit-icon">✓</div>
                <div>
                    <strong>Expert Insights</strong>
                    <p>Learn from professionals who've walked the path</p>
                </div>
            </li>
            <li>
                <div class="benefit-icon">✓</div>
                <div>
                    <strong>Progress Tracking</strong>
                    <p>Monitor your advancement and celebrate milestones</p>
                </div>
            </li>
        </ul>
    </div>
</div>

<style>
.auth-container {
    min-height: 75vh;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 3rem;
    align-items: center;
    max-width: 1000px;
    margin: 2rem auto;
    padding: 0 1rem;
}

.auth-card {
    background: #ffffff;
    padding: 2rem;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
}

.auth-header {
    text-align: center;
    margin-bottom: 1.5rem;
}

.auth-header h1 {
    color: #000000;
    margin-bottom: 0.5rem;
    font-size: 1.75rem;
}

.auth-header p {
    color: #666666;
    margin: 0;
    font-size: 0.95rem;
}

.auth-form {
    display: flex;
    flex-direction: column;
    gap: 1.25rem;
}

.form-group {
    display: flex;
    flex-direction: column;
}

.form-group label {
    font-weight: 600;
    margin-bottom: 0.5rem;
    color: #000000;
}

.form-group input {
    padding: 0.7rem;
    border: 1px solid #d0d0d0;
    border-radius: 6px;
    font-size: 0.95rem;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

.form-group input:focus {
    outline: none;
    border-color: #B9937B;
    box-shadow: 0 0 0 3px rgba(185, 147, 123, 0.1);
}

.form-group input.error {
    border-color: #e74c3c;
}

.field-error {
    color: #e74c3c;
    font-size: 0.875rem;
    margin-top: 0.25rem;
}

.form-options {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.checkbox-label {
    display: flex;
    align-items: center;
    cursor: pointer;
    font-size: 0.9rem;
}

.checkbox-label input {
    margin-right: 0.5rem;
}

.forgot-link {
    color: #B9937B;
    font-size: 0.9rem;
    text-decoration: none;
}

.forgot-link:hover {
    text-decoration: underline;
}

.btn-full {
    width: 100%;
}

.auth-footer {
    text-align: center;
    margin-top: 1.5rem;
    padding-top: 1.5rem;
    border-top: 1px solid #f0f0f0;
}

.auth-footer p {
    color: #666666;
    margin: 0;
}

.auth-footer a {
    color: #B9937B;
    text-decoration: none;
    font-weight: 600;
}

.auth-footer a:hover {
    text-decoration: underline;
}

.auth-benefits {
    padding: 1.75rem;
}

.auth-benefits h3 {
    color: #000000;
    margin-bottom: 1.5rem;
}

.auth-benefits ul {
    list-style: none;
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.auth-benefits li {
    display: flex;
    align-items: flex-start;
    gap: 1rem;
}

.benefit-icon {
    width: 24px;
    height: 24px;
    background-color: #B9937B;
    color: #ffffff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.8rem;
    font-weight: bold;
    flex-shrink: 0;
}

.auth-benefits strong {
    color: #000000;
    display: block;
    margin-bottom: 0.25rem;
}

.auth-benefits p {
    color: #666666;
    margin: 0;
    font-size: 0.9rem;
    line-height: 1.4;
}

@media (max-width: 768px) {
    .auth-container {
        grid-template-columns: 1fr;
        gap: 2rem;
        min-height: auto;
    }
    
    .auth-card, .auth-benefits {
        padding: 1.5rem;
    }
    
    .auth-header h1 {
        font-size: 1.5rem;
    }
    
    .form-options {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
    }
}
</style>