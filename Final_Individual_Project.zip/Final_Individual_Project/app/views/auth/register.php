<!-- Registration Page -->
<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <h1>Start Your Journey 🚀</h1>
            <p>Create your account to access personalized career guidance</p>
        </div>
        
        <form class="auth-form" method="POST" action="<?= BASE_URL ?>/register">
            
            <div class="form-row">
                <div class="form-group">
                    <label for="first_name">First Name</label>
                    <input 
                        type="text" 
                        id="first_name" 
                        name="first_name" 
                        required 
                        value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>"
                        placeholder="Enter your first name"
                    >
                </div>
                
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <input 
                        type="text" 
                        id="last_name" 
                        name="last_name" 
                        required 
                        value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>"
                        placeholder="Enter your last name"
                    >
                </div>
            </div>
            
            <div class="form-group">
                <label for="email">Email Address</label>
                <input 
                    type="email" 
                    id="email" 
                    name="email" 
                    required 
                    value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                    placeholder="Enter your email address"
                >
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input 
                    type="password" 
                    id="password" 
                    name="password" 
                    required 
                    placeholder="Create a strong password"
                    minlength="8"
                >
                <small class="form-help">Must be at least 8 characters long</small>
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input 
                    type="password" 
                    id="confirm_password" 
                    name="confirm_password" 
                    required 
                    placeholder="Confirm your password"
                >
            </div>
            

            
            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" name="terms_accepted" value="1" required>
                    <span class="checkmark"></span>
                    I agree to the <a href="/terms" target="_blank">Terms of Service</a> and <a href="/privacy" target="_blank">Privacy Policy</a>
                </label>
            </div>
            
            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" name="newsletter" value="1" <?= ($_POST['newsletter'] ?? '') ? 'checked' : '' ?>>
                    <span class="checkmark"></span>
                    Send me career tips and platform updates
                </label>
            </div>
            
            <button type="submit" class="btn btn-primary btn-full">Create Account</button>
        </form>
        
        <div class="auth-footer">
            <p>Already have an account? <a href="<?= BASE_URL ?>/login">Sign in here</a></p>
        </div>
    </div>
    
    <div class="auth-benefits">
        <h3>What You'll Get</h3>
        
        <div class="benefit-card">
            <div>
                <h4>📊 Personalized Assessment</h4>
                <p>Discover your strengths and get matched with careers that fit your skills and interests.</p>
            </div>
        </div>
        
        <div class="benefit-card">
            <div>
                <h4>🗺️ Step-by-Step Roadmaps</h4>
                <p>Clear, actionable pathways from where you are now to where you want to be.</p>
            </div>
        </div>
        
        <div class="benefit-card">
            <div>
                <h4>👥 Expert Community</h4>
                <p>Learn from verified professionals who share real experiences and practical advice.</p>
            </div>
        </div>
        
        <div class="benefit-card">
            <div>
                <h4>📈 Progress Tracking</h4>
                <p>Monitor your growth and celebrate achievements as you advance in your career.</p>
            </div>
        </div>
        
        <div class="trust-indicators">
            <h4>Trusted by Professionals</h4>
            <div class="stats">
                <div class="stat">
                    <strong>10,000+</strong>
                    <span>Active Users</span>
                </div>
                <div class="stat">
                    <strong>500+</strong>
                    <span>Career Paths</span>
                </div>
                <div class="stat">
                    <strong>95%</strong>
                    <span>Success Rate</span>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}

.form-group select {
    padding: 0.75rem;
    border: 2px solid #e0e0e0;
    border-radius: 6px;
    font-size: 1rem;
    background-color: #ffffff;
    transition: border-color 0.3s ease;
}

.form-group select:focus {
    outline: none;
    border-color: #B9937B;
}

.form-help {
    color: #666666;
    font-size: 0.8rem;
    margin-top: 0.25rem;
}

.checkbox-label {
    display: flex;
    align-items: flex-start;
    cursor: pointer;
    font-size: 0.9rem;
    line-height: 1.4;
}

.checkbox-label input {
    margin-right: 0.5rem;
    margin-top: 0.1rem;
}

.checkbox-label a {
    color: #B9937B;
    text-decoration: none;
}

.checkbox-label a:hover {
    text-decoration: underline;
}

.benefit-card {
    padding: 1.25rem;
    background-color: #f8f6f3;
    border-radius: 8px;
    margin-bottom: 0.75rem;
}

.benefit-card h4 {
    color: #000000;
    margin-bottom: 0.5rem;
    font-size: 1.1rem;
}

.benefit-card p {
    color: #666666;
    margin: 0;
    font-size: 0.9rem;
    line-height: 1.4;
}

.trust-indicators {
    margin-top: 1.5rem;
    padding: 1.25rem;
    background-color: #ffffff;
    border-radius: 8px;
    border: 1px solid #e0e0e0;
}

.trust-indicators h4 {
    color: #000000;
    margin-bottom: 1rem;
    text-align: center;
}

.stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1rem;
    text-align: center;
}

.stat strong {
    display: block;
    font-size: 1.5rem;
    color: #B9937B;
    font-weight: 700;
}

.stat span {
    font-size: 0.8rem;
    color: #666666;
}

@media (max-width: 768px) {
    .form-row {
        grid-template-columns: 1fr;
    }
    
    .stats {
        grid-template-columns: 1fr;
        gap: 0.5rem;
    }
    
    .benefit-card {
        padding: 1rem;
    }
    
    .trust-indicators {
        padding: 1rem;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Password confirmation validation
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirm_password');
    
    function validatePasswordMatch() {
        if (confirmPassword.value && password.value !== confirmPassword.value) {
            confirmPassword.setCustomValidity('Passwords do not match');
        } else {
            confirmPassword.setCustomValidity('');
        }
    }
    
    password.addEventListener('input', validatePasswordMatch);
    confirmPassword.addEventListener('input', validatePasswordMatch);
});
</script>