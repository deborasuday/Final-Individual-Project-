<!-- Careers Listing Page -->
<div class="careers-container">
    <div class="careers-header">
        <h1>Explore Career Paths</h1>
        <p class="careers-intro">
            Discover structured roadmaps for hundreds of careers. Each path includes skills requirements, 
            learning stages, and realistic timelines to help you plan your journey.
        </p>
    </div>
    
    <!-- Search and Filters -->
    <div class="search-filters">
        <form class="search-form" method="GET" action="/careers">
            <div class="search-input-group">
                <input 
                    type="text" 
                    name="search" 
                    placeholder="Search careers, skills, or industries..." 
                    value="<?= htmlspecialchars($searchTerm) ?>"
                    class="search-input"
                >
                <button type="submit" class="search-btn">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="11" cy="11" r="8"/>
                        <path d="m21 21-4.35-4.35"/>
                    </svg>
                </button>
            </div>
            
            <div class="filter-group">
                <select name="industry" class="filter-select">
                    <option value="">All Industries</option>
                    <?php foreach ($industries as $industry): ?>
                        <option value="<?= htmlspecialchars($industry) ?>" 
                                <?= $selectedIndustry === $industry ? 'selected' : '' ?>>
                            <?= htmlspecialchars($industry) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <button type="submit" class="btn btn-secondary">Filter</button>
                
                <?php if ($hasSearch): ?>
                    <a href="/careers" class="btn btn-outline">Clear Filters</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    
    <!-- Results Summary -->
    <div class="results-summary">
        <?php if ($hasSearch): ?>
            <p>
                <?php if ($searchTerm): ?>
                    Showing results for "<strong><?= htmlspecialchars($searchTerm) ?></strong>"
                <?php endif; ?>
                <?php if ($selectedIndustry): ?>
                    in <strong><?= htmlspecialchars($selectedIndustry) ?></strong>
                <?php endif; ?>
                (<?= count($careers) ?> careers found)
            </p>
        <?php else: ?>
            <p>Personalized recommendations based on your profile (<?= count($careers) ?> careers)</p>
        <?php endif; ?>
    </div>
    
    <!-- Career Cards Grid -->
    <div class="careers-grid">
        <?php foreach ($careers as $career): ?>
            <div class="career-card">
                <div class="career-header">
                    <h3><?= htmlspecialchars($career['title']) ?></h3>
                    <div class="career-industry"><?= htmlspecialchars($career['industry']) ?></div>
                </div>
                
                <div class="career-content">
                    <p class="career-description">
                        <?= htmlspecialchars(substr($career['overview'], 0, 150)) ?>...
                    </p>
                    
                    <div class="career-meta">
                        <?php if (isset($career['stages_count'])): ?>
                            <span class="meta-item">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M9 11H1v3h8v3l3-4-3-4v2z"/>
                                    <path d="M22 12h-6"/>
                                </svg>
                                <?= $career['stages_count'] ?> stages
                            </span>
                        <?php endif; ?>
                        
                        <?php if (isset($career['skills_count'])): ?>
                            <span class="meta-item">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="12" r="3"/>
                                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1 1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
                                </svg>
                                <?= $career['skills_count'] ?> skills
                            </span>
                        <?php endif; ?>
                        
                        <?php if (isset($career['match_percentage'])): ?>
                            <span class="meta-item match-score">
                                <?= $career['match_percentage'] ?>% match
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="career-actions">
                    <a href="/careers/<?= $career['id'] ?>" class="btn btn-primary">
                        View Roadmap
                    </a>
                    <button class="btn btn-secondary save-career" data-career-id="<?= $career['id'] ?>">
                        Save
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <?php if (empty($careers)): ?>
        <div class="no-results">
            <div class="no-results-icon">🔍</div>
            <h3>No careers found</h3>
            <p>Try adjusting your search terms or filters to find more results.</p>
            <a href="/careers" class="btn btn-primary">View All Careers</a>
        </div>
    <?php endif; ?>
    
    <!-- Popular Careers Sidebar -->
    <?php if (!$hasSearch && !empty($popularCareers)): ?>
        <aside class="popular-careers">
            <h3>Popular Career Paths</h3>
            <div class="popular-list">
                <?php foreach ($popularCareers as $career): ?>
                    <a href="/careers/<?= $career['id'] ?>" class="popular-item">
                        <h4><?= htmlspecialchars($career['title']) ?></h4>
                        <p><?= htmlspecialchars($career['industry']) ?></p>
                    </a>
                <?php endforeach; ?>
            </div>
        </aside>
    <?php endif; ?>
    
    <!-- Call to Action -->
    <div class="cta-section">
        <h2>Not sure where to start?</h2>
        <p>Take our comprehensive assessment to get personalized career recommendations.</p>
        <a href="/assessment" class="btn btn-primary btn-large">Take Assessment</a>
    </div>
</div>

<style>
.careers-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem 1rem;
}

.careers-header {
    text-align: center;
    margin-bottom: 3rem;
}

.careers-header h1 {
    color: #000000;
    margin-bottom: 1rem;
}

.careers-intro {
    color: #666666;
    font-size: 1.1rem;
    line-height: 1.6;
    max-width: 600px;
    margin: 0 auto;
}

.search-filters {
    background: #ffffff;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    margin-bottom: 2rem;
}

.search-form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.search-input-group {
    position: relative;
    flex: 1;
}

.search-input {
    width: 100%;
    padding: 1rem 3rem 1rem 1rem;
    border: 2px solid #e0e0e0;
    border-radius: 6px;
    font-size: 1rem;
    transition: border-color 0.3s ease;
}

.search-input:focus {
    outline: none;
    border-color: #B9937B;
}

.search-btn {
    position: absolute;
    right: 0.5rem;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: #B9937B;
    cursor: pointer;
    padding: 0.5rem;
}

.filter-group {
    display: flex;
    gap: 1rem;
    align-items: center;
}

.filter-select {
    padding: 0.75rem;
    border: 2px solid #e0e0e0;
    border-radius: 6px;
    font-size: 1rem;
    background-color: #ffffff;
    min-width: 200px;
}

.btn-outline {
    background: transparent;
    color: #B9937B;
    border: 2px solid #B9937B;
}

.btn-outline:hover {
    background: #B9937B;
    color: #ffffff;
}

.results-summary {
    margin-bottom: 2rem;
    color: #666666;
}

.careers-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 2rem;
    margin-bottom: 3rem;
}

.career-card {
    background: #ffffff;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 2rem;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.career-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
}

.career-header {
    margin-bottom: 1rem;
}

.career-header h3 {
    color: #000000;
    margin-bottom: 0.5rem;
}

.career-industry {
    color: #B9937B;
    font-weight: 600;
    font-size: 0.9rem;
}

.career-description {
    color: #666666;
    line-height: 1.6;
    margin-bottom: 1.5rem;
}

.career-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.meta-item {
    display: flex;
    align-items: center;
    gap: 0.25rem;
    color: #666666;
    font-size: 0.9rem;
}

.meta-item svg {
    color: #B9937B;
}

.match-score {
    background-color: #B9937B;
    color: #ffffff;
    padding: 0.25rem 0.75rem;
    border-radius: 12px;
    font-weight: 600;
}

.career-actions {
    display: flex;
    gap: 0.75rem;
}

.no-results {
    text-align: center;
    padding: 4rem 2rem;
    color: #666666;
}

.no-results-icon {
    font-size: 4rem;
    margin-bottom: 1rem;
}

.no-results h3 {
    color: #000000;
    margin-bottom: 1rem;
}

.popular-careers {
    background: #f8f6f3;
    padding: 2rem;
    border-radius: 8px;
    margin-bottom: 3rem;
}

.popular-careers h3 {
    color: #000000;
    margin-bottom: 1.5rem;
}

.popular-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.popular-item {
    display: block;
    padding: 1rem;
    background: #ffffff;
    border-radius: 6px;
    text-decoration: none;
    transition: background-color 0.3s ease;
}

.popular-item:hover {
    background-color: #B9937B;
}

.popular-item h4 {
    color: #000000;
    margin-bottom: 0.25rem;
    transition: color 0.3s ease;
}

.popular-item p {
    color: #666666;
    margin: 0;
    font-size: 0.9rem;
    transition: color 0.3s ease;
}

.popular-item:hover h4,
.popular-item:hover p {
    color: #ffffff;
}

.cta-section {
    text-align: center;
    background: linear-gradient(135deg, #B9937B 0%, #9A7A5F 100%);
    color: #ffffff;
    padding: 3rem 2rem;
    border-radius: 12px;
}

.cta-section h2 {
    color: #ffffff;
    margin-bottom: 1rem;
}

.cta-section p {
    color: #f0e6d9;
    font-size: 1.1rem;
    margin-bottom: 2rem;
}

.cta-section .btn-primary {
    background-color: #ffffff;
    color: #B9937B;
}

.cta-section .btn-primary:hover {
    background-color: #f0f0f0;
}

@media (max-width: 768px) {
    .search-form {
        gap: 1.5rem;
    }
    
    .filter-group {
        flex-direction: column;
        align-items: stretch;
    }
    
    .filter-select {
        min-width: auto;
    }
    
    .careers-grid {
        grid-template-columns: 1fr;
    }
    
    .career-actions {
        flex-direction: column;
    }
    
    .popular-careers {
        order: -1;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Save career functionality
    document.querySelectorAll('.save-career').forEach(button => {
        button.addEventListener('click', function() {
            const careerId = this.dataset.careerId;
            
            fetch('/careers/toggle-save', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content
                },
                body: `career_id=${careerId}&csrf_token=${document.querySelector('meta[name="csrf-token"]').content}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.textContent = data.action === 'saved' ? 'Saved!' : 'Save';
                    this.classList.toggle('btn-primary', data.action === 'saved');
                    this.classList.toggle('btn-secondary', data.action !== 'saved');
                }
            })
            .catch(error => {
                console.error('Error saving career:', error);
            });
        });
    });
    
    // Auto-submit form on filter change
    document.querySelector('.filter-select').addEventListener('change', function() {
        this.closest('form').submit();
    });
});
</script>