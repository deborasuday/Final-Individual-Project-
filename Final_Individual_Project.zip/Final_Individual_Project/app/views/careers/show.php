<!-- Career Detail Page -->
<div class="career-detail-container">
    <!-- Career Header -->
    <div class="career-header">
        <div class="career-breadcrumb">
            <a href="/careers">← Back to Careers</a>
        </div>
        
        <div class="career-title-section">
            <h1><?= htmlspecialchars($career['title']) ?></h1>
            <div class="career-meta">
                <span class="industry"><?= htmlspecialchars($career['industry']) ?></span>
                <span class="difficulty">Difficulty: <?= $career['difficulty_level'] ?></span>
                <span class="duration">Duration: <?= $career['total_duration'] ?></span>
            </div>
        </div>
        
        <div class="career-actions">
            <button class="btn <?= $isSaved ? 'btn-primary' : 'btn-secondary' ?> save-career" 
                    data-career-id="<?= $career['id'] ?>">
                <?= $isSaved ? 'Saved' : 'Save Career' ?>
            </button>
            <button class="btn btn-secondary share-career">Share</button>
        </div>
    </div>
    
    <!-- Career Overview -->
    <section class="career-overview">
        <h2>Career Overview</h2>
        <div class="overview-content">
            <p><?= nl2br(htmlspecialchars($career['overview'])) ?></p>
            
            <?php if (!empty($skillGap)): ?>
                <div class="skill-gap-summary">
                    <h3>Your Skill Match</h3>
                    <div class="skill-match-bar">
                        <div class="match-fill" style="width: <?= 100 - $skillGap['gap_percentage'] ?>%"></div>
                    </div>
                    <p>
                        You have <?= $skillGap['matching_skills'] ?> of <?= $skillGap['total_skills'] ?> required skills. 
                        <a href="#skills-section">See detailed breakdown</a>
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- Career Roadmap -->
    <section class="career-roadmap" id="roadmap-section">
        <h2>Career Roadmap</h2>
        <p>Follow this step-by-step path to achieve your career goals:</p>
        
        <div class="roadmap-timeline">
            <?php foreach ($career['stages'] as $index => $stage): ?>
                <div class="roadmap-stage">
                    <div class="stage-marker">
                        <div class="stage-number"><?= $index + 1 ?></div>
                    </div>
                    
                    <div class="stage-content">
                        <h3><?= htmlspecialchars($stage['title']) ?></h3>
                        <div class="stage-duration"><?= htmlspecialchars($stage['estimated_duration']) ?></div>
                        <p><?= nl2br(htmlspecialchars($stage['description'])) ?></p>
                        
                        <?php if (!empty($stage['key_activities'])): ?>
                            <div class="stage-activities">
                                <h4>Key Activities:</h4>
                                <ul>
                                    <?php foreach ($stage['key_activities'] as $activity): ?>
                                        <li><?= htmlspecialchars($activity) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    
    <!-- Required Skills -->
    <section class="required-skills" id="skills-section">
        <h2>Required Skills</h2>
        
        <div class="skills-categories">
            <?php foreach ($career['skill_categories'] as $category => $skills): ?>
                <div class="skills-category">
                    <h3><?= ucfirst($category) ?> Skills</h3>
                    
                    <div class="skills-grid">
                        <?php foreach ($skills as $skill): ?>
                            <div class="skill-item <?= isset($skillGap) && in_array($skill['name'], $skillGap['missing_skills']) ? 'skill-gap' : 'skill-match' ?>">
                                <div class="skill-info">
                                    <h4><?= htmlspecialchars($skill['name']) ?></h4>
                                    <div class="skill-level"><?= ucfirst($skill['proficiency_level']) ?> Level</div>
                                </div>
                                
                                <?php if (isset($skillGap) && in_array($skill['name'], $skillGap['missing_skills'])): ?>
                                    <div class="skill-status gap">
                                        <span>Need to develop</span>
                                    </div>
                                <?php else: ?>
                                    <div class="skill-status match">
                                        <span>✓ You have this</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    
    <!-- Learning Resources -->
    <?php if (!empty($career['resources'])): ?>
        <section class="learning-resources">
            <h2>Learning Resources</h2>
            <p>Recommended resources to develop the skills needed for this career:</p>
            
            <div class="resources-grid">
                <?php foreach ($career['resources'] as $resource): ?>
                    <div class="resource-card">
                        <div class="resource-type"><?= ucfirst($resource['resource_type']) ?></div>
                        <h3><?= htmlspecialchars($resource['title']) ?></h3>
                        <p><?= htmlspecialchars($resource['description']) ?></p>
                        
                        <?php if (!empty($resource['url'])): ?>
                            <a href="<?= htmlspecialchars($resource['url']) ?>" 
                               target="_blank" 
                               class="btn btn-secondary btn-small">
                                View Resource
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>
    
    <!-- Career Insights -->
    <?php if (!empty($insights)): ?>
        <section class="career-insights">
            <h2>Career Insights</h2>
            
            <div class="insights-grid">
                <div class="insight-card">
                    <h3>Market Demand</h3>
                    <div class="insight-value"><?= $insights['market_demand']['demand_level'] ?></div>
                    <p>Growth Rate: <?= $insights['market_demand']['growth_rate'] ?></p>
                    <p>Job Openings: <?= number_format($insights['market_demand']['job_openings']) ?>+</p>
                </div>
                
                <div class="insight-card">
                    <h3>Average Salary</h3>
                    <div class="insight-value"><?= $insights['market_demand']['avg_salary'] ?></div>
                    <p>Based on industry data</p>
                </div>
                
                <div class="insight-card">
                    <h3>Success Stories</h3>
                    <div class="insight-value"><?= $insights['success_stories_count'] ?></div>
                    <p>Professionals sharing their journey</p>
                    <a href="/stories?career_id=<?= $career['id'] ?>" class="btn btn-secondary btn-small">
                        Read Stories
                    </a>
                </div>
                
                <div class="insight-card">
                    <h3>Related Careers</h3>
                    <div class="related-careers-list">
                        <?php foreach (array_slice($insights['related_careers'], 0, 3) as $relatedCareer): ?>
                            <a href="/careers/<?= $relatedCareer['id'] ?>" class="related-career-link">
                                <?= htmlspecialchars($relatedCareer['title']) ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
    
    <!-- Next Steps -->
    <section class="next-steps">
        <h2>Ready to Start?</h2>
        <div class="next-steps-content">
            <p>Take the next step in your career journey:</p>
            
            <div class="next-steps-actions">
                <a href="/assessment" class="btn btn-primary">
                    Take Skills Assessment
                </a>
                <a href="/dashboard" class="btn btn-secondary">
                    Track Your Progress
                </a>
                <a href="/careers" class="btn btn-secondary">
                    Explore More Careers
                </a>
            </div>
        </div>
    </section>
</div>

<style>
.career-detail-container {
    max-width: 1000px;
    margin: 0 auto;
    padding: 2rem 1rem;
}

.career-header {
    margin-bottom: 3rem;
}

.career-breadcrumb {
    margin-bottom: 1rem;
}

.career-breadcrumb a {
    color: #B9937B;
    text-decoration: none;
    font-weight: 500;
}

.career-breadcrumb a:hover {
    text-decoration: underline;
}

.career-title-section {
    margin-bottom: 2rem;
}

.career-title-section h1 {
    color: #000000;
    margin-bottom: 1rem;
    font-size: 2.5rem;
}

.career-meta {
    display: flex;
    gap: 2rem;
    flex-wrap: wrap;
}

.career-meta span {
    color: #666666;
    font-weight: 500;
}

.industry {
    color: #B9937B !important;
}

.career-actions {
    display: flex;
    gap: 1rem;
}

.career-overview,
.career-roadmap,
.required-skills,
.learning-resources,
.career-insights,
.next-steps {
    background: #ffffff;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    margin-bottom: 2rem;
}

.career-overview h2,
.career-roadmap h2,
.required-skills h2,
.learning-resources h2,
.career-insights h2,
.next-steps h2 {
    color: #000000;
    margin-bottom: 1.5rem;
}

.skill-gap-summary {
    background-color: #f8f6f3;
    padding: 1.5rem;
    border-radius: 8px;
    margin-top: 2rem;
    border-left: 4px solid #B9937B;
}

.skill-gap-summary h3 {
    color: #B9937B;
    margin-bottom: 1rem;
}

.skill-match-bar {
    width: 100%;
    height: 12px;
    background-color: #e0e0e0;
    border-radius: 6px;
    overflow: hidden;
    margin-bottom: 1rem;
}

.match-fill {
    height: 100%;
    background-color: #B9937B;
    transition: width 0.3s ease;
}

.roadmap-timeline {
    position: relative;
}

.roadmap-timeline::before {
    content: '';
    position: absolute;
    left: 30px;
    top: 0;
    bottom: 0;
    width: 2px;
    background-color: #e0e0e0;
}

.roadmap-stage {
    display: flex;
    margin-bottom: 3rem;
    position: relative;
}

.stage-marker {
    position: relative;
    z-index: 2;
}

.stage-number {
    width: 60px;
    height: 60px;
    background-color: #B9937B;
    color: #ffffff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 1.2rem;
}

.stage-content {
    flex: 1;
    margin-left: 2rem;
    padding: 1rem 0;
}

.stage-content h3 {
    color: #000000;
    margin-bottom: 0.5rem;
}

.stage-duration {
    color: #B9937B;
    font-weight: 600;
    margin-bottom: 1rem;
}

.stage-activities {
    margin-top: 1rem;
    padding: 1rem;
    background-color: #f8f6f3;
    border-radius: 6px;
}

.stage-activities h4 {
    color: #B9937B;
    margin-bottom: 0.5rem;
}

.stage-activities ul {
    color: #666666;
    line-height: 1.6;
}

.skills-categories {
    display: flex;
    flex-direction: column;
    gap: 2rem;
}

.skills-category h3 {
    color: #B9937B;
    margin-bottom: 1rem;
}

.skills-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1rem;
}

.skill-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
    border-radius: 6px;
    border: 1px solid #e0e0e0;
}

.skill-item.skill-match {
    background-color: #d4edda;
    border-color: #c3e6cb;
}

.skill-item.skill-gap {
    background-color: #fff3cd;
    border-color: #ffeaa7;
}

.skill-info h4 {
    color: #000000;
    margin-bottom: 0.25rem;
}

.skill-level {
    color: #666666;
    font-size: 0.9rem;
}

.skill-status {
    font-size: 0.9rem;
    font-weight: 500;
}

.skill-status.match {
    color: #155724;
}

.skill-status.gap {
    color: #856404;
}

.resources-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1.5rem;
}

.resource-card {
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 1.5rem;
    transition: box-shadow 0.3s ease;
}

.resource-card:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.resource-type {
    background-color: #B9937B;
    color: #ffffff;
    padding: 0.25rem 0.75rem;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 600;
    display: inline-block;
    margin-bottom: 1rem;
}

.resource-card h3 {
    color: #000000;
    margin-bottom: 1rem;
}

.resource-card p {
    color: #666666;
    margin-bottom: 1rem;
    line-height: 1.5;
}

.insights-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
}

.insight-card {
    text-align: center;
    padding: 1.5rem;
    background-color: #f8f6f3;
    border-radius: 8px;
}

.insight-card h3 {
    color: #B9937B;
    margin-bottom: 1rem;
}

.insight-value {
    font-size: 2rem;
    font-weight: 700;
    color: #000000;
    margin-bottom: 0.5rem;
}

.insight-card p {
    color: #666666;
    margin-bottom: 0.5rem;
}

.related-careers-list {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.related-career-link {
    color: #B9937B;
    text-decoration: none;
    font-size: 0.9rem;
}

.related-career-link:hover {
    text-decoration: underline;
}

.next-steps-content {
    text-align: center;
}

.next-steps-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
    margin-top: 2rem;
    flex-wrap: wrap;
}

@media (max-width: 768px) {
    .career-meta {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .career-actions {
        flex-direction: column;
    }
    
    .roadmap-timeline::before {
        left: 20px;
    }
    
    .stage-number {
        width: 40px;
        height: 40px;
        font-size: 1rem;
    }
    
    .stage-content {
        margin-left: 1rem;
    }
    
    .skills-grid {
        grid-template-columns: 1fr;
    }
    
    .next-steps-actions {
        flex-direction: column;
        align-items: center;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Save career functionality
    document.querySelector('.save-career').addEventListener('click', function() {
        const careerId = this.dataset.careerId;
        
        fetch('/careers/toggle-save', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content
            },
            body: `career_id=${careerId}&csrf_token=${document.querySelector('meta[name="csrf-token"]').content}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                this.textContent = data.action === 'saved' ? 'Saved' : 'Save Career';
                this.classList.toggle('btn-primary', data.action === 'saved');
                this.classList.toggle('btn-secondary', data.action !== 'saved');
            }
        })
        .catch(error => {
            console.error('Error saving career:', error);
        });
    });
    
    // Share career functionality
    document.querySelector('.share-career').addEventListener('click', function() {
        if (navigator.share) {
            navigator.share({
                title: document.title,
                url: window.location.href
            });
        } else {
            // Fallback: copy to clipboard
            navigator.clipboard.writeText(window.location.href).then(() => {
                this.textContent = 'Link Copied!';
                setTimeout(() => {
                    this.textContent = 'Share';
                }, 2000);
            });
        }
    });
});
</script>