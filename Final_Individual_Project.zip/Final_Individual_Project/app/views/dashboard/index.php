<!-- Dashboard Page -->
<div class="dashboard">
    <div class="dashboard-header">
        <div class="welcome-section">
            <h1>Welcome back, <?= htmlspecialchars($user['first_name']) ?>! 👋</h1>
            <p class="dashboard-subtitle">
                <?php if (!$hasAssessment): ?>
                    Ready to discover your ideal career path? Start with our assessment. 🚀
                <?php else: ?>
                    Continue your career journey with personalized recommendations. ✨
                <?php endif; ?>
            </p>
        </div>
        
        <div class="quick-actions">
            <?php if (!$hasAssessment): ?>
                <a href="/Final_Individual_Project/SIMPLE_ASSESSMENT.php" class="btn btn-primary">Take Assessment</a>
            <?php else: ?>
                <a href="/Final_Individual_Project/SIMPLE_ASSESSMENT.php" class="btn btn-secondary">Retake Assessment</a>
            <?php endif; ?>
            <a href="/Final_Individual_Project/SIMPLE_CAREERS.php" class="btn btn-secondary">Explore Careers</a>
        </div>
    </div>
    
    <!-- Progress Overview -->
    <div class="progress-overview">
        <h2>Your Progress</h2>
        <div class="progress-cards">
            <div class="progress-card">
                <div class="progress-content">
                    <h3><?= $progressStats['assessments_completed'] ?></h3>
                    <p>Assessments Completed</p>
                </div>
            </div>
            
            <div class="progress-card">
                <div class="progress-content">
                    <h3><?= $progressStats['careers_explored'] ?></h3>
                    <p>Careers Explored</p>
                </div>
            </div>
            
            <div class="progress-card">
                <div class="progress-content">
                    <h3><?= $progressStats['roadmaps_viewed'] ?></h3>
                    <p>Roadmaps Viewed</p>
                </div>
            </div>
            
            <div class="progress-card">
                <div class="progress-content">
                    <h3><?= $progressStats['skills_identified'] ?></h3>
                    <p>Skills Identified</p>
                </div>
            </div>
        </div>
        
        <div class="overall-progress">
            <div class="progress-bar-container">
                <div class="progress-label">
                    <span>Career Journey Progress</span>
                    <span><?= $progressStats['progress_percentage'] ?>%</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: <?= $progressStats['progress_percentage'] ?>%"></div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="dashboard-content">
        <!-- Main Content Area -->
        <div class="main-content">
            <?php if ($hasAssessment && !empty($recommendations)): ?>
                <!-- Career Recommendations -->
                <section class="recommendations-section">
                    <h2>Recommended for You</h2>
                    <p>Based on your assessment results, here are careers that match your profile:</p>
                    
                    <div class="recommendations-grid">
                        <?php foreach (array_slice($recommendations, 0, 3) as $recommendation): ?>
                            <div class="recommendation-card">
                                <div class="recommendation-header">
                                    <h3><?= htmlspecialchars($recommendation['career']['title']) ?></h3>
                                    <div class="match-score">
                                        <?= $recommendation['career']['match_percentage'] ?? round($recommendation['match_score'] * 10, 1) ?>% match
                                    </div>
                                </div>
                                
                                <p class="recommendation-description">
                                    <?= htmlspecialchars(substr($recommendation['career']['overview'], 0, 120)) ?>...
                                </p>
                                
                                <div class="recommendation-meta">
                                    <span class="industry"><?= htmlspecialchars($recommendation['career']['industry']) ?></span>
                                    <span class="skills-match"><?= $recommendation['skill_matches'] ?? 0 ?> skill matches</span>
                                </div>
                                
                                <div class="recommendation-actions">
                                    <a href="<?= BASE_URL ?>/careers/<?= $recommendation['career']['id'] ?>" class="btn btn-primary btn-small">
                                        View Roadmap
                                    </a>
                                    <button class="btn btn-secondary btn-small save-career" data-career-id="<?= $recommendation['career']['id'] ?>">
                                        Save
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="section-footer">
                        <a href="<?= BASE_URL ?>/careers" class="view-all-link">View all career recommendations →</a>
                    </div>
                </section>
            <?php endif; ?>
            
            <?php if (!empty($savedCareers)): ?>
                <!-- Saved Careers -->
                <section class="saved-careers-section">
                    <h2>Your Saved Careers</h2>
                    
                    <div class="saved-careers-list">
                        <?php foreach ($savedCareers as $career): ?>
                            <div class="saved-career-item">
                                <div class="career-info">
                                    <h4><?= htmlspecialchars($career['title']) ?></h4>
                                    <p><?= htmlspecialchars($career['industry']) ?> • <?= $career['match_percentage'] ?>% match</p>
                                </div>
                                
                                <div class="career-actions">
                                    <a href="<?= BASE_URL ?>/roadmap/<?= $career['id'] ?>" class="btn btn-primary btn-small">Continue</a>
                                    <button class="btn btn-secondary btn-small remove-career" data-career-id="<?= $career['id'] ?>">
                                        Remove
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endif; ?>
            
            <!-- Recent Activity -->
            <section class="activity-section">
                <h2>Recent Activity</h2>
                
                <div class="activity-list">
                    <?php foreach ($recentActivity as $activity): ?>
                        <div class="activity-item">
                            <div class="activity-content">
                                <p><?= htmlspecialchars($activity['description']) ?></p>
                                <span class="activity-date"><?= date('M j, Y', strtotime($activity['date'])) ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        </div>
        
        <!-- Sidebar -->
        <div class="sidebar">
            <?php if (!$hasAssessment): ?>
                <!-- Assessment CTA -->
                <div class="sidebar-card assessment-cta">
                    <h3>Discover Your Path</h3>
                    <p>Take our comprehensive assessment to get personalized career recommendations.</p>
                    <a href="/Final_Individual_Project/SIMPLE_ASSESSMENT.php" class="btn btn-primary btn-full">Start Assessment</a>
                </div>
            <?php endif; ?>
            
            <!-- Quick Stats -->
            <div class="sidebar-card quick-stats">
                <h3>Quick Stats</h3>
                <div class="stat-item">
                    <span class="stat-label">Journey Progress</span>
                    <span class="stat-value"><?= $progressStats['progress_percentage'] ?>%</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Skills Identified</span>
                    <span class="stat-value"><?= $progressStats['skills_identified'] ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Careers Explored</span>
                    <span class="stat-value"><?= $progressStats['careers_explored'] ?></span>
                </div>
            </div>
            
            <!-- Role-specific content -->
            <?php if ($user['role'] === 'contributor' && !empty($roleData)): ?>
                <div class="sidebar-card contributor-stats">
                    <h3>Your Contributions</h3>
                    <div class="stat-item">
                        <span class="stat-label">Content Submissions</span>
                        <span class="stat-value"><?= $roleData['content_submissions'] ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Approved Content</span>
                        <span class="stat-value"><?= $roleData['approved_content'] ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Impact Score</span>
                        <span class="stat-value"><?= $roleData['impact_score'] ?></span>
                    </div>
                    <a href="<?= BASE_URL ?>/contribute" class="btn btn-secondary btn-full">Contribute Content</a>
                </div>
            <?php endif; ?>
            
            <?php if ($user['role'] === 'administrator' && !empty($roleData)): ?>
                <div class="sidebar-card admin-stats">
                    <h3>Platform Overview</h3>
                    <div class="stat-item">
                        <span class="stat-label">Total Users</span>
                        <span class="stat-value"><?= $roleData['total_users'] ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Pending Verifications</span>
                        <span class="stat-value"><?= $roleData['pending_verifications'] ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Content to Review</span>
                        <span class="stat-value"><?= $roleData['content_pending_review'] ?></span>
                    </div>
                    <a href="<?= BASE_URL ?>/admin" class="btn btn-secondary btn-full">Admin Panel</a>
                </div>
            <?php endif; ?>
            
            <!-- Help & Support -->
            <div class="sidebar-card help-card">
                <h3>Need Help?</h3>
                <p>Get the most out of your career journey with our resources.</p>
                <ul class="help-links">
                    <li><a href="/help/getting-started">Getting Started Guide</a></li>
                    <li><a href="/help/assessment">Assessment Tips</a></li>
                    <li><a href="/help/roadmaps">Understanding Roadmaps</a></li>
                    <li><a href="/contact">Contact Support</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<style>
.dashboard {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem 1rem;
}

.dashboard-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 2rem;
    padding-bottom: 2rem;
    border-bottom: 1px solid #f0f0f0;
}

.welcome-section h1 {
    color: #000000;
    margin-bottom: 0.5rem;
}

.dashboard-subtitle {
    color: #666666;
    font-size: 1.1rem;
    margin: 0;
}

.quick-actions {
    display: flex;
    gap: 1rem;
}

.progress-overview {
    margin-bottom: 3rem;
}

.progress-overview h2 {
    color: #000000;
    margin-bottom: 1.5rem;
}

.progress-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin-bottom: 2rem;
}

.progress-card {
    background: #ffffff;
    padding: 1.5rem;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    text-align: center;
}

.progress-content h3 {
    font-size: 2rem;
    color: #B9937B;
    margin-bottom: 0.25rem;
}

.progress-content p {
    color: #666666;
    margin: 0;
    font-size: 0.9rem;
}

.overall-progress {
    background: #f8f6f3;
    padding: 1.5rem;
    border-radius: 8px;
}

.progress-bar-container {
    width: 100%;
}

.progress-label {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: #000000;
}

.progress-bar {
    width: 100%;
    height: 8px;
    background-color: #e0e0e0;
    border-radius: 4px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background-color: #B9937B;
    transition: width 0.3s ease;
}

.dashboard-content {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 2rem;
}

.main-content {
    display: flex;
    flex-direction: column;
    gap: 2rem;
}

.recommendations-section,
.saved-careers-section,
.activity-section {
    background: #ffffff;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.recommendations-section h2,
.saved-careers-section h2,
.activity-section h2 {
    color: #000000;
    margin-bottom: 1rem;
}

.recommendations-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1rem;
    margin-bottom: 1rem;
}

.recommendation-card {
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 1.5rem;
    transition: box-shadow 0.3s ease;
}

.recommendation-card:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.recommendation-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 1rem;
}

.recommendation-header h3 {
    color: #000000;
    margin: 0;
    flex: 1;
}

.match-score {
    background-color: #B9937B;
    color: #ffffff;
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
}

.recommendation-description {
    color: #666666;
    margin-bottom: 1rem;
    line-height: 1.5;
}

.recommendation-meta {
    display: flex;
    gap: 1rem;
    margin-bottom: 1rem;
    font-size: 0.9rem;
}

.industry {
    color: #B9937B;
    font-weight: 600;
}

.skills-match {
    color: #666666;
}

.recommendation-actions {
    display: flex;
    gap: 0.5rem;
}

.section-footer {
    text-align: center;
    padding-top: 1rem;
    border-top: 1px solid #f0f0f0;
}

.view-all-link {
    color: #B9937B;
    text-decoration: none;
    font-weight: 600;
}

.view-all-link:hover {
    text-decoration: underline;
}

.saved-careers-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.saved-career-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
    border: 1px solid #e0e0e0;
    border-radius: 6px;
}

.career-info h4 {
    color: #000000;
    margin-bottom: 0.25rem;
}

.career-info p {
    color: #666666;
    margin: 0;
    font-size: 0.9rem;
}

.career-actions {
    display: flex;
    gap: 0.5rem;
}

.activity-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.activity-item {
    padding: 1rem;
    background-color: #f8f6f3;
    border-radius: 6px;
}

.activity-content p {
    color: #000000;
    margin-bottom: 0.25rem;
}

.activity-date {
    color: #666666;
    font-size: 0.8rem;
}

.sidebar {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.sidebar-card {
    background: #ffffff;
    padding: 1.5rem;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.sidebar-card h3 {
    color: #000000;
    margin-bottom: 1rem;
}

.assessment-cta {
    background: linear-gradient(135deg, #B9937B 0%, #9A7A5F 100%);
    color: #ffffff;
}

.assessment-cta h3,
.assessment-cta p {
    color: #ffffff;
}

.stat-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.5rem 0;
    border-bottom: 1px solid #f0f0f0;
}

.stat-item:last-child {
    border-bottom: none;
}

.stat-label {
    color: #666666;
    font-size: 0.9rem;
}

.stat-value {
    color: #B9937B;
    font-weight: 600;
}

.help-links {
    list-style: none;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.help-links a {
    color: #B9937B;
    text-decoration: none;
    font-size: 0.9rem;
}

.help-links a:hover {
    text-decoration: underline;
}

@media (max-width: 768px) {
    .dashboard-header {
        flex-direction: column;
        gap: 1rem;
    }
    
    .quick-actions {
        width: 100%;
    }
    
    .quick-actions .btn {
        flex: 1;
    }
    
    .progress-cards {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .dashboard-content {
        grid-template-columns: 1fr;
    }
    
    .recommendations-grid {
        grid-template-columns: 1fr;
    }
    
    .saved-career-item {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
    }
    
    .career-actions {
        width: 100%;
        justify-content: flex-end;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Save career functionality
    document.querySelectorAll('.save-career').forEach(button => {
        button.addEventListener('click', function() {
            const careerId = this.dataset.careerId;
            // Implement save career AJAX call
            console.log('Saving career:', careerId);
            this.textContent = 'Saved';
            this.disabled = true;
        });
    });
    
    // Remove career functionality
    document.querySelectorAll('.remove-career').forEach(button => {
        button.addEventListener('click', function() {
            const careerId = this.dataset.careerId;
            if (confirm('Remove this career from your saved list?')) {
                // Implement remove career AJAX call
                console.log('Removing career:', careerId);
                this.closest('.saved-career-item').remove();
            }
        });
    });
});
</script>