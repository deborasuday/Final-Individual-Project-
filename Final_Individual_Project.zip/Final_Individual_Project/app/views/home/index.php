<!-- Hero Section -->
<section class="hero">
    <div class="hero-container">
        <div class="hero-content">
            <h1 class="hero-title">Transform Career Confusion into Clear Direction</h1>
            <p class="hero-subtitle">
                Get structured, step-by-step guidance from career confusion to your dream job. 
                Our platform provides realistic roadmaps, skills assessments, and authentic insights 
                from professionals who've walked the path.
            </p>
            
            <?php if (!$isLoggedIn): ?>
                <div class="hero-actions">
                    <a href="<?= BASE_URL ?>/register" class="btn btn-primary btn-large">Start Your Journey</a>
                    <a href="/Final_Individual_Project/SIMPLE_CAREERS.php" class="btn btn-secondary btn-large">Explore Careers</a>
                </div>
            <?php else: ?>
                <div class="hero-actions">
                    <a href="<?= BASE_URL ?>/dashboard" class="btn btn-primary btn-large">Go to Dashboard</a>
                    <a href="/Final_Individual_Project/SIMPLE_ASSESSMENT.php" class="btn btn-secondary btn-large">Take Assessment</a>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="hero-visual">
            <div class="roadmap-preview">
                <div class="roadmap-step active">
                    <div class="step-number">1</div>
                    <div class="step-content">
                        <h4>Discover</h4>
                        <p>Take our comprehensive assessment</p>
                    </div>
                </div>
                <div class="roadmap-step">
                    <div class="step-number">2</div>
                    <div class="step-content">
                        <h4>Explore</h4>
                        <p>Browse structured career roadmaps</p>
                    </div>
                </div>
                <div class="roadmap-step">
                    <div class="step-number">3</div>
                    <div class="step-content">
                        <h4>Progress</h4>
                        <p>Follow step-by-step guidance</p>
                    </div>
                </div>
                <div class="roadmap-step">
                    <div class="step-number">4</div>
                    <div class="step-content">
                        <h4>Achieve</h4>
                        <p>Reach your career goals</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="features">
    <div class="container">
        <h2 class="section-title">Why Choose Our Platform?</h2>
        
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M9 11H1v3h8v3l3-4-3-4v2z"/>
                        <path d="M22 12h-6"/>
                        <path d="M16 16h6"/>
                        <path d="M16 8h6"/>
                    </svg>
                </div>
                <h3>Structured Roadmaps</h3>
                <p>Clear, step-by-step pathways from your current stage to your career goals. No more guessing what comes next.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="3"/>
                        <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1 1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
                    </svg>
                </div>
                <h3>Skills Assessment</h3>
                <p>Comprehensive evaluation of your current skills and interests to match you with the right career paths.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                        <circle cx="9" cy="7" r="4"/>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                    </svg>
                </div>
                <h3>Expert Insights</h3>
                <p>Learn from verified professionals and mentors who share real experiences and practical advice.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="22,12 18,12 15,21 9,3 6,12 2,12"/>
                    </svg>
                </div>
                <h3>Progress Tracking</h3>
                <p>Monitor your advancement through career stages with clear milestones and achievement markers.</p>
            </div>
        </div>
    </div>
</section>

<!-- How It Works Section -->
<section class="how-it-works">
    <div class="container">
        <h2 class="section-title">How It Works</h2>
        
        <div class="steps-container">
            <div class="step">
                <div class="step-number">01</div>
                <h3>Take the Assessment</h3>
                <p>Complete our comprehensive skills and interest evaluation to understand your strengths and preferences.</p>
            </div>
            
            <div class="step">
                <div class="step-number">02</div>
                <h3>Explore Career Matches</h3>
                <p>Browse personalized career recommendations based on your assessment results and interests.</p>
            </div>
            
            <div class="step">
                <div class="step-number">03</div>
                <h3>Follow Your Roadmap</h3>
                <p>Get detailed, step-by-step guidance with timelines, required skills, and learning resources.</p>
            </div>
            
            <div class="step">
                <div class="step-number">04</div>
                <h3>Track Progress</h3>
                <p>Monitor your advancement and adjust your path as you grow and develop new interests.</p>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta">
    <div class="container">
        <div class="cta-content">
            <h2>Ready to Transform Your Career Journey?</h2>
            <p>Join thousands of professionals who have found clarity and direction through our platform.</p>
            
            <?php if (!$isLoggedIn): ?>
                <a href="<?= BASE_URL ?>/register" class="btn btn-primary btn-large">Start Free Today</a>
            <?php else: ?>
                <a href="<?= BASE_URL ?>/assessment" class="btn btn-primary btn-large">Continue Your Journey</a>
            <?php endif; ?>
        </div>
    </div>
</section>