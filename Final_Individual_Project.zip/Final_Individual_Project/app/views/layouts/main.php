<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($title) ? htmlspecialchars($title) : APP_NAME ?></title>
    
    <!-- CSS Styles -->
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/css/main.css">
    <link rel="stylesheet" href="<?= ASSETS_URL ?>/css/responsive.css">
    
    <!-- Meta tags for SEO -->
    <meta name="description" content="Career guidance platform providing structured roadmaps and professional guidance">
    <meta name="keywords" content="career, guidance, roadmap, professional development">
    
    <!-- CSRF Token for forms -->
    <meta name="csrf-token" content="<?= generateCSRFToken() ?>">
</head>
<body>
    <!-- Navigation Header -->
    <header class="main-header">
        <nav class="navbar">
            <div class="nav-container">
                <a href="<?= BASE_URL ?>/" class="nav-brand">
                    <h1><?= APP_NAME ?></h1>
                </a>
                
                <div class="nav-menu">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <!-- Authenticated user menu -->
                        <a href="<?= BASE_URL ?>/dashboard" class="nav-link">Dashboard</a>
                        <a href="/Final_Individual_Project/SIMPLE_CAREERS.php" class="nav-link">Explore Careers</a>
                        <a href="/Final_Individual_Project/SIMPLE_ASSESSMENT.php" class="nav-link">Assessment</a>
                        
                        <?php if (isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['contributor', 'administrator'])): ?>
                            <a href="<?= BASE_URL ?>/contribute" class="nav-link">Contribute</a>
                        <?php endif; ?>
                        
                        <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'administrator'): ?>
                            <a href="<?= BASE_URL ?>/admin" class="nav-link">Admin</a>
                        <?php endif; ?>
                        
                        <div class="nav-dropdown">
                            <a href="#" class="nav-link dropdown-toggle">
                                <?= htmlspecialchars($_SESSION['user_email'] ?? 'User') ?>
                            </a>
                            <div class="dropdown-menu">
                                <a href="<?= BASE_URL ?>/profile" class="dropdown-item">Profile</a>
                                <a href="<?= BASE_URL ?>/logout" class="dropdown-item">Logout</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <!-- Guest user menu -->
                        <a href="<?= BASE_URL ?>/login" class="nav-link">Login</a>
                        <a href="<?= BASE_URL ?>/register" class="nav-link nav-cta">Get Started</a>
                    <?php endif; ?>
                </div>
                
                <!-- Mobile menu toggle -->
                <div class="nav-toggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </nav>
    </header>

    <!-- Main Content Area -->
    <main class="main-content">
        <!-- Flash Messages -->
        <?php if (isset($_SESSION['flash_message'])): ?>
            <div class="flash-message flash-<?= $_SESSION['flash_type'] ?? 'info' ?>">
                <?= htmlspecialchars($_SESSION['flash_message']) ?>
                <button class="flash-close">&times;</button>
            </div>
            <?php 
            unset($_SESSION['flash_message']);
            unset($_SESSION['flash_type']);
            ?>
        <?php endif; ?>
        
        <!-- Page Content -->
        <?= $content ?>
    </main>

    <!-- Footer -->
    <footer class="main-footer">
        <div class="footer-container">
            <div class="footer-section">
                <h3><?= APP_NAME ?></h3>
                <p>Transforming career confusion into clear direction through structured guidance and authentic insights.</p>
            </div>
            
            <div class="footer-section">
                <h4>Platform</h4>
                <ul>
                    <li><a href="/Final_Individual_Project/SIMPLE_CAREERS.php">Explore Careers</a></li>
                    <li><a href="/Final_Individual_Project/SIMPLE_ASSESSMENT.php">Take Assessment</a></li>
                    <li><a href="<?= BASE_URL ?>/api">API Documentation</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4>Community</h4>
                <ul>
                    <li><a href="<?= BASE_URL ?>/contribute">Become a Contributor</a></li>
                    <li><a href="<?= BASE_URL ?>/stories">Career Stories</a></li>
                    <li><a href="<?= BASE_URL ?>/contact">Contact Us</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4>Legal</h4>
                <ul>
                    <li><a href="<?= BASE_URL ?>/privacy">Privacy Policy</a></li>
                    <li><a href="<?= BASE_URL ?>/terms">Terms of Service</a></li>
                    <li><a href="<?= BASE_URL ?>/security">Security</a></li>
                </ul>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; <?= date('Y') ?> <?= APP_NAME ?>. All rights reserved.</p>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="<?= ASSETS_URL ?>/js/main.js"></script>
    
    <!-- Page-specific scripts -->
    <?php if (isset($scripts)): ?>
        <?php foreach ($scripts as $script): ?>
            <script src="<?= ASSETS_URL ?>/js/<?= $script ?>.js"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>