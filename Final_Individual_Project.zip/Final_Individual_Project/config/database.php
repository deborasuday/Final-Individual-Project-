<?php
/**
 * Database Configuration
 * Contains database connection settings and initialization
 */

// Load environment variables
require_once __DIR__ . '/env.php';

// Database configuration constants from environment
define('DB_HOST', env('DB_HOST', 'localhost'));
define('DB_NAME', env('DB_NAME', 'career_guidance_platform'));
define('DB_USER', env('DB_USER', 'root'));
define('DB_PASS', env('DB_PASS', ''));
define('DB_CHARSET', 'utf8mb4');

/**
 * Database connection class using PDO
 * Implements singleton pattern for efficient connection management
 */
class Database {
    private static $instance = null;
    private $connection;
    
    private function __construct() {
        // Try multiple connection methods
        $attempts = [
            ['host' => 'localhost', 'user' => 'root', 'pass' => ''],
            ['host' => 'localhost', 'user' => 'root', 'pass' => 'root'],
            ['host' => '127.0.0.1', 'user' => 'root', 'pass' => ''],
            ['host' => 'localhost', 'user' => 'root', 'pass' => 'password']
        ];
        
        $connected = false;
        
        foreach ($attempts as $attempt) {
            try {
                $dsn = "mysql:host={$attempt['host']};dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
                $options = [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ];
                
                $this->connection = new PDO($dsn, $attempt['user'], $attempt['pass'], $options);
                $connected = true;
                break;
            } catch (PDOException $e) {
                continue;
            }
        }
        
        if (!$connected) {
            die("
            <h1>Database Connection Failed</h1>
            <p>Could not connect to MySQL. Please ensure:</p>
            <ul style='text-align: left;'>
                <li>XAMPP is running</li>
                <li>MySQL service is started</li>
                <li>Database 'career_guidance_platform' exists</li>
            </ul>
            <p><a href='career_platform.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Use Standalone Version</a></p>
            <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 100px auto; padding: 20px; text-align: center; }
            ul { background: #f8f9fa; padding: 20px; border-radius: 5px; }
            </style>
            ");
        }
    }
    
    /**
     * Get singleton database instance
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Get PDO connection object
     */
    public function getConnection() {
        return $this->connection;
    }
    
    /**
     * Prevent cloning of singleton
     */
    private function __clone() {}
    
    /**
     * Prevent unserialization of singleton
     */
    public function __wakeup() {}
}

/**
 * Helper function to get database connection
 * Used by repositories and tests
 */
function getDBConnection() {
    return Database::getInstance()->getConnection();
}