<?php
// Simple database setup script
// Run this file once to create the database and tables

$host = 'localhost';
$username = 'root';
$password = '';

try {
    $conn = new mysqli($host, $username, $password);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $sql = file_get_contents(__DIR__ . '/database.sql');
    
    if ($conn->multi_query($sql)) {
        echo "Database setup completed successfully!<br>";
        echo "You can now use the application.<br>";
        echo "<a href='../index.php'>Go to Home Page</a>";
    } else {
        echo "Error setting up database: " . $conn->error;
    }
    
    $conn->close();
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>