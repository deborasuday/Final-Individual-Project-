﻿<?php
session_start();

// Handle different pages and actions
$page = $_GET['page'] ?? 'home';
$action = $_POST['action'] ?? '';

// Initialize users array if not exists
if (!isset($_SESSION['users'])) {
    $_SESSION['users'] = [];
}

// Handle registration
if ($action === 'register') {
    $user = [
        'id' => count($_SESSION['users']) + 1,
        'first_name' => $_POST['first_name'] ?? '',
        'last_name' => $_POST['last_name'] ?? '',
        'email' => $_POST['email'] ?? '',
        'password' => password_hash($_POST['password'] ?? '', PASSWORD_DEFAULT)
    ];
    $_SESSION['users'][] = $user;
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user'] = $user;
    header('Location: ?page=dashboard');
    exit;
}

// Handle login
if ($action === 'login') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    foreach ($_SESSION['users'] as $user) {
        if ($user['email'] === $email && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user'] = $user;
            header('Location: ?page=dashboard');
            exit;
        }
    }
    $error = "Invalid email or password";
}

// Handle logout
if ($action === 'logout') {
    unset($_SESSION['user_id'], $_SESSION['user']);
    header('Location: ?page=home');
    exit;
}

// Handle assessment submission
if ($action === 'submit_assessment') {
    $responses = [
        'skills' => $_POST['skills'] ?? [],
        'interests' => $_POST['interests'] ?? []
    ];
    
    // Calculate career matches
    $matches = calculateCareerMatches($responses);
    $_SESSION['assessment_results'] = $matches;
    header('Location: ?page=results');
    exit;
}

// Career matching function
function calculateCareerMatches($responses) {
    $careers = [
        ['title' => 'Software Developer', 'description' => 'Design and develop software applications', 'salary' => '$60,000 - $120,000', 'skills' => [1,2,6,13], 'interests' => ['technology','engineering']],
        ['title' => 'Data Scientist', 'description' => 'Analyze data to help business decisions', 'salary' => '$70,000 - $140,000', 'skills' => [2,6,9,10], 'interests' => ['technology','science']],
        ['title' => 'Project Manager', 'description' => 'Plan and execute projects', 'salary' => '$55,000 - $110,000', 'skills' => [3,4,5,14], 'interests' => ['business','management']],
        ['title' => 'UX Designer', 'description' => 'Design user interfaces', 'salary' => '$50,000 - $100,000', 'skills' => [7,4,6,14], 'interests' => ['creative','technology']],
        ['title' => 'Marketing Specialist', 'description' => 'Develop marketing campaigns', 'salary' => '$45,000 - $85,000', 'skills' => [8,4,12,14], 'interests' => ['business','media']],
        ['title' => 'Cybersecurity Analyst', 'description' => 'Protect systems from cyber threats', 'salary' => '$65,000 - $125,000', 'skills' => [1,6,10,13], 'interests' => ['technology','security']]
    ];
    
    foreach ($careers as &$career) {
        $skillScore = 0;
        $skillCount = 0;
        
        foreach ($career['skills'] as $skillId) {
            if (isset($responses['skills'][$skillId])) {
                $skillScore += $responses['skills'][$skillId];
                $skillCount++;
            }
        }
        
        $interestScore = 0;
        $interestCount = 0;
        
        foreach ($career['interests'] as $interest) {
            if (isset($responses['interests'][$interest])) {
                $interestScore += $responses['interests'][$interest];
                $interestCount++;
            }
        }
        
        $avgSkill = $skillCount > 0 ? $skillScore / $skillCount : 0;
        $avgInterest = $interestCount > 0 ? $interestScore / $interestCount : 0;
        
        $career['match'] = min(100, round(($avgSkill * 0.6 + $avgInterest * 0.4) * 20));
    }
    
    usort($careers, function($a, $b) { return $b['match'] - $a['match']; });
    return $careers;
}

$isLoggedIn = isset($_SESSION['user_id']);
$user = $_SESSION['user'] ?? null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Career Guidance Platform</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #f9f7f4 0%, #ffffff 50%, #f9f7f4 100%);
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        /* Header */
        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0,0,0,0.08);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: #B9937B;
            text-decoration: none;
        }
        
        .nav-links {
            display: flex;
            gap: 2rem;
            align-items: center;
        }
        
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s;
        }
        
        .nav-links a:hover {
            color: #B9937B;
        }
        
        .btn {
            background: linear-gradient(135deg, #B9937B 0%, #A68A6F 100%);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-block;
            box-shadow: 0 2px 8px rgba(185, 147, 123, 0.3);
        }
        
        .btn:hover {
            background: linear-gradient(135deg, #A68A6F 0%, #9A7A5F 100%);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(185, 147, 123, 0.4);
        }
        
        .btn-secondary {
            background: transparent;
            color: #B9937B;
            border: 2px solid #B9937B;
            box-shadow: none;
        }
        
        .btn-secondary:hover {
            background: #B9937B;
            color: white;
        }
        
        /* Main Content */
        .main-content {
            padding: 2rem 0;
        }
        
        .card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 2rem;
            margin: 2rem 0;
            box-shadow: 0 8px 25px rgba(0,0,0,0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(0,0,0,0.12);
        }
        
        /* Home Page */
        .hero {
            text-align: center;
            padding: 4rem 0;
        }
        
        .hero h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, #B9937B 0%, #A68A6F 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-weight: 700;
        }
        
        .hero p {
            font-size: 1.2rem;
            margin-bottom: 2rem;
            color: #666;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .hero-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        /* Forms */
        .form-container {
            max-width: 450px;
            margin: 0 auto;
        }
        
        .form-group {
            margin-bottom: 1.25rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.4rem;
            font-weight: 600;
            color: #333;
            font-size: 0.9rem;
        }
        
        .form-group input {
            width: 100%;
            padding: 0.7rem;
            border: 1px solid #d0d0d0;
            border-radius: 6px;
            font-size: 0.95rem;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
            background-color: #ffffff;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #B9937B;
            box-shadow: 0 0 0 3px rgba(185, 147, 123, 0.1);
        }
        
        .form-group input::placeholder {
            color: #999999;
            font-size: 0.9rem;
        }
        
        .error {
            color: #e74c3c;
            margin-top: 1rem;
            text-align: center;
            background: #f8d7da;
            padding: 0.75rem;
            border-radius: 6px;
            border: 1px solid #f5c6cb;
        }
        
        /* Dashboard */
        .dashboard-header {
            text-align: center;
            margin-bottom: 2.5rem;
        }
        
        .dashboard-header h1 {
            font-size: 2.2rem;
            margin-bottom: 1rem;
            color: #333;
        }
        
        .dashboard-nav {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
            flex-wrap: wrap;
        }
        
        /* Assessment */
        .assessment-section {
            margin-bottom: 2.5rem;
        }
        
        .assessment-section h3 {
            color: #B9937B;
            margin-bottom: 1.25rem;
            font-size: 1.4rem;
        }
        
        .skill-item, .interest-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            margin-bottom: 0.75rem;
            background: #f8f6f3;
            border-radius: 8px;
            transition: background-color 0.3s ease;
        }
        
        .skill-item:hover, .interest-item:hover {
            background: #f0ede8;
        }
        
        .rating-scale {
            display: flex;
            gap: 0.5rem;
            align-items: center;
        }
        
        .rating-scale input[type="radio"] {
            margin: 0 2px;
            accent-color: #B9937B;
        }
        
        .rating-scale label {
            font-size: 0.8rem;
            color: #666;
            margin: 0 0.25rem;
        }
        
        /* Career Grid */
        .career-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }
        
        .career-card {
            background: white;
            padding: 1.75rem;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .career-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        
        .career-card h3 {
            color: #B9937B;
            margin-bottom: 1rem;
            font-size: 1.3rem;
        }
        
        .salary {
            color: #27ae60;
            font-weight: bold;
            margin-top: 1rem;
            font-size: 1.1rem;
        }
        
        /* Results */
        .result-item {
            background: linear-gradient(135deg, #B9937B 0%, #A68A6F 100%);
            color: white;
            padding: 1.75rem;
            border-radius: 12px;
            margin-bottom: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 15px rgba(185, 147, 123, 0.3);
        }
        
        .match-score {
            font-size: 1.8rem;
            font-weight: bold;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 2.2rem;
            }
            
            .hero-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .nav-links {
                flex-direction: column;
                gap: 1rem;
            }
            
            .dashboard-nav {
                flex-direction: column;
                align-items: center;
            }
            
            .card {
                padding: 1.5rem;
                margin: 1rem 0;
            }
            
            .form-container {
                max-width: none;
            }
            
            .career-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 480px) {
            .container {
                padding: 0 1rem;
            }
            
            .card {
                padding: 1.25rem;
            }
            
            .hero h1 {
                font-size: 1.8rem;
            }
            
            .form-group input {
                padding: 0.65rem;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="container">
            <div class="nav">
                <a href="?page=home" class="logo">Career Platform</a>
                <div class="nav-links">
                    <?php if ($isLoggedIn): ?>
                        <span>Welcome, <?= htmlspecialchars($user['first_name'] ?? 'User') ?>!</span>
                        <a href="?page=dashboard">Dashboard</a>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="action" value="logout">
                            <button type="submit" class="btn btn-secondary">Logout</button>
                        </form>
                    <?php else: ?>
                        <a href="?page=login">Login</a>
                        <a href="?page=register" class="btn">Get Started</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="main-content">
        <div class="container">
            <?php if ($page === 'home'): ?>
                <!-- Landing Page -->
                <div class="hero">
                    <h1>Transform Your Career Journey</h1>
                    <p>Discover your ideal career path through our comprehensive assessment system. Get personalized recommendations and structured guidance to achieve your professional goals.</p>
                    <div class="hero-buttons">
                        <?php if (!$isLoggedIn): ?>
                            <a href="?page=register" class="btn">Start Your Journey</a>
                            <a href="?page=login" class="btn btn-secondary">Already Have Account?</a>
                        <?php else: ?>
                            <a href="?page=dashboard" class="btn">Go to Dashboard</a>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Features Section -->
                <div class="card" style="margin-top: 3rem;">
                    <h2 style="text-align: center; color: #B9937B; margin-bottom: 2rem; font-size: 2rem;">Why Choose Our Career Platform?</h2>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; margin-bottom: 3rem;">
                        <div style="text-align: center; padding: 1.5rem;">
                            <div style="font-size: 3rem; margin-bottom: 1rem; color: #B9937B; font-weight: bold;">●</div>
                            <h3 style="color: #B9937B; margin-bottom: 1rem;">Personalized Assessment</h3>
                            <p style="color: #666; line-height: 1.6;">Our comprehensive evaluation analyzes your skills and interests to provide tailored career recommendations that truly fit your profile.</p>
                        </div>
                        
                        <div style="text-align: center; padding: 1.5rem;">
                            <div style="font-size: 3rem; margin-bottom: 1rem; color: #B9937B; font-weight: bold;">●</div>
                            <h3 style="color: #B9937B; margin-bottom: 1rem;">Data-Driven Insights</h3>
                            <p style="color: #666; line-height: 1.6;">Get detailed career matches with salary information, growth prospects, and industry outlook based on current market data.</p>
                        </div>
                        
                        <div style="text-align: center; padding: 1.5rem;">
                            <div style="font-size: 3rem; margin-bottom: 1rem; color: #B9937B; font-weight: bold;">●</div>
                            <h3 style="color: #B9937B; margin-bottom: 1rem;">Step-by-Step Roadmaps</h3>
                            <p style="color: #666; line-height: 1.6;">Receive actionable career roadmaps with specific skills to develop, resources to use, and clear next steps to achieve your goals.</p>
                        </div>
                    </div>
                </div>

                <!-- Statistics Section -->
                <div class="card" style="background: linear-gradient(135deg, #B9937B 0%, #A68A6F 100%); color: white;">
                    <h2 style="text-align: center; margin-bottom: 2rem; color: white; font-size: 1.8rem;">Trusted by Professionals Worldwide</h2>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 2rem; text-align: center;">
                        <div>
                            <div style="font-size: 2.5rem; font-weight: bold; margin-bottom: 0.5rem;">15,000+</div>
                            <div style="color: #f0e6d9;">Career Assessments Completed</div>
                        </div>
                        <div>
                            <div style="font-size: 2.5rem; font-weight: bold; margin-bottom: 0.5rem;">500+</div>
                            <div style="color: #f0e6d9;">Career Paths Available</div>
                        </div>
                        <div>
                            <div style="font-size: 2.5rem; font-weight: bold; margin-bottom: 0.5rem;">95%</div>
                            <div style="color: #f0e6d9;">User Satisfaction Rate</div>
                        </div>
                        <div>
                            <div style="font-size: 2.5rem; font-weight: bold; margin-bottom: 0.5rem;">24/7</div>
                            <div style="color: #f0e6d9;">Platform Availability</div>
                        </div>
                    </div>
                </div>

                <!-- How It Works Section -->
                <div class="card">
                    <h2 style="text-align: center; color: #B9937B; margin-bottom: 2rem; font-size: 1.8rem;">How It Works - Simple 3-Step Process</h2>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem;">
                        <div style="text-align: center; padding: 1.5rem; background: #f8f6f3; border-radius: 12px;">
                            <div style="background: #B9937B; color: white; width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; font-weight: bold; margin: 0 auto 1rem;">1</div>
                            <h3 style="color: #B9937B; margin-bottom: 1rem;">Take Assessment</h3>
                            <p style="color: #666; line-height: 1.6;">Complete our comprehensive skills and interests evaluation in just 10-15 minutes.</p>
                        </div>
                        
                        <div style="text-align: center; padding: 1.5rem; background: #f8f6f3; border-radius: 12px;">
                            <div style="background: #B9937B; color: white; width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; font-weight: bold; margin: 0 auto 1rem;">2</div>
                            <h3 style="color: #B9937B; margin-bottom: 1rem;">Get Matches</h3>
                            <p style="color: #666; line-height: 1.6;">Receive personalized career recommendations with detailed explanations and match percentages.</p>
                        </div>
                        
                        <div style="text-align: center; padding: 1.5rem; background: #f8f6f3; border-radius: 12px;">
                            <div style="background: #B9937B; color: white; width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; font-weight: bold; margin: 0 auto 1rem;">3</div>
                            <h3 style="color: #B9937B; margin-bottom: 1rem;">Start Your Journey</h3>
                            <p style="color: #666; line-height: 1.6;">Follow your personalized roadmap with actionable steps, resources, and skill development plans.</p>
                        </div>
                    </div>
                </div>

                <!-- Testimonials Section -->
                <div class="card" style="background: #f8f6f3;">
                    <h2 style="text-align: center; color: #B9937B; margin-bottom: 2rem; font-size: 1.8rem;">What Our Users Say</h2>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
                        <div style="background: white; padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.08);">
                            <div style="color: #f39c12; font-size: 1.2rem; margin-bottom: 1rem;"></div>
                            <p style="color: #555; line-height: 1.6; margin-bottom: 1rem; font-style: italic;">"This platform helped me transition from marketing to UX design. The assessment was spot-on and the roadmap gave me clear direction!"</p>
                            <div style="font-weight: 600; color: #B9937B;">- Sarah Chen, UX Designer</div>
                        </div>
                        
                        <div style="background: white; padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.08);">
                            <div style="color: #f39c12; font-size: 1.2rem; margin-bottom: 1rem;"></div>
                            <p style="color: #555; line-height: 1.6; margin-bottom: 1rem; font-style: italic;">"I discovered my passion for data science through this assessment. Now I'm working at a Fortune 500 company!"</p>
                            <div style="font-weight: 600; color: #B9937B;">- Michael Rodriguez, Data Scientist</div>
                        </div>
                        
                        <div style="background: white; padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.08);">
                            <div style="color: #f39c12; font-size: 1.2rem; margin-bottom: 1rem;"></div>
                            <p style="color: #555; line-height: 1.6; margin-bottom: 1rem; font-style: italic;">"The detailed career information and growth paths helped me make an informed decision about my future in cybersecurity."</p>
                            <div style="font-weight: 600; color: #B9937B;">- Jessica Park, Security Analyst</div>
                        </div>
                    </div>
                </div>

                <!-- CTA Section -->
                <?php if (!$isLoggedIn): ?>
                <div class="card" style="background: linear-gradient(135deg, #B9937B 0%, #A68A6F 100%); color: white; text-align: center;">
                    <h2 style="color: white; margin-bottom: 1rem; font-size: 1.8rem;">Ready to Transform Your Career?</h2>
                    <p style="color: #f0e6d9; margin-bottom: 2rem; font-size: 1.1rem;">Join thousands of professionals who have discovered their ideal career path with our platform.</p>
                    <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                        <a href="?page=register" class="btn" style="background: white; color: #B9937B; font-size: 1.1rem; padding: 1rem 2rem;">Start Free Assessment</a>
                        <a href="?page=careers" class="btn" style="background: transparent; border: 2px solid white; color: white;">Explore Careers</a>
                    </div>
                </div>
                <?php endif; ?>

            <?php elseif ($page === 'register'): ?>
                <!-- Register Page -->
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 3rem; align-items: start; max-width: 1100px; margin: 0 auto;">
                    <!-- Registration Form -->
                    <div class="card">
                        <div class="form-container">
                            <h2 style="text-align: center; margin-bottom: 1rem; color: #B9937B; font-size: 1.75rem;">Start Your Career Journey</h2>
                            <p style="text-align: center; color: #666; margin-bottom: 1.5rem;">Join thousands of professionals who have transformed their careers with our platform.</p>
                            
                            <form method="POST">
                                <input type="hidden" name="action" value="register">
                                <div class="form-group">
                                    <label>First Name</label>
                                    <input type="text" name="first_name" required placeholder="Enter your first name">
                                </div>
                                <div class="form-group">
                                    <label>Last Name</label>
                                    <input type="text" name="last_name" required placeholder="Enter your last name">
                                </div>
                                <div class="form-group">
                                    <label>Email Address</label>
                                    <input type="email" name="email" required placeholder="your.email@example.com">
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input type="password" name="password" required placeholder="Create a secure password">
                                </div>
                                <button type="submit" class="btn" style="width: 100%; font-size: 1.1rem; padding: 0.85rem;">Create Free Account</button>
                            </form>
                            
                            <div style="text-align: center; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid #e0e0e0;">
                                <p style="color: #666; margin-bottom: 0.5rem;">Already have an account?</p>
                                <a href="?page=login" style="color: #B9937B; font-weight: 600; text-decoration: none;">Sign in here →</a>
                            </div>
                        </div>
                    </div>

                    <!-- Benefits Section -->
                    <div class="card" style="background: #f8f6f3;">
                        <h3 style="color: #B9937B; margin-bottom: 1.5rem; text-align: center;">What You'll Get (100% Free)</h3>
                        
                        <div style="space-y: 1rem;">
                            <div style="display: flex; align-items: start; gap: 1rem; margin-bottom: 1.25rem;">
                                <div style="background: #B9937B; color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.9rem; flex-shrink: 0;"></div>
                                <div>
                                    <h4 style="color: #B9937B; margin-bottom: 0.25rem;">Personalized Career Assessment</h4>
                                    <p style="color: #666; font-size: 0.9rem; line-height: 1.5;">Comprehensive evaluation of your skills and interests with detailed analysis.</p>
                                </div>
                            </div>
                            
                            <div style="display: flex; align-items: start; gap: 1rem; margin-bottom: 1.25rem;">
                                <div style="background: #B9937B; color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.9rem; flex-shrink: 0;"></div>
                                <div>
                                    <h4 style="color: #B9937B; margin-bottom: 0.25rem;">Career Match Reports</h4>
                                    <p style="color: #666; font-size: 0.9rem; line-height: 1.5;">Detailed reports showing your top career matches with percentage compatibility.</p>
                                </div>
                            </div>
                            
                            <div style="display: flex; align-items: start; gap: 1rem; margin-bottom: 1.25rem;">
                                <div style="background: #B9937B; color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.9rem; flex-shrink: 0;"></div>
                                <div>
                                    <h4 style="color: #B9937B; margin-bottom: 0.25rem;">Step-by-Step Roadmaps</h4>
                                    <p style="color: #666; font-size: 0.9rem; line-height: 1.5;">Actionable career paths with skills to develop and resources to use.</p>
                                </div>
                            </div>
                            
                            <div style="display: flex; align-items: start; gap: 1rem; margin-bottom: 1.25rem;">
                                <div style="background: #B9937B; color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.9rem; flex-shrink: 0;"></div>
                                <div>
                                    <h4 style="color: #B9937B; margin-bottom: 0.25rem;">Career Database Access</h4>
                                    <p style="color: #666; font-size: 0.9rem; line-height: 1.5;">Explore 500+ careers with salary data, growth prospects, and requirements.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div style="background: white; padding: 1rem; border-radius: 8px; margin-top: 1.5rem; text-align: center;">
                            <div style="color: #27ae60; font-weight: bold; margin-bottom: 0.5rem;">� Success Rate: 95%</div>
                            <p style="color: #666; font-size: 0.85rem;">of users find their assessment results helpful for career decisions</p>
                        </div>
                    </div>
                </div>

                <!-- Mobile Responsive -->
                <style>
                @media (max-width: 768px) {
                    .register-container {
                        grid-template-columns: 1fr !important;
                        gap: 2rem !important;
                    }
                }
                </style>

            <?php elseif ($page === 'login'): ?>
                <!-- Login Page -->
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 3rem; align-items: start; max-width: 1100px; margin: 0 auto;">
                    <!-- Login Form -->
                    <div class="card">
                        <div class="form-container">
                            <h2 style="text-align: center; margin-bottom: 1rem; color: #B9937B; font-size: 1.75rem;">Welcome Back!</h2>
                            <p style="text-align: center; color: #666; margin-bottom: 1.5rem;">Continue your career journey where you left off.</p>
                            
                            <?php if (isset($error)): ?>
                                <div class="error"><?= htmlspecialchars($error) ?></div>
                            <?php endif; ?>
                            
                            <form method="POST">
                                <input type="hidden" name="action" value="login">
                                <div class="form-group">
                                    <label>Email Address</label>
                                    <input type="email" name="email" required placeholder="your.email@example.com">
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input type="password" name="password" required placeholder="Enter your password">
                                </div>
                                <button type="submit" class="btn" style="width: 100%; font-size: 1.1rem; padding: 0.85rem;">Sign In to Dashboard</button>
                            </form>
                            
                            <div style="text-align: center; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid #e0e0e0;">
                                <p style="color: #666; margin-bottom: 0.5rem;">New to our platform?</p>
                                <a href="?page=register" style="color: #B9937B; font-weight: 600; text-decoration: none;">Create free account →</a>
                            </div>
                        </div>
                    </div>

                    <!-- Welcome Back Section -->
                    <div class="card" style="background: linear-gradient(135deg, #B9937B 0%, #A68A6F 100%); color: white;">
                        <h3 style="color: white; margin-bottom: 1.5rem; text-align: center;">Welcome Back to Your Career Journey!</h3>
                        
                        <div style="space-y: 1rem;">
                            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                                <div style="font-size: 1.5rem;">�</div>
                                <div>
                                    <h4 style="color: white; margin-bottom: 0.25rem;">Your Assessment Results</h4>
                                    <p style="color: #f0e6d9; font-size: 0.9rem;">Access your personalized career matches and detailed analysis</p>
                                </div>
                            </div>
                            
                            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                                <div style="font-size: 1.5rem;">�</div>
                                <div>
                                    <h4 style="color: white; margin-bottom: 0.25rem;">Career Roadmaps</h4>
                                    <p style="color: #f0e6d9; font-size: 0.9rem;">Follow your step-by-step career development plan</p>
                                </div>
                            </div>
                            
                            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                                <div style="font-size: 1.5rem;"></div>
                                <div>
                                    <h4 style="color: white; margin-bottom: 0.25rem;">Progress Tracking</h4>
                                    <p style="color: #f0e6d9; font-size: 0.9rem;">Monitor your career development journey</p>
                                </div>
                            </div>
                            
                            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem;">
                                <div style="font-size: 1.5rem;"></div>
                                <div>
                                    <h4 style="color: white; margin-bottom: 0.25rem;">Skill Development</h4>
                                    <p style="color: #f0e6d9; font-size: 0.9rem;">Get recommendations for courses and resources</p>
                                </div>
                            </div>
                        </div>
                        
                        <div style="background: rgba(255,255,255,0.1); padding: 1rem; border-radius: 8px; text-align: center;">
                            <div style="font-weight: bold; margin-bottom: 0.5rem;"> Ready to Continue?</div>
                            <p style="color: #f0e6d9; font-size: 0.85rem;">Your personalized dashboard is waiting with updated career insights and recommendations.</p>
                        </div>
                    </div>
                </div>

                <!-- Mobile Responsive -->
                <style>
                @media (max-width: 768px) {
                    .login-container {
                        grid-template-columns: 1fr !important;
                        gap: 2rem !important;
                    }
                }
                </style>

            <?php elseif ($page === 'dashboard' && $isLoggedIn): ?>
                <!-- Dashboard Page -->
                <div class="card">
                    <div class="dashboard-header">
                        <h1>Welcome back, <?= htmlspecialchars($user['first_name'] ?? 'User') ?>!</h1>
                        <p style="font-size: 1.1rem; color: #666;">Your personalized career guidance dashboard is ready. Let's continue building your professional future!</p>
                    </div>
                </div>

                <!-- Progress Overview -->
                <div class="card" style="background: linear-gradient(135deg, #f8f6f3 0%, #ffffff 100%);">
                    <h2 style="color: #B9937B; margin-bottom: 1.5rem; text-align: center;">Your Career Journey Progress</h2>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
                        <div style="background: white; padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); text-align: center;">
                            <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">
                                <?= isset($_SESSION['assessment_results']) ? '' : '' ?>
                            </div>
                            <h3 style="color: #B9937B; margin-bottom: 0.5rem;">Assessment</h3>
                            <p style="color: #666; font-size: 0.9rem;">
                                <?= isset($_SESSION['assessment_results']) ? 'Completed! View your results.' : 'Take our comprehensive career assessment.' ?>
                            </p>
                            <?php if (!isset($_SESSION['assessment_results'])): ?>
                                <a href="?page=assessment" class="btn" style="margin-top: 1rem; padding: 0.5rem 1rem; font-size: 0.9rem;">Start Assessment</a>
                            <?php else: ?>
                                <a href="?page=results" class="btn" style="margin-top: 1rem; padding: 0.5rem 1rem; font-size: 0.9rem;">View Results</a>
                            <?php endif; ?>
                        </div>
                        
                        <div style="background: white; padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); text-align: center;">
                            <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">�</div>
                            <h3 style="color: #B9937B; margin-bottom: 0.5rem;">Career Matches</h3>
                            <p style="color: #666; font-size: 0.9rem;">
                                <?= isset($_SESSION['assessment_results']) ? count($_SESSION['assessment_results']) . ' personalized matches found!' : 'Discover careers that fit your profile.' ?>
                            </p>
                            <a href="?page=careers" class="btn btn-secondary" style="margin-top: 1rem; padding: 0.5rem 1rem; font-size: 0.9rem;">Explore Careers</a>
                        </div>
                        
                        <div style="background: white; padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); text-align: center;">
                            <div style="font-size: 2.5rem; margin-bottom: 0.5rem;"></div>
                            <h3 style="color: #B9937B; margin-bottom: 0.5rem;">Next Steps</h3>
                            <p style="color: #666; font-size: 0.9rem;">
                                <?= isset($_SESSION['assessment_results']) ? 'Follow your personalized roadmap.' : 'Get actionable career guidance.' ?>
                            </p>
                            <?php if (isset($_SESSION['assessment_results'])): ?>
                                <a href="?page=results" class="btn" style="margin-top: 1rem; padding: 0.5rem 1rem; font-size: 0.9rem;">View Roadmap</a>
                            <?php else: ?>
                                <a href="?page=assessment" class="btn" style="margin-top: 1rem; padding: 0.5rem 1rem; font-size: 0.9rem;">Get Started</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="card">
                    <h2 style="color: #B9937B; margin-bottom: 1.5rem; text-align: center;">Quick Actions </h2>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem;">
                        <div style="background: #f8f6f3; padding: 1.5rem; border-radius: 12px; border-left: 4px solid #B9937B;">
                            <h3 style="color: #B9937B; margin-bottom: 1rem; display: flex; align-items: center; gap: 0.5rem;">
                                � Career Assessment
                            </h3>
                            <p style="color: #666; margin-bottom: 1rem; line-height: 1.5;">
                                <?= isset($_SESSION['assessment_results']) ? 'Retake the assessment to update your career matches or explore new possibilities.' : 'Take our comprehensive 15-minute assessment to discover careers that match your skills and interests.' ?>
                            </p>
                            <a href="?page=assessment" class="btn" style="width: 100%;">
                                <?= isset($_SESSION['assessment_results']) ? 'Retake Assessment' : 'Start Assessment' ?>
                            </a>
                        </div>
                        
                        <div style="background: #f0f8f0; padding: 1.5rem; border-radius: 12px; border-left: 4px solid #27ae60;">
                            <h3 style="color: #27ae60; margin-bottom: 1rem; display: flex; align-items: center; gap: 0.5rem;">
                                � Career Explorer
                            </h3>
                            <p style="color: #666; margin-bottom: 1rem; line-height: 1.5;">Browse our comprehensive database of 500+ careers with detailed information, salary ranges, and growth prospects.</p>
                            <a href="?page=careers" class="btn btn-secondary" style="width: 100%; border-color: #27ae60; color: #27ae60;">Explore Careers</a>
                        </div>
                        
                        <?php if (isset($_SESSION['assessment_results'])): ?>
                        <div style="background: #e8f4f8; padding: 1.5rem; border-radius: 12px; border-left: 4px solid #3498db;">
                            <h3 style="color: #3498db; margin-bottom: 1rem; display: flex; align-items: center; gap: 0.5rem;">
                                 Your Results
                            </h3>
                            <p style="color: #666; margin-bottom: 1rem; line-height: 1.5;">Review your personalized career matches, detailed roadmaps, and actionable next steps for your professional journey.</p>
                            <a href="?page=results" class="btn" style="width: 100%; background: #3498db;">View Detailed Results</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Platform Benefits -->
                <div class="card" style="background: linear-gradient(135deg, #B9937B 0%, #A68A6F 100%); color: white;">
                    <h2 style="color: white; margin-bottom: 1.5rem; text-align: center;">Why You Made the Right Choice �</h2>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
                        <div style="text-align: center;">
                            <div style="font-size: 2rem; margin-bottom: 0.5rem;">�</div>
                            <h4 style="color: white; margin-bottom: 0.5rem;">Personalized Matching</h4>
                            <p style="color: #f0e6d9; font-size: 0.9rem;">AI-powered assessment analyzes your unique profile</p>
                        </div>
                        
                        <div style="text-align: center;">
                            <div style="font-size: 2rem; margin-bottom: 0.5rem;"></div>
                            <h4 style="color: white; margin-bottom: 0.5rem;">Real Market Data</h4>
                            <p style="color: #f0e6d9; font-size: 0.9rem;">Current salary ranges and job growth statistics</p>
                        </div>
                        
                        <div style="text-align: center;">
                            <div style="font-size: 2rem; margin-bottom: 0.5rem;">�</div>
                            <h4 style="color: white; margin-bottom: 0.5rem;">Actionable Roadmaps</h4>
                            <p style="color: #f0e6d9; font-size: 0.9rem;">Step-by-step guidance with resources and timelines</p>
                        </div>
                        
                        <div style="text-align: center;">
                            <div style="font-size: 2rem; margin-bottom: 0.5rem;"></div>
                            <h4 style="color: white; margin-bottom: 0.5rem;">Continuous Updates</h4>
                            <p style="color: #f0e6d9; font-size: 0.9rem;">Regular assessment updates as you grow professionally</p>
                        </div>
                    </div>
                </div>

            <?php elseif ($page === 'assessment' && $isLoggedIn): ?>
                <!-- Assessment Page -->
                <div class="card">
                    <h2 style="text-align: center; color: #B9937B; margin-bottom: 1.5rem; font-size: 1.75rem;">Career Assessment</h2>
                    <form method="POST">
                        <input type="hidden" name="action" value="submit_assessment">
                        
                        <div class="assessment-section">
                            <h3>Skills Assessment</h3>
                            <p>Rate your proficiency in each skill (1 = Beginner, 5 = Expert):</p>
                            
                            <?php 
                            $skills = [
                                1 => 'Programming/Coding',
                                2 => 'Data Analysis', 
                                3 => 'Project Management',
                                4 => 'Communication',
                                5 => 'Leadership',
                                6 => 'Problem Solving',
                                7 => 'Creative Design',
                                8 => 'Sales & Marketing',
                                9 => 'Financial Analysis',
                                10 => 'Research & Analysis',
                                11 => 'Teaching/Training',
                                12 => 'Customer Service',
                                13 => 'Technical Writing',
                                14 => 'Team Collaboration'
                            ];
                            
                            foreach ($skills as $id => $skill): ?>
                                <div class="skill-item">
                                    <label><?= $skill ?></label>
                                    <div class="rating-scale">
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <input type="radio" name="skills[<?= $id ?>]" value="<?= $i ?>" required> <?= $i ?>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="assessment-section">
                            <h3>Interest Assessment</h3>
                            <p>Rate your interest in each area (1 = Not Interested, 5 = Very Interested):</p>
                            
                            <?php 
                            $interests = [
                                'technology' => 'Technology & Computing',
                                'science' => 'Science & Research',
                                'business' => 'Business & Management',
                                'creative' => 'Creative & Arts',
                                'engineering' => 'Engineering',
                                'media' => 'Media & Communications',
                                'management' => 'Leadership & Management',
                                'security' => 'Security & Protection'
                            ];
                            
                            foreach ($interests as $key => $interest): ?>
                                <div class="interest-item">
                                    <label><?= $interest ?></label>
                                    <div class="rating-scale">
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <input type="radio" name="interests[<?= $key ?>]" value="<?= $i ?>" required> <?= $i ?>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <button type="submit" class="btn" style="width: 100%; margin-top: 2rem;">Submit Assessment</button>
                    </form>
                </div>

            <?php elseif ($page === 'results' && $isLoggedIn && isset($_SESSION['assessment_results'])): ?>
                <!-- Results Page -->
                <div class="card">
                    <h2 style="text-align: center; color: #B9937B; margin-bottom: 1.5rem; font-size: 1.75rem;">Your Personalized Career Assessment Results �</h2>
                    
                    <!-- Assessment Summary -->
                    <div style="background: #f8f6f3; padding: 1.5rem; border-radius: 8px; margin-bottom: 2rem; text-align: center;">
                        <h3 style="color: #B9937B; margin-bottom: 1rem;">Assessment Complete!</h3>
                        <p style="color: #666; margin-bottom: 0.5rem;">Based on your skills evaluation and interest preferences, we've identified your top career matches.</p>
                        <p style="color: #666; font-size: 0.9rem;"><strong>Assessment Date:</strong> <?= date('F j, Y') ?> | <strong>Participant:</strong> <?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></p>
                    </div>

                    <!-- Top Career Matches -->
                    <h3 style="color: #B9937B; margin-bottom: 1.5rem; text-align: center;">Your Top Career Matches</h3>
                    
                    <?php 
                    $careerDetails = [
                        'Software Developer' => [
                            'detailed_description' => 'As a Software Developer, you\'ll design, build, and maintain applications that solve real-world problems. This role combines creativity with technical expertise, allowing you to work on everything from mobile apps to enterprise systems.',
                            'why_match' => 'Your strong analytical thinking and problem-solving skills align perfectly with software development. Your interest in technology and logical approach make this an excellent career path.',
                            'daily_tasks' => ['Write and debug code', 'Collaborate with team members', 'Design software architecture', 'Test applications', 'Maintain existing systems'],
                            'growth_path' => 'Junior Developer → Senior Developer → Lead Developer → Software Architect → Engineering Manager',
                            'skills_needed' => ['Programming Languages (Python, Java, JavaScript)', 'Problem Solving', 'Version Control (Git)', 'Database Management', 'Software Testing'],
                            'industry_outlook' => 'The software development field is experiencing unprecedented growth with 22% job growth expected through 2030, much faster than average.',
                            'next_steps' => ['Learn a programming language (Python or JavaScript recommended)', 'Build a portfolio of projects', 'Contribute to open-source projects', 'Consider a coding bootcamp or CS degree']
                        ],
                        'Data Scientist' => [
                            'detailed_description' => 'Data Scientists extract insights from complex datasets to drive business decisions. You\'ll work with statistical models, machine learning algorithms, and data visualization tools to uncover patterns and trends.',
                            'why_match' => 'Your analytical mindset and attention to detail make you well-suited for data science. Your interest in research and problem-solving aligns with this data-driven field.',
                            'daily_tasks' => ['Analyze large datasets', 'Build predictive models', 'Create data visualizations', 'Present findings to stakeholders', 'Clean and prepare data'],
                            'growth_path' => 'Junior Data Analyst → Data Scientist → Senior Data Scientist → Lead Data Scientist → Chief Data Officer',
                            'skills_needed' => ['Python/R Programming', 'Statistics & Mathematics', 'Machine Learning', 'Data Visualization', 'SQL & Databases'],
                            'industry_outlook' => 'Data Science is one of the fastest-growing fields with 31% job growth expected, driven by increasing data generation and AI adoption.',
                            'next_steps' => ['Learn Python and statistics', 'Complete online courses (Coursera, edX)', 'Work on data projects', 'Build a portfolio on GitHub']
                        ],
                        'UX Designer' => [
                            'detailed_description' => 'UX Designers create intuitive and engaging user experiences for digital products. You\'ll research user needs, design interfaces, and test solutions to ensure products are both functional and delightful to use.',
                            'why_match' => 'Your creative thinking and empathy for users make you a natural fit for UX design. Your attention to detail and communication skills are essential in this field.',
                            'daily_tasks' => ['Conduct user research', 'Create wireframes and prototypes', 'Design user interfaces', 'Test usability', 'Collaborate with developers'],
                            'growth_path' => 'Junior UX Designer → UX Designer → Senior UX Designer → UX Lead → Design Director',
                            'skills_needed' => ['Design Tools (Figma, Sketch)', 'User Research', 'Prototyping', 'Information Architecture', 'Usability Testing'],
                            'industry_outlook' => 'UX Design is growing rapidly with 13% job growth expected as companies prioritize user experience in digital transformation.',
                            'next_steps' => ['Learn design tools (Figma, Adobe XD)', 'Study UX principles', 'Create a design portfolio', 'Take UX courses or bootcamps']
                        ],
                        'Project Manager' => [
                            'detailed_description' => 'Project Managers coordinate teams, resources, and timelines to deliver successful projects. You\'ll be the central hub ensuring projects stay on track, within budget, and meet quality standards.',
                            'why_match' => 'Your organizational skills and leadership abilities make you well-suited for project management. Your communication skills and ability to see the big picture are key strengths.',
                            'daily_tasks' => ['Plan project timelines', 'Coordinate team activities', 'Manage budgets and resources', 'Communicate with stakeholders', 'Monitor project progress'],
                            'growth_path' => 'Assistant Project Manager → Project Manager → Senior Project Manager → Program Manager → Portfolio Manager',
                            'skills_needed' => ['Project Management Tools', 'Leadership', 'Communication', 'Risk Management', 'Budgeting'],
                            'industry_outlook' => 'Project Management roles are growing at 11% with increasing demand across all industries for skilled project coordinators.',
                            'next_steps' => ['Get PMP certification', 'Learn project management tools (Asana, Jira)', 'Gain leadership experience', 'Study project management methodologies']
                        ],
                        'Marketing Specialist' => [
                            'detailed_description' => 'Marketing Specialists develop and execute campaigns to promote products and build brand awareness. You\'ll work across digital and traditional channels to reach target audiences and drive business growth.',
                            'why_match' => 'Your creativity and communication skills are perfect for marketing. Your understanding of people and trends makes you well-suited for this dynamic field.',
                            'daily_tasks' => ['Develop marketing campaigns', 'Analyze market trends', 'Create content', 'Manage social media', 'Track campaign performance'],
                            'growth_path' => 'Marketing Assistant → Marketing Specialist → Marketing Manager → Marketing Director → Chief Marketing Officer',
                            'skills_needed' => ['Digital Marketing', 'Content Creation', 'Analytics', 'Social Media Management', 'Brand Strategy'],
                            'industry_outlook' => 'Digital Marketing is experiencing 19% growth as businesses shift to online channels and data-driven marketing strategies.',
                            'next_steps' => ['Learn digital marketing tools', 'Get Google Analytics certified', 'Build a personal brand', 'Create marketing campaigns']
                        ],
                        'Cybersecurity Analyst' => [
                            'detailed_description' => 'Cybersecurity Analysts protect organizations from digital threats by monitoring systems, investigating security breaches, and implementing protective measures.',
                            'why_match' => 'Your analytical thinking and attention to detail are crucial for cybersecurity. Your interest in technology and problem-solving align with this critical field.',
                            'daily_tasks' => ['Monitor security systems', 'Investigate security incidents', 'Implement security measures', 'Conduct risk assessments', 'Train staff on security'],
                            'growth_path' => 'Security Analyst → Senior Security Analyst → Security Manager → Security Architect → Chief Security Officer',
                            'skills_needed' => ['Network Security', 'Incident Response', 'Risk Assessment', 'Security Tools', 'Compliance'],
                            'industry_outlook' => 'Cybersecurity is the fastest-growing field with 35% job growth expected due to increasing cyber threats and digital transformation.',
                            'next_steps' => ['Get Security+ certification', 'Learn networking fundamentals', 'Practice with security tools', 'Study cybersecurity frameworks']
                        ]
                    ];
                    
                    foreach ($_SESSION['assessment_results'] as $index => $career): 
                        $details = $careerDetails[$career['title']] ?? null;
                        $matchLevel = $career['match'] >= 80 ? 'Excellent' : ($career['match'] >= 60 ? 'Good' : 'Moderate');
                        $matchColor = $career['match'] >= 80 ? '#27ae60' : ($career['match'] >= 60 ? '#f39c12' : '#e74c3c');
                    ?>
                        <div style="background: white; border: 1px solid #e0e0e0; border-radius: 12px; padding: 2rem; margin-bottom: 2rem; box-shadow: 0 4px 15px rgba(0,0,0,0.08);">
                            <!-- Career Header -->
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap;">
                                <div>
                                    <h3 style="color: #B9937B; margin-bottom: 0.5rem; font-size: 1.4rem;"><?= htmlspecialchars($career['title']) ?></h3>
                                    <div style="display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;">
                                        <span style="background: <?= $matchColor ?>; color: white; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.9rem; font-weight: 600;">
                                            <?= $career['match'] ?>% Match - <?= $matchLevel ?>
                                        </span>
                                        <span style="color: #27ae60; font-weight: 600; font-size: 1.1rem;"><?= htmlspecialchars($career['salary']) ?></span>
                                    </div>
                                </div>
                                <div style="text-align: center;">
                                    <div style="font-size: 2rem; margin-bottom: 0.5rem;"><?= $index === 0 ? '' : ($index === 1 ? '' : '') ?></div>
                                    <div style="font-size: 0.8rem; color: #666;"><?= $index === 0 ? 'Top Match' : ($index === 1 ? '2nd Best' : '3rd Best') ?></div>
                                </div>
                            </div>

                            <?php if ($details): ?>
                                <!-- Detailed Description -->
                                <div style="margin-bottom: 1.5rem;">
                                    <h4 style="color: #B9937B; margin-bottom: 0.75rem;">What You'll Do</h4>
                                    <p style="color: #555; line-height: 1.6; margin-bottom: 1rem;"><?= htmlspecialchars($details['detailed_description']) ?></p>
                                </div>

                                <!-- Why It Matches -->
                                <div style="background: #f0f8f0; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem; border-left: 4px solid #27ae60;">
                                    <h4 style="color: #27ae60; margin-bottom: 0.75rem;">� Why This Matches You</h4>
                                    <p style="color: #555; line-height: 1.6; margin: 0;"><?= htmlspecialchars($details['why_match']) ?></p>
                                </div>

                                <!-- Daily Tasks -->
                                <div style="margin-bottom: 1.5rem;">
                                    <h4 style="color: #B9937B; margin-bottom: 0.75rem;"> Typical Daily Tasks</h4>
                                    <ul style="color: #555; line-height: 1.6; padding-left: 1.5rem;">
                                        <?php foreach ($details['daily_tasks'] as $task): ?>
                                            <li style="margin-bottom: 0.25rem;"><?= htmlspecialchars($task) ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>

                                <!-- Career Growth Path -->
                                <div style="margin-bottom: 1.5rem;">
                                    <h4 style="color: #B9937B; margin-bottom: 0.75rem;"> Career Growth Path</h4>
                                    <div style="background: #f8f6f3; padding: 1rem; border-radius: 8px; font-family: monospace; color: #666; text-align: center;">
                                        <?= htmlspecialchars($details['growth_path']) ?>
                                    </div>
                                </div>

                                <!-- Skills Needed -->
                                <div style="margin-bottom: 1.5rem;">
                                    <h4 style="color: #B9937B; margin-bottom: 0.75rem;"> Key Skills to Develop</h4>
                                    <div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">
                                        <?php foreach ($details['skills_needed'] as $skill): ?>
                                            <span style="background: #B9937B; color: white; padding: 0.25rem 0.75rem; border-radius: 15px; font-size: 0.85rem;">
                                                <?= htmlspecialchars($skill) ?>
                                            </span>
                                        <?php endforeach; ?>
                                    </div>
                                </div>

                                <!-- Industry Outlook -->
                                <div style="margin-bottom: 1.5rem;">
                                    <h4 style="color: #B9937B; margin-bottom: 0.75rem;">� Industry Outlook</h4>
                                    <p style="color: #555; line-height: 1.6; margin: 0;"><?= htmlspecialchars($details['industry_outlook']) ?></p>
                                </div>

                                <!-- Next Steps -->
                                <div style="background: #e8f4f8; padding: 1rem; border-radius: 8px; border-left: 4px solid #3498db;">
                                    <h4 style="color: #3498db; margin-bottom: 0.75rem;"> Your Next Steps</h4>
                                    <ul style="color: #555; line-height: 1.6; padding-left: 1.5rem; margin: 0;">
                                        <?php foreach ($details['next_steps'] as $step): ?>
                                            <li style="margin-bottom: 0.25rem;"><?= htmlspecialchars($step) ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php else: ?>
                                <!-- Fallback for careers without detailed info -->
                                <p style="color: #555; line-height: 1.6;"><?= htmlspecialchars($career['description']) ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                    
                    <!-- Action Section -->
                    <div style="background: linear-gradient(135deg, #B9937B 0%, #A68A6F 100%); color: white; padding: 2rem; border-radius: 12px; text-align: center; margin-top: 2rem;">
                        <h3 style="margin-bottom: 1rem; color: white;">Ready to Take Action? �</h3>
                        <p style="margin-bottom: 1.5rem; color: #f0e6d9;">Your assessment results are just the beginning. Explore more careers or retake the assessment to refine your matches.</p>
                        <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                            <a href="?page=careers" class="btn" style="background: white; color: #B9937B;">Explore All Careers</a>
                            <a href="?page=assessment" class="btn" style="background: transparent; border: 2px solid white; color: white;">Retake Assessment</a>
                            <a href="?page=dashboard" class="btn" style="background: rgba(255,255,255,0.2); color: white;">Back to Dashboard</a>
                        </div>
                    </div>
                </div>

            <?php elseif ($page === 'careers'): ?>
                <!-- Careers Page -->
                <div class="card">
                    <h2 style="text-align: center; color: #B9937B; margin-bottom: 1.5rem; font-size: 1.75rem;">Explore Career Opportunities</h2>
                    
                    <div class="career-grid">
                        <?php 
                        $allCareers = [
                            [
                                'title' => 'Software Developer',
                                'description' => 'Design and develop innovative software applications using cutting-edge technologies and programming languages.',
                                'salary' => '$60,000 - $120,000',
                                'industry' => 'Technology',
                                'outlook' => 'Excellent (22% growth)',
                                'education' => 'Bachelor\'s degree in Computer Science or related field',
                                'environment' => 'Office environment with flexible remote work options'
                            ],
                            [
                                'title' => 'Data Scientist',
                                'description' => 'Analyze complex data to drive strategic business decisions and uncover valuable insights from large datasets.',
                                'salary' => '$70,000 - $140,000',
                                'industry' => 'Technology',
                                'outlook' => 'Outstanding (31% growth)',
                                'education' => 'Bachelor\'s degree in Statistics, Mathematics, or Computer Science',
                                'environment' => 'Collaborative office environment with data labs and research facilities'
                            ],
                            [
                                'title' => 'UX/UI Designer',
                                'description' => 'Create beautiful and intuitive user experiences for digital products and applications.',
                                'salary' => '$50,000 - $100,000',
                                'industry' => 'Design & Technology',
                                'outlook' => 'Very Good (13% growth)',
                                'education' => 'Bachelor\'s degree in Design, HCI, or related field',
                                'environment' => 'Creative office environment with design studios and collaboration spaces'
                            ],
                            [
                                'title' => 'Project Manager',
                                'description' => 'Lead teams and coordinate projects to deliver successful outcomes on time and within budget.',
                                'salary' => '$55,000 - $110,000',
                                'industry' => 'Business & Management',
                                'outlook' => 'Good (11% growth)',
                                'education' => 'Bachelor\'s degree in Business Administration or related field',
                                'environment' => 'Office environment with meeting rooms and team collaboration areas'
                            ],
                            [
                                'title' => 'Digital Marketing Specialist',
                                'description' => 'Drive brand growth through strategic digital marketing campaigns across multiple channels.',
                                'salary' => '$45,000 - $85,000',
                                'industry' => 'Marketing & Communications',
                                'outlook' => 'Excellent (19% growth)',
                                'education' => 'Bachelor\'s degree in Marketing, Communications, or related field',
                                'environment' => 'Dynamic office environment with creative spaces and analytics tools'
                            ],
                            [
                                'title' => 'Cybersecurity Analyst',
                                'description' => 'Protect organizations from cyber threats and security breaches through monitoring and analysis.',
                                'salary' => '$65,000 - $125,000',
                                'industry' => 'Technology & Security',
                                'outlook' => 'Exceptional (35% growth)',
                                'education' => 'Bachelor\'s degree in Cybersecurity, IT, or related field',
                                'environment' => 'Secure office environment with monitoring centers and security operations'
                            ],
                            [
                                'title' => 'Business Analyst',
                                'description' => 'Bridge the gap between business needs and technology solutions through analysis and planning.',
                                'salary' => '$55,000 - $95,000',
                                'industry' => 'Business & Technology',
                                'outlook' => 'Good (14% growth)',
                                'education' => 'Bachelor\'s degree in Business, IT, or related field',
                                'environment' => 'Professional office environment with access to stakeholders and systems'
                            ],
                            [
                                'title' => 'Content Creator',
                                'description' => 'Develop engaging content across various platforms to build brand awareness and audience engagement.',
                                'salary' => '$35,000 - $75,000',
                                'industry' => 'Media & Communications',
                                'outlook' => 'Very Good (16% growth)',
                                'education' => 'Bachelor\'s degree in Communications, Marketing, or related field',
                                'environment' => 'Creative environment with studios, editing suites, and collaboration spaces'
                            ]
                        ];
                        
                        foreach ($allCareers as $career): ?>
                            <div class="career-card">
                                <h3><?= htmlspecialchars($career['title']) ?></h3>
                                <p style="color: #666; margin-bottom: 1rem; line-height: 1.5;">
                                    <?= htmlspecialchars($career['description']) ?>
                                </p>
                                
                                <div style="margin-bottom: 0.75rem;">
                                    <strong style="color: #B9937B;">Industry:</strong> 
                                    <span style="color: #555;"><?= htmlspecialchars($career['industry']) ?></span>
                                </div>
                                
                                <div style="margin-bottom: 0.75rem;">
                                    <strong style="color: #B9937B;">Job Outlook:</strong> 
                                    <span style="color: #27ae60; font-weight: 600;"><?= htmlspecialchars($career['outlook']) ?></span>
                                </div>
                                
                                <div style="margin-bottom: 0.75rem;">
                                    <strong style="color: #B9937B;">Education:</strong> 
                                    <span style="color: #555; font-size: 0.9rem;"><?= htmlspecialchars($career['education']) ?></span>
                                </div>
                                
                                <div style="margin-bottom: 1rem;">
                                    <strong style="color: #B9937B;">Work Environment:</strong> 
                                    <span style="color: #555; font-size: 0.9rem;"><?= htmlspecialchars($career['environment']) ?></span>
                                </div>
                                
                                <div class="salary" style="font-size: 1.1rem; font-weight: bold; color: #27ae60; text-align: center; padding: 0.5rem; background: #f0f8f0; border-radius: 6px;">
                                    <?= htmlspecialchars($career['salary']) ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div style="text-align: center; margin-top: 2rem; padding: 1.5rem; background: #f8f6f3; border-radius: 8px;">
                        <h3 style="color: #B9937B; margin-bottom: 1rem;">Ready to Start Your Career Journey?</h3>
                        <p style="color: #666; margin-bottom: 1.5rem;">Take our comprehensive assessment to discover which career path aligns with your skills and interests.</p>
                        <a href="?page=assessment" class="btn" style="margin-right: 1rem;">Take Assessment</a>
                        <a href="?page=dashboard" class="btn btn-secondary">Back to Dashboard</a>
                    </div>
                </div>

            <?php else: ?>
                <!-- Access Denied -->
                <div class="card">
                    <h2 style="text-align: center; color: #e74c3c;">Access Denied</h2>
                    <p style="text-align: center;">Please <a href="?page=login" style="color: #B9937B;">login</a> to access this page.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
