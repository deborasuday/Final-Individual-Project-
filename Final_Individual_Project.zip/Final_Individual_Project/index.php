<?php
/**
 * Career Guidance Platform - Main Entry Point
 * Handles all incoming requests and routes them through the application
 */

// Configure secure session settings
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_samesite', 'Strict');

// Enable secure cookies in production
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}

// Start session for user authentication
session_start();

// Enable error reporting for development
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Define application constants
define('ROOT_PATH', __DIR__);
define('APP_PATH', ROOT_PATH . '/app');
define('CONFIG_PATH', ROOT_PATH . '/config');
define('PUBLIC_PATH', ROOT_PATH . '/public');

// Include the autoloader (if it exists)
if (file_exists(ROOT_PATH . '/vendor/autoload.php')) {
    require_once ROOT_PATH . '/vendor/autoload.php';
}

// Include configuration
require_once CONFIG_PATH . '/database.php';
require_once CONFIG_PATH . '/app.php';

// Include the router
require_once APP_PATH . '/core/Router.php';

// Initialize the application
try {
    $router = new Router();
    $router->handleRequest();
} catch (Exception $e) {
    error_log("Application Error: " . $e->getMessage());
    http_response_code(500);
    echo "<h1>Application Error</h1><p>Sorry, something went wrong. Please try again later.</p>";
}