<?php
// Database setup for Career Guidance Platform
echo "<h1>Career Guidance Platform - Database Setup</h1>";

try {
    // Connect to MySQL without selecting a database first
    $conn = new mysqli('localhost', 'root', '');
    
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    
    echo "<p>✓ Connected to MySQL</p>";
    
    // Create database
    if ($conn->query("CREATE DATABASE IF NOT EXISTS career_guidance_platform")) {
        echo "<p>✓ Database created</p>";
    } else {
        throw new Exception("Error creating database: " . $conn->error);
    }
    
    // Select the database
    $conn->select_db('career_guidance_platform');
    
    // Create users table
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(50) DEFAULT 'general_user',
        verified BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql)) {
        echo "<p>✓ Users table created</p>";
    } else {
        echo "<p>Warning: " . $conn->error . "</p>";
    }
    
    // Create assessments table
    $sql = "CREATE TABLE IF NOT EXISTS assessments (
        id INT PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        assessment_type VARCHAR(50) DEFAULT 'comprehensive',
        questions_count INT DEFAULT 20,
        estimated_duration INT DEFAULT 15,
        status VARCHAR(50) DEFAULT 'published',
        created_by INT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql)) {
        echo "<p>✓ Assessments table created</p>";
    } else {
        echo "<p>Warning: " . $conn->error . "</p>";
    }
    
    // Create user_assessment_results table
    $sql = "CREATE TABLE IF NOT EXISTS user_assessment_results (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        assessment_id INT NOT NULL,
        responses JSON NOT NULL,
        calculated_scores JSON,
        recommended_careers JSON,
        completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )";
    
    if ($conn->query($sql)) {
        echo "<p>✓ Assessment results table created</p>";
    } else {
        echo "<p>Warning: " . $conn->error . "</p>";
    }
    
    // Create careers table
    $sql = "CREATE TABLE IF NOT EXISTS careers (
        id INT PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(255) NOT NULL,
        overview TEXT NOT NULL,
        industry VARCHAR(100),
        salary_range_min INT,
        salary_range_max INT,
        job_outlook VARCHAR(50) DEFAULT 'stable',
        education_requirements TEXT,
        work_environment TEXT,
        status VARCHAR(50) DEFAULT 'published',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql)) {
        echo "<p>✓ Careers table created</p>";
    } else {
        echo "<p>Warning: " . $conn->error . "</p>";
    }
    
    // Insert default assessment
    $conn->query("INSERT IGNORE INTO assessments (id, title, description) VALUES (1, 'Career Interest Assessment', 'Discover your career interests and find matching career paths')");
    echo "<p>✓ Default assessment added</p>";
    
    // Insert sample careers
    $careers = [
        ['Software Developer', 'Design and develop software applications using various programming languages and frameworks', 'Technology', 60000, 120000, 'Bachelor degree in Computer Science or related field', 'Office environment with flexible remote work options'],
        ['Data Scientist', 'Analyze complex data to help organizations make informed business decisions', 'Technology', 70000, 140000, 'Bachelor degree in Statistics, Mathematics, or Computer Science', 'Collaborative office environment with data labs'],
        ['Project Manager', 'Plan, execute, and oversee projects from start to finish ensuring quality and deadlines', 'Business', 55000, 110000, 'Bachelor degree in Business Administration or related field', 'Office environment with meeting rooms'],
        ['UX Designer', 'Create user-friendly and visually appealing interfaces for websites and applications', 'Design', 50000, 100000, 'Bachelor degree in Design, HCI, or related field', 'Creative office environment with design studios'],
        ['Marketing Specialist', 'Develop and execute marketing campaigns across various channels and platforms', 'Marketing', 45000, 85000, 'Bachelor degree in Marketing, Communications, or related field', 'Dynamic office environment with creative spaces'],
        ['Cybersecurity Analyst', 'Protect computer systems and networks from cyber threats and security breaches', 'Technology', 65000, 125000, 'Bachelor degree in Cybersecurity, IT, or related field', 'Secure office environment with monitoring centers']
    ];
    
    foreach ($careers as $career) {
        $stmt = $conn->prepare("INSERT IGNORE INTO careers (title, overview, industry, salary_range_min, salary_range_max, education_requirements, work_environment) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssiiss", $career[0], $career[1], $career[2], $career[3], $career[4], $career[5], $career[6]);
        $stmt->execute();
    }
    
    echo "<p>✓ Sample careers added</p>";
    
    $conn->close();
    
    echo "<h2>🎉 Setup Complete!</h2>";
    echo "<p>Your database is ready. You can now use the application.</p>";
    echo "<p><strong><a href='index.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Launch Application</a></strong></p>";
    
} catch (Exception $e) {
    echo "<p style='color: red; background: #f8d7da; padding: 10px; border-radius: 5px;'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<p>Please make sure:</p>";
    echo "<ul>";
    echo "<li>XAMPP is running</li>";
    echo "<li>MySQL service is started</li>";
    echo "<li>You have the correct database permissions</li>";
    echo "</ul>";
}
?>

<style>
body { 
    font-family: Arial, sans-serif; 
    max-width: 700px; 
    margin: 50px auto; 
    padding: 20px; 
    background: #f8f9fa;
}
h1 { color: #333; text-align: center; }
h2 { color: #28a745; text-align: center; }
p { margin: 10px 0; }
a { color: #007bff; text-decoration: none; }
ul { background: white; padding: 15px; border-radius: 5px; }
</style>