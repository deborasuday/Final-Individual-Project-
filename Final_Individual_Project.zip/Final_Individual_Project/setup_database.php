<?php
// Simple database setup for Career Guidance Platform

echo "<h1>Database Setup</h1>";

try {
    $conn = new mysqli('localhost', 'root', '');
    
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    
    echo "<p>Connected to MySQL server</p>";
    
    $sql = file_get_contents(__DIR__ . '/database/database.sql');
    
    if ($conn->multi_query($sql)) {
        echo "<p>Database setup completed successfully!</p>";
        echo "<p><a href='index.php'>Go to Application</a></p>";
    } else {
        throw new Exception("Error: " . $conn->error);
    }
    
    $conn->close();
    
} catch (Exception $e) {
    echo "<p>Error: " . $e->getMessage() . "</p>";
}
?>

<style>
body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
</style>